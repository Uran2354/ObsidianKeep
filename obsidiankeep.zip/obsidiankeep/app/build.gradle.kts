// Модуль приложения ObsidianKeep.
//
// Ключевые особенности сборки:
//  - AGP 9.x со встроенным Kotlin: плагин org.jetbrains.kotlin.android
//    НЕ применяется — Kotlin-исходники компилирует сам AGP;
//  - версия каталога — gradle/libs.versions.toml;
//  - compileSdk 37 поддерживается AGP 9.4 (максимум — API 37);
//  - minSdk 23 — обложено гардами в коде (View#setForeground и т.п.);
//  - targetSdk 35 — включён edge-to-edge, отступы системных панелей
//    применяет Ui.applyEdgeToEdgeInsets() в каждой активности.

plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.obsidiankeep"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.obsidiankeep"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // Обфускация выключена: приложение маленькое, а R8 без правил
            // может срезать рефлексию Keystore/Biometric-коллбеков.
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Встроенный Kotlin AGP 9: байткод под ту же JVM, что и Java-источники.
kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.drawerlayout)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.biometric)
}
