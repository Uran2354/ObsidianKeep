package com.example.obsidiankeep

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.util.Calendar

/**
 * Редактор заметки ObsidianKeep — визуальный аналог полноэкранного
 * редактора веб-live-view:
 *  - режимы «Правка» / «Чтение» (сегментированный переключатель,
 *    live-предпросмотр через [Markdown]);
 *  - markdown-тулбар из круглых чипов: [[вики-ссылка]], #тег, **жирный**,
 *    • список, ☐ чекбокс, `код`;
 *  - теги (выводятся из контента; тап — страница тегов, долгое нажатие —
 *    убрать из текста);
 *  - ссылки — исходящие [[вики-ссылки]] из текста (секция под тегами);
 *    тап по чипу открывает целевую заметку (создаётся при отсутствии);
 *  - цвет (8 свотчей с фиолетовой обводкой выбранного), папка,
 *    напоминание (дата+время, AlarmManager);
 *  - избранное и закрепление; экспорт .md через системное окно «Поделиться»;
 *  - бэклинки «Ссылки сюда»;
 *  - автосохранение с дебаунсом 700 мс + сохранение при уходе с экрана.
 *
 * Клавиатура: нижняя панель (теги/ссылки/цвет) — overlay-слой FrameLayout
 * ПОВЕРХ скролла, клавиатура её ПЕРЕКРЫВАЕТ (панель не поднимается и не
 * оставляет пустого «слота»; см. [applyEdgeToEdgeInsets]).
 *
 * Защита папок: если заметка лежит в защищённой папке и папка заблокирована
 * ([NotesStore.isNoteLocked]), перед редактированием показывается диалог
 * [FolderLock] (PIN или биометрия); при отказе — экран закрывается.
 * Сохранение заблокированной заметки запрещено ([saveNow]).
 *
 * UI построен целиком в коде (иконки — векторные res/drawable). Все
 * строковые литералы — русские.
 */
class EditorActivity : AppCompatActivity() {

    private var note: Note? = null

    private lateinit var toolbarTitle: TextView
    private lateinit var toolbarSubtitle: TextView
    /** Постоянная часть подзаголовка «папка · дата» — счётчик слов добирается динамически. */
    private var subtitleBase: String = ""

    /** Регэксп разбора слов — компилируется один раз (счётчик живёт на каждый ввод). */
    private val wordSplitRegex = Regex("\\s+")
    private lateinit var titleInput: EditText
    private lateinit var contentInput: EditText
    private lateinit var previewText: TextView
    private lateinit var markdownToolbar: HorizontalScrollView
    private lateinit var tagsRow: LinearLayout
    private lateinit var linksRow: LinearLayout
    private lateinit var linksSection: LinearLayout
    private lateinit var colorRow: LinearLayout
    private lateinit var bottomPanel: LinearLayout
    private lateinit var backlinksBox: LinearLayout
    private lateinit var editorScroll: ScrollView
    private lateinit var editorScrollbar: EditorScrollbarView
    private lateinit var modeEditButton: TextView
    private lateinit var modeReadButton: TextView
    private lateinit var favoriteButton: ImageButton
    private lateinit var pinButton: ImageButton

    private var readingMode = false
    /** Диалог разблокировки уже показан (onCreate → onResume не дублируем). */
    private var unlockPending = false
    private val saveHandler = Handler(Looper.getMainLooper())
    private val saveRunnable = Runnable { saveNow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val id = intent?.getStringExtra(EXTRA_NOTE_ID)
        note = id?.let { NotesStore.noteById(it) }
        if (note == null) {
            Toast.makeText(this, "Заметка не найдена", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContentView(buildUi())
        // Клавиатура ПЕРЕКРЫВАЕТ нижнюю панель с тегами/ссылками/цветом (как в
        // live view — она не должна мешать набору), а поднимается только
        // область набора текста, чтобы курсор оставался виден.
        //
        // Панель — overlay в FrameLayout (НЕ строка LinearLayout): при сжатии
        // окна она не резервирует слот над клавиатурой, поэтому пустой тёмной
        // полосы больше не появляется. Высоту клавиатуры applyEdgeToEdgeInsets
        // берёт из insets (API 30+) ИЛИ из сжатия окна (adjustResize, API < 30
        // и системы, проигнорировавшие ADJUST_NOTHING) — в обоих случаях панель
        // уходит ровно под клавиатуру, без двойной компенсации.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
            WindowCompat.setDecorFitsSystemWindows(window, false)
        }
        // Клавиатура открылась/закрылась: видимая область сжалась/расширилась —
        // подтягиваем курсор над клавиатуру («видно что пишется») и сразу
        // пересчитываем полосу прокрутки (после layout — через post).
        applyEdgeToEdgeInsets(editorScroll, bottomPanel) {
            if (::contentInput.isInitialized && contentInput.hasFocus()) {
                contentInput.post { scrollCursorIntoView() }
            }
            editorScroll.post { editorScrollbar.update() }
        }
        // Полоса прокрутки редактора: появляется, когда текст вырастает до
        // клавиатуры (в область не влезает), и её можно тянуть вниз, чтобы
        // видеть набираемое. Обновляется при прокрутке и при изменении
        // высоты контента (набор текста, предпросмотр, высота клавиатуры).
        editorScroll.setOnScrollChangeListener { _, _, _, _, _ -> editorScrollbar.update() }
        editorScroll.getChildAt(0)?.addOnLayoutChangeListener {
            _, _, _, _, _, _, _, _, _ -> editorScrollbar.update()
        }
        if (!ensureUnlocked()) fillFromNote()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Отложенное автосохранение не должно тикать после закрытия экрана.
        saveHandler.removeCallbacksAndMessages(null)
    }

    /**
     * Гейт защиты: если заметка в заблокированной защищённой папке — показать
     * диалог разблокировки. Возвращает true, если показан диалог (fillFromNote
     * делать нельзя: контент в памяти ещё шифротекст).
     */
    private fun ensureUnlocked(): Boolean {
        val n = note ?: return false
        if (!NotesStore.isNoteLocked(n)) return false
        if (unlockPending) return true // диалог уже открыт — не дублируем
        val folder = NotesStore.folderById(n.folderId) ?: return false
        unlockPending = true
        FolderLock.showUnlock(
            this,
            folder,
            onUnlocked = {
                unlockPending = false
                note = NotesStore.noteById(n.id)
                fillFromNote()
            },
            onCancelled = {
                unlockPending = false
                Toast.makeText(this, "Заметка защищена — папка не разблокирована", Toast.LENGTH_LONG).show()
                finish()
            }
        )
        return true
    }

    override fun onResume() {
        super.onResume()
        // Заметка могла измениться из других экранов (граф, теги, корзина).
        val reloaded = NotesStore.noteById(note?.id ?: "")
        if (reloaded == null) {
            Toast.makeText(this, "Заметка удалена", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        note = reloaded
        if (!ensureUnlocked()) fillFromNote()
    }

    override fun onPause() {
        super.onPause()
        saveNow()
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)
    private fun dp(v: Int): Int = Ui.dp(this, v)

    // ----- UI построен целиком в коде (без XML-лейаутов) ---------------------

    @SuppressLint("SetTextI18n")
    private fun buildUi(): View {
        val p = pal
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
        }

        // Тулбар: назад | заголовок+подзаголовок | звезда | булавка | ещё.
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val backButton = Ui.iconButton(this, R.drawable.ic_back, "Назад", p.muted) {
            saveNow()
            finish()
        }
        toolbar.addView(backButton)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        toolbarTitle = Ui.title(this, "Редактор", p, 16f)
        toolbarSubtitle = Ui.subtitle(this, "", p)
        header.addView(toolbarTitle)
        header.addView(toolbarSubtitle)
        toolbar.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        favoriteButton = Ui.iconButton(this, R.drawable.ic_star_outline, "В избранное", p.muted) {
            val n = note ?: return@iconButton
            NotesStore.updateNote(n.id, isFavorite = !n.isFavorite)
            refreshAfterChange()
        }
        toolbar.addView(favoriteButton)

        pinButton = Ui.iconButton(this, R.drawable.ic_pin, "Закрепить", p.muted) {
            val n = note ?: return@iconButton
            NotesStore.updateNote(n.id, isPinned = !n.isPinned)
            refreshAfterChange()
        }
        toolbar.addView(pinButton)

        val moreButton = Ui.iconButton(this, R.drawable.ic_more, "Ещё действия", p.muted) {
            showNoteSheet(it)
        }
        toolbar.addView(moreButton)
        root.addView(toolbar)

        // Скролл-контейнер редактора — растянут на ВСЮ высоту области контента:
        // нижняя панель лежит ПОВЕРХ него (overlay), поэтому при сжатии окна
        // клавиатурой скролл заполняет и её зону — пустой тёмной полосы на месте
        // панели не остаётся.
        // СВОЯ компактная полоса (EditorScrollbarView) — системная длинная
        // отключена: у длинного текста не должно быть ДВУХ полос, только
        // маленькая акцентная, которую можно тянуть пальцем.
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Нижний отступ скромный: зазор до нижней панели добирает
            // динамический паддинг из applyEdgeToEdgeInsets (высота панели/IME).
            setPadding(dp(16), dp(6), dp(16), dp(12))
        }
        scroll.addView(column)
        editorScroll = scroll

        // Заголовок.
        titleInput = EditText(this).apply {
            hint = "Заголовок"
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = null
            isSingleLine = true
            setPadding(0, dp(4), 0, dp(4))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: android.text.Editable?) {
                    saveHandler.removeCallbacks(saveRunnable)
                    saveHandler.postDelayed(saveRunnable, 700)
                }
            })
        }
        column.addView(titleInput)

        // Переключатель режима «Правка / Чтение» — сегментированный, как в вебе.
        column.addView(buildModeSwitch().also {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            it.layoutParams = lp
        })

        // Теги и цвет перенесены в НИЖНЮЮ панель (как в live view) — см. конец buildUi.

        // Markdown-тулбар как в live view: компактная полоса 28dp-кнопок
        // над текстом (в вебе — h-7 w-7 ghost-иконки, а не крупные чипы).
        // Долгое нажатие показывает назначение (аналог tooltip в веб-версии).
        markdownToolbar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            visibility = View.VISIBLE
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
            addView(LinearLayout(this@EditorActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(2), dp(2), dp(2), dp(2))
                background = Ui.rounded(
                    if (isDark) 0x14FFFFFF.toInt() else 0x0A000000.toInt(), 10f, this@EditorActivity
                )
                addView(mdToolButton("B", "Жирный") { wrapSelection("**", "**") })
                addView(mdToolButton("i", "Курсив") { wrapSelection("*", "*") })
                addView(mdToolButton("H", "Заголовок") { insertAtCursor("\n### ") })
                addView(mdToolButton("</>", "Код") { wrapSelection("`", "`") })
                addView(mdToolButton("❝", "Цитата") { insertAtCursor("\n> ") })
                addView(mdToolButton("•", "Список") { insertAtCursor("\n- ") })
                addView(mdToolButton("☐", "Чекбокс") { insertAtCursor("\n- [ ] ") })
                addView(mdToolButton("[[ ]", "Вики-ссылка") { insertAtCursor("[[ ]]") })
                addView(mdToolButton("#", "Тег") { insertAtCursor("#") })
                addView(mdToolButton("—", "Разделитель") { insertAtCursor("\n---\n") })
            })
        }
        column.addView(markdownToolbar)

        // Контент: правка / предпросмотр.
        contentInput = EditText(this).apply {
            hint = "Текст заметки… поддерживается markdown, [[вики-ссылки]] и #теги"
            textSize = 15f
            gravity = Gravity.TOP
            minLines = 8
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = null
            setPadding(0, dp(6), 0, dp(6))
            // Полоса прокрутки у поля своя не нужна — скроллит внешний ScrollView
            // (иначе у длинного текста рисуется вторая, системная полоса).
            isVerticalScrollBarEnabled = false
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: android.text.Editable?) {
                    // Счётчик слов в подзаголовке — живой, на каждый ввод.
                    updateSubtitle()
                    // Курсор остаётся видимым: когда текст доходит до клавиатуры,
                    // строка набора подтягивается над неё сама.
                    if (contentInput.hasFocus()) contentInput.post { scrollCursorIntoView() }
                    // Автосохранение 700 мс — как в веб-версии.
                    saveHandler.removeCallbacks(saveRunnable)
                    saveHandler.postDelayed(saveRunnable, 700)
                }
            })
            // Геометрия пересчиталась (текст вырос, появился перенос, сменился
            // шрифт) — это ПОСЛЕ layout, значит координаты строки уже свежие:
            // держим курсор видимым даже у самой клавиатуры.
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                if (contentInput.hasFocus()) scrollCursorIntoView()
            }
        }
        column.addView(contentInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        previewText = TextView(this).apply {
            textSize = 15f
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, dp(6), 0, dp(6))
        }
        column.addView(previewText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        // Бэклинки.
        backlinksBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(12)
            layoutParams = lp
        }
        column.addView(backlinksBox)

        // Контентная область: скролл во всю высоту + нижняя панель overlay
        // (gravity BOTTOM). Панель НЕ забирает высоту у скролла, поэтому
        // клавиатура перекрывает её без пустых полос и без «подъёма».
        val contentArea = FrameLayout(this)
        contentArea.addView(scroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // Полоса прокрутки (просьба пользователя): видна, когда текст
        // доходит до клавиатуры; тянется пальцем вниз/вверх. Между скроллом
        // и нижней панелью — панель перекрывает её нижнюю часть.
        editorScrollbar = EditorScrollbarView(this, scroll, isDark).apply {
            contentDescription = "Полоса прокрутки текста"
            visibility = View.GONE
        }
        contentArea.addView(editorScrollbar, FrameLayout.LayoutParams(
            Ui.dp(this, 22), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END
        ))

        // Нижняя панель (как в live view): теги, ссылки и цвет — ВСЕГДА внизу
        // экрана и всегда ПОД клавиатурой (клавиатура её перекрывает),
        // поднимается только скролл с текстом (см. applyEdgeToEdgeInsets).
        bottomPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.roundedTop(p.cardElevated, this@EditorActivity, 18f)
            setPadding(dp(14), dp(10), dp(14), dp(12))
            elevation = dp(6).toFloat()
        }
        bottomPanel.addView(Ui.caption(this, "Теги", p).apply {
            setPadding(dp(2), 0, 0, dp(2))
        })
        tagsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        bottomPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tagsRow)
        })

        // Ссылки — под тегами (по просьбе пользователя): исходящие
        // [[вики-ссылки]] из текста; тап по чипу открывает целевую заметку.
        linksSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        linksSection.addView(Ui.caption(this, "Ссылки", p).apply {
            setPadding(dp(2), dp(8), 0, dp(2))
        })
        linksRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        linksSection.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(linksRow)
        })
        bottomPanel.addView(linksSection)

        bottomPanel.addView(Ui.caption(this, "Цвет", p).apply {
            setPadding(dp(2), dp(8), 0, dp(2))
        })
        colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, 0)
        }
        bottomPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(colorRow)
        })
        contentArea.addView(bottomPanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ))
        root.addView(contentArea, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        return root
    }

    /** Сегментированный переключатель «Правка / Чтение». */
    private fun buildModeSwitch(): View {
        val p = pal
        val row = LinearLayout(this).apply {
            background = Ui.rounded(if (p.dark) 0x14FFFFFF.toInt() else 0x0A000000.toInt(), 10f, this@EditorActivity)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        modeEditButton = TextView(this).apply {
            text = "Правка"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { if (readingMode) toggleMode() }
        }
        modeReadButton = TextView(this).apply {
            text = "Чтение"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { if (!readingMode) toggleMode() }
        }
        row.addView(modeEditButton)
        row.addView(modeReadButton)
        styleModeSwitch()
        return row
    }

    /** Подсветка активного сегмента режима. */
    private fun styleModeSwitch() {
        val p = pal
        if (readingMode) {
            modeReadButton.background = Ui.rounded(p.cardElevated, 8f, this, p.primary, 1)
            modeReadButton.setTextColor(p.primaryText)
            modeReadButton.setTypeface(null, Typeface.BOLD)
            modeEditButton.background = null
            modeEditButton.setTextColor(p.muted)
            modeEditButton.setTypeface(null, Typeface.NORMAL)
        } else {
            modeEditButton.background = Ui.rounded(p.cardElevated, 8f, this, p.primary, 1)
            modeEditButton.setTextColor(p.primaryText)
            modeEditButton.setTypeface(null, Typeface.BOLD)
            modeReadButton.background = null
            modeReadButton.setTextColor(p.muted)
            modeReadButton.setTypeface(null, Typeface.NORMAL)
        }
    }

    /** Компактная 28dp-кнопка тулбара (как ghost-иконки h-7 в live view);
     *  долгое нажатие показывает назначение (аналог tooltip в вебе). */
    private fun mdToolButton(label: String, desc: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            contentDescription = desc
            textSize = 12f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(if (isDark) NoteColors.PRIMARY_SOFT_DARK else NoteColors.PRIMARY_LIGHT)
            background = Ui.ripple(this@EditorActivity)
            // Минимум 28dp ширины, высота ровно 28dp — как w-7 h-7 в вебе.
            minimumWidth = Ui.dp(this@EditorActivity, 28)
            setPadding(dp(6), 0, dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this@EditorActivity, 28)
            )
            setOnClickListener { onClick() }
            setOnLongClickListener {
                Toast.makeText(this@EditorActivity, desc, Toast.LENGTH_SHORT).show()
                true
            }
        }

    private fun sectionCaption(text: String): TextView = Ui.caption(this, text, pal).apply {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        layoutParams = lp
    }

    // ----- Счётчик слов в подзаголовке -----------------------------------------

    /** Русская плюрализация: 1 слово / 2 слова / 5 слов (11 не «1»). */
    private fun wordsLabel(count: Int): String = when {
        count % 10 == 1 && count % 100 != 11 -> "$count слово"
        count % 10 in 2..4 && (count % 100 < 12 || count % 100 > 14) -> "$count слова"
        else -> "$count слов"
    }

    /** Подзаголовок тулбара: «папка · дата · N слов» — счётчик живой,
     *  обновляется на каждый ввод (см. TextWatcher контента). */
    private fun updateSubtitle() {
        if (!::toolbarSubtitle.isInitialized || !::contentInput.isInitialized) return
        val text = contentInput.text?.toString().orEmpty()
        val words = if (text.isBlank()) 0 else text.split(wordSplitRegex).count { it.isNotBlank() }
        val wordsPart = if (words == 0) "" else " · " + wordsLabel(words)
        toolbarSubtitle.text = subtitleBase + wordsPart
    }

    // ----- Заполнение и обновление ---------------------------------------------

    /** Обновить все контролы из [note]. */
    private fun fillFromNote() {
        val n = note ?: return
        val p = pal
        val locked = NotesStore.isNoteLocked(n)
        toolbarTitle.text = "Редактор"
        subtitleBase = NotesStore.folderLabel(n)?.let { "$it · " }.orEmpty() +
            formatDate(n.updatedAt, "d MMM yyyy, HH:mm")
        updateSubtitle()
        if (titleInput.text.isNullOrBlank() && n.title.isNotEmpty()) {
            titleInput.setText(n.title)
        }
        // Контент трогаем только если поле не в фокусе редактирования (иначе курсор уедет).
        // Заблокированной заметке контент не показываем (он шифротекст) и не редактируем.
        if (!locked && !contentInput.hasFocus() && contentInput.text.toString() != n.content) {
            contentInput.setText(n.content)
        }
        if (locked) {
            previewText.text = "Заметка защищена. Разблокируйте папку, чтобы открыть содержимое."
            previewText.visibility = View.VISIBLE
        }
        favoriteButton.setImageResource(if (n.isFavorite) R.drawable.ic_star else R.drawable.ic_star_outline)
        favoriteButton.imageTintList = android.content.res.ColorStateList.valueOf(
            if (n.isFavorite) 0xFFF59E0B.toInt() else p.muted
        )
        favoriteButton.contentDescription = if (n.isFavorite) "Убрать из избранного" else "В избранное"
        pinButton.imageTintList = android.content.res.ColorStateList.valueOf(
            if (n.isPinned) p.primary else p.muted
        )
        pinButton.contentDescription = if (n.isPinned) "Открепить" else "Закрепить"
        renderTagChips()
        renderLinks()
        renderColorSwatches()
        renderBacklinks()
        if (readingMode && !locked) renderPreview()
    }

    private fun renderTagChips() {
        val n = note ?: return
        val p = pal
        tagsRow.removeAllViews()
        n.tags.forEach { tag ->
            tagsRow.addView(Ui.tagChip(this, tag, p) {
                // Тап — страница тегов (облако + список заметок тега).
                openTagsPage(tag)
            }.also { chip ->
                // Чип ещё не добавлен в родителя — layoutParams == null,
                // читать и кастовать его нельзя (NPE). Назначаем свежие LP.
                chip.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(6) }
                chip.contentDescription = "Тег #$tag — открыть страницу тегов, долгое нажатие — убрать"
                // Долгое нажатие — убрать тег = вырезать его из контента
                // (теги живут в тексте).
                chip.setOnLongClickListener { v ->
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    val updated = n.content.replace(Regex("(?m)(^|\\s)#${escapeRegExp(tag)}\\b"), "$1")
                        .replace(Regex("(^|\\s)##+"), "$1#")
                    NotesStore.updateNote(n.id, content = updated)
                    note = NotesStore.noteById(n.id)
                    contentInput.setText(note?.content ?: "")
                    refreshAfterChange()
                    Toast.makeText(this@EditorActivity, "Тег убран", Toast.LENGTH_SHORT).show()
                    true
                }
            })
        }
        tagsRow.addView(TextView(this).apply {
            text = "+ тег"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.primaryText)
            background = Ui.rounded(if (p.dark) 0x14FFFFFF.toInt() else 0x0A000000.toInt(), 20f, this@EditorActivity)
            setPadding(dp(10), dp(3), dp(10), dp(3))
            setOnClickListener { showAddTagDialog() }
        })
    }

    /**
     * Ссылки заметки (секция под тегами): исходящие [[вики-ссылки]], которые
     * выводятся из текста. Тап по чипу открывает целевую заметку (создаётся
     * при отсутствии — как в Obsidian); секция живёт вместе с текстом.
     * У заблокированной заметки скрыта (контент — шифротекст, ссылки не
     * извлечь).
     */
    private fun renderLinks() {
        val n = note ?: return
        val p = pal
        val locked = NotesStore.isNoteLocked(n)
        linksSection.visibility = if (locked) View.GONE else View.VISIBLE
        linksRow.removeAllViews()
        if (locked) return
        val targets = extractWikiLinks(n.content)
        if (targets.isEmpty()) {
            linksRow.addView(Ui.hint(
                this,
                "Ссылок нет — напишите [[название]] в тексте",
                p
            ))
            return
        }
        targets.forEach { target ->
            linksRow.addView(TextView(this).apply {
                text = "[[$target]]"
                textSize = 12f
                setTextColor(p.primaryText)
                background = Ui.rounded(p.chipBg, 20f, this@EditorActivity)
                setPadding(dp(10), dp(3), dp(10), dp(3))
                contentDescription = "Открыть заметку $target"
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(6) }
                setOnClickListener { openWikiLink(target) }
            })
        }
    }

    private fun renderColorSwatches() {
        val n = note ?: return
        colorRow.removeAllViews()
        NOTE_COLOR_KEYS.forEach { key ->
            colorRow.addView(Ui.colorSwatch(this, key, key == n.color, pal, 28) { picked ->
                NotesStore.updateNote(n.id, color = picked ?: "default")
                note = NotesStore.noteById(n.id)
                refreshAfterChange()
            })
        }
    }

    private fun renderBacklinks() {
        val n = note ?: return
        val p = pal
        val backlinks = NotesStore.backlinksFor(n)
        backlinksBox.removeAllViews()
        if (backlinks.isEmpty()) return
        backlinksBox.addView(sectionCaption("Ссылки сюда (${backlinks.size})").also {
            val lp = it.layoutParams as LinearLayout.LayoutParams
            lp.topMargin = dp(14)
        })
        backlinks.forEach { source ->
            backlinksBox.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(p.cardElevated, 12f, this@EditorActivity, p.border, 1)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.topMargin = dp(6)
                layoutParams = lp
                addView(ImageView(this@EditorActivity).apply {
                    setImageResource(R.drawable.ic_link)
                    imageTintList = android.content.res.ColorStateList.valueOf(p.primary)
                }, LinearLayout.LayoutParams(dp(15), dp(15)).apply { marginEnd = dp(9) })
                addView(TextView(this@EditorActivity).apply {
                    text = source.title.ifBlank { "Без названия" }
                    textSize = 13f
                    setTextColor(p.primaryText)
                })
                setOnClickListener {
                    startActivity(Intent(this@EditorActivity, EditorActivity::class.java).apply {
                        putExtra(EXTRA_NOTE_ID, source.id)
                    })
                }
            })
        }
    }

    private fun renderPreview() {
        val n = note ?: return
        Markdown.render(
            previewText,
            n.title.ifBlank { "Без названия" } + "\n\n" + n.content,
            isDark,
            onWikiLink = { title -> openWikiLink(title) },
            onTag = { tag ->
                // Тег ведёт на страницу тегов (облако + заметки тега) —
                // редактор остаётся в стеке, назад возвращается в него.
                openTagsPage(tag)
            }
        )
    }

    /** Открыть страницу тегов с выбранным тегом. */
    private fun openTagsPage(tag: String) {
        startActivity(Intent(this, TagsActivity::class.java).apply {
            putExtra(TagsActivity.EXTRA_TAG, tag)
        })
    }

    // ----- Режимы, сохранение, вставки -------------------------------------------

    private fun toggleMode() {
        readingMode = !readingMode
        styleModeSwitch()
        markdownToolbar.visibility = if (readingMode) View.GONE else View.VISIBLE
        contentInput.visibility = if (readingMode) View.GONE else View.VISIBLE
        previewText.visibility = if (readingMode) View.VISIBLE else View.GONE
        if (readingMode) {
            saveNow()
            renderPreview()
        }
    }

    /** Немедленно сохранить поля ввода в хранилище. */
    private fun saveNow() {
        val n = note ?: return
        // Заблокированную заметку нельзя менять (контент в памяти — шифротекст;
        // случайная запись открытого текста из EditText недопустима).
        if (NotesStore.isNoteLocked(n)) return
        val newTitle = titleInput.text?.toString().orEmpty()
        val newContent = contentInput.text?.toString().orEmpty()
        if (newTitle == n.title && newContent == n.content) return
        note = NotesStore.updateNote(n.id, title = newTitle, content = newContent)
        // Теги и [[ссылки]] могли измениться вместе с контентом.
        renderTagChips()
        renderLinks()
    }

    /** Обновить экран после правки хранилища. */
    private fun refreshAfterChange() {
        note = NotesStore.noteById(note?.id ?: "") ?: note
        fillFromNote()
    }

    private fun insertAtCursor(text: String) {
        val edit = contentInput
        val end = edit.selectionEnd.coerceAtLeast(0)
        edit.text?.insert(end, text)
        edit.setSelection((end + text.length).coerceAtMost(edit.text?.length ?: 0))
    }

    /**
     * Подтянуть строку с курсором в видимую область: когда текст доходит
     * до клавиатуры, набираемая строка уезжает под неё — скролл сам
     * опускается вниз, пока строка не окажется над клавиатурой («видно
     * что пишется»), заодно вниз автоматически уходит и полоса прокрутки.
     *
     * Прямая арифметика по scrollY, а не requestRectangleOnScreen: тот
     * вызывался до layout (устаревшая геометрия строки) и не знал про
     * нижний padding-IME скролла — у клавиатуры курсор оставался скрыт.
     */
    private fun scrollCursorIntoView() {
        if (readingMode || !contentInput.hasFocus()) return
        val layout = contentInput.layout ?: return
        val sel = contentInput.selectionEnd.coerceIn(0, contentInput.text?.length ?: 0)
        val line = layout.getLineForOffset(sel)
        val margin = dp(8)
        // Координаты строки курсора внутри ребёнка скролла (колонки контента).
        val lineTop = contentInput.top + layout.getLineTop(line)
        val lineBottom = contentInput.top + layout.getLineBottom(line)
        // Видимое окно скролла: высота минус верхний паддинг и минус
        // нижний padding-IME (высота клавиатуры).
        val visTop = editorScroll.scrollY + editorScroll.paddingTop
        val visBottom = editorScroll.scrollY + editorScroll.height - editorScroll.paddingBottom
        val child = editorScroll.getChildAt(0) ?: return
        val maxScroll = (child.height -
            (editorScroll.height - editorScroll.paddingTop - editorScroll.paddingBottom)).coerceAtLeast(0)
        val target = when {
            lineBottom + margin > visBottom -> lineBottom - editorScroll.height + editorScroll.paddingBottom + margin
            lineTop - margin < visTop -> lineTop - editorScroll.paddingTop - margin
            else -> return // строка уже видна — не дёргаем скролл
        }
        editorScroll.scrollTo(0, target.coerceIn(0, maxScroll))
    }

    private fun wrapSelection(prefix: String, suffix: String) {
        val edit = contentInput
        val text = edit.text ?: return
        val start = Math.min(edit.selectionStart.coerceAtLeast(0), edit.selectionEnd.coerceAtLeast(0))
        val end = Math.max(edit.selectionStart.coerceAtLeast(0), edit.selectionEnd.coerceAtLeast(0))
        if (start == end) {
            text.insert(start, prefix + suffix)
            edit.setSelection(start + prefix.length)
        } else {
            text.insert(end, suffix)
            text.insert(start, prefix)
            edit.setSelection(start + prefix.length, end + prefix.length)
        }
    }

    private fun openWikiLink(title: String) {
        saveNow()
        val target = NotesStore.findOrCreateByTitle(title)
        startActivity(Intent(this, EditorActivity::class.java).apply {
            putExtra(EXTRA_NOTE_ID, target.id)
        })
    }

    // ----- Меню действий (bottom-sheet) ----------------------------------------------

    private fun showNoteSheet(anchor: View) {
        val n = note ?: return
        val p = pal
        val dialog = BottomSheetDialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.roundedTop(p.cardElevated, this@EditorActivity)
            setPadding(dp(8), dp(10), dp(8), dp(14))
        }
        box.addView(View(this).apply {
            background = Ui.rounded(if (p.dark) 0x33FFFFFF.toInt() else 0x1A000000.toInt(), 2f, this@EditorActivity)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        box.addView(Ui.title(this, "Действия", p, 16f).apply {
            setPadding(dp(12), dp(10), dp(12), dp(4))
        })

        // Каждое действие закрывает шторку ПЕРЕД запуском следующего окна
        // (иначе системный выбор висел поверх шторки и сбивал с толку).
        sheetRow(box, R.drawable.ic_bell,
            if (n.reminderAt != null) "Напоминание: " + formatDate(n.reminderAt!!, "d MMM HH:mm") + "…" else "Напоминание…"
        ) { dialog.dismiss(); pickReminder() }
        if (n.reminderAt != null) {
            sheetRow(box, R.drawable.ic_close, "Убрать напоминание") {
                dialog.dismiss()
                NotesStore.updateNote(n.id, clearReminder = true)
                Reminders.cancel(this, n.id)
                Toast.makeText(this, "Напоминание убрано", Toast.LENGTH_SHORT).show()
                refreshAfterChange()
            }
        }
        sheetRow(box, R.drawable.ic_folder, "Папка…") { dialog.dismiss(); pickFolder() }
        // «Поделиться» теперь двумя каналами: РЕАЛЬНЫЙ файл .md (FileProvider,
        // его можно сохранить на Диск/в почту) и обычный текст для мессенджеров.
        sheetRow(box, R.drawable.ic_link, "Поделиться файлом .md") { dialog.dismiss(); shareNoteFile(n) }
        sheetRow(box, R.drawable.ic_text, "Поделиться текстом") { dialog.dismiss(); shareNoteText(n) }
        sheetRow(box, R.drawable.ic_trash, "В корзину", danger = true) { dialog.dismiss(); confirmTrash(n) }

        dialog.setContentView(box)
        dialog.show()
    }

    /** Строка bottom-sheet (как в MainActivity — общий вид действий). */
    private fun sheetRow(
        parent: LinearLayout,
        iconRes: Int,
        label: String,
        danger: Boolean = false,
        onClick: () -> Unit
    ) {
        val p = pal
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = Ui.ripple(this@EditorActivity)
            isClickable = true
            isFocusable = true
            addView(ImageView(this@EditorActivity).apply {
                setImageResource(iconRes)
                imageTintList = android.content.res.ColorStateList.valueOf(if (danger) p.danger else p.muted)
            }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginEnd = dp(14) })
            addView(TextView(this@EditorActivity).apply {
                text = label
                textSize = 14f
                setTextColor(if (danger) p.danger else p.text)
            })
            setOnClickListener { onClick() }
        })
    }

    private fun pickReminder() {
        val n = note ?: return
        val cal = Calendar.getInstance()
        if (n.reminderAt != null) cal.timeInMillis = n.reminderAt!!
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, hh, mm ->
                val at = Calendar.getInstance().apply {
                    set(y, m, d, hh, mm, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                NotesStore.updateNote(n.id, reminderAt = at)
                note = NotesStore.noteById(n.id)
                // note может стать null, если заметку удалили извне — не падаем.
                note?.let { Reminders.schedule(this, it) }
                Toast.makeText(this, "Напоминание: " + formatDate(at, "d MMM yyyy, HH:mm"), Toast.LENGTH_SHORT).show()
                refreshAfterChange()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun pickFolder() {
        val n = note ?: return
        val p = pal
        val folders = NotesStore.folders.value
        val items = mutableListOf("Без папки") + folders.map {
            it.name + if (it.isProtected) " · защищена" else ""
        }
        val checked = folders.indexOfFirst { it.id == n.folderId } + 1
        AlertDialog.Builder(this)
            .setTitle("Папка заметки")
            .setSingleChoiceItems(items.toTypedArray(), checked) { dialog, which ->
                val targetId = if (which == 0) null else folders[which - 1].id
                val target = if (which == 0) null else folders[which - 1]
                // Выбор заблокированной защищённой папки — сначала разблокировка.
                if (target != null && NotesStore.isFolderLocked(target.id)) {
                    dialog.dismiss()
                    FolderLock.showUnlock(
                        this,
                        target,
                        onUnlocked = {
                            NotesStore.updateNote(n.id, folderId = target.id)
                            note = NotesStore.noteById(n.id)
                            refreshAfterChange()
                        }
                    )
                    return@setSingleChoiceItems
                }
                NotesStore.updateNote(n.id, folderId = targetId, clearFolder = which == 0)
                note = NotesStore.noteById(n.id)
                dialog.dismiss()
                refreshAfterChange()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showAddTagDialog() {
        val input = EditText(this).apply {
            hint = "имя-тега"
            isSingleLine = true
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(32))
        }
        AlertDialog.Builder(this)
            .setTitle("Добавить тег")
            .setMessage("Тег добавится в текст заметки как #хэштег — теги живут в контенте.")
            .setView(input)
            .setPositiveButton("Добавить") { _, _ ->
                val tag = input.text?.toString()?.trim()?.removePrefix("#").orEmpty()
                if (tag.isEmpty()) return@setPositiveButton
                val n = note ?: return@setPositiveButton
                val appended = if (n.content.isBlank()) "#$tag" else n.content.trimEnd() + " #$tag"
                NotesStore.updateNote(n.id, content = appended)
                note = NotesStore.noteById(n.id)
                contentInput.setText(note?.content ?: "")
                refreshAfterChange()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Поделиться РЕАЛЬНЫМ .md-файлом (FileProvider) — файл сохраняется куда угодно. */
    private fun shareNoteFile(n: Note) {
        if (NotesStore.isNoteLocked(n)) {
            // Контент заблокированной заметки в памяти — шифротекст: делиться им нельзя.
            Toast.makeText(this, "Заметка защищена — сначала разблокируйте её папку", Toast.LENGTH_LONG).show()
            return
        }
        saveNow() // в файл уходит последняя редакция, а не то, что на диске
        if (!NoteShare.shareFile(this, n)) {
            Toast.makeText(this, "Не удалось создать файл для экспорта", Toast.LENGTH_LONG).show()
        }
    }

    /** Поделиться текстом (мессенджеры, заметки в другие приложения). */
    private fun shareNoteText(n: Note) {
        if (NotesStore.isNoteLocked(n)) {
            Toast.makeText(this, "Заметка защищена — сначала разблокируйте её папку", Toast.LENGTH_LONG).show()
            return
        }
        saveNow()
        NoteShare.shareText(this, n)
    }

    /** Двухшаговое удаление: подтверждение → корзина (10 дней на восстановление). */
    private fun confirmTrash(n: Note) {
        AlertDialog.Builder(this)
            .setTitle("В корзину?")
            .setMessage("Заметка «${n.title.ifBlank { "Без названия" }}» будет удалена через 10 дней. До этого её можно восстановить.")
            .setPositiveButton("В корзину") { _, _ ->
                NotesStore.trashNote(n.id)
                Toast.makeText(this, "Заметка перемещена в корзину", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun formatDate(time: Long, pattern: String): String = Ui.formatDate(time, pattern)

    companion object {
        /** Экстра intent: id заметки для редактирования. */
        const val EXTRA_NOTE_ID = "noteId"
    }
}

/**
 * Вертикальная полоса прокрутки редактора (просьба пользователя: чтобы
 * «полоска для просмотра появлялась при достижении клавиатуры» и её можно
 * было опустить вниз к набираемому тексту). Появляется, когда контент
 * перестаёт влезать в видимую область (в геометрии учтён нижний отступ
 * скролла — высота клавиатуры), тянется пальцем и прячется, когда
 * прокручивать нечего. Системная длинная полоса скролла отключена —
 * эта маленькая заменяет её (жалоба «создаётся 2 полосы прокрутки»).
 */
private class EditorScrollbarView(
    context: Context,
    private val scroll: ScrollView,
    isDark: Boolean
) : View(context) {

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var dragging = false
    private var grabDy = 0f

    // Геометрия — пересчитывается в [update] (на прокрутку/лейаут/клавиатуру).
    private var trackTop = 0f
    private var trackH = 0f
    private var thumbH = 0f
    private var thumbY = 0f
    private var scrollRange = 0

    init {
        // Акцентный цвет темы — полупрозрачный, виден на светлой и тёмной.
        val primary = if (isDark) NoteColors.PRIMARY_SOFT_DARK else NoteColors.PRIMARY_LIGHT
        thumbPaint.color = primary
        trackPaint.color = (primary and 0x00FFFFFF) or 0x26000000
    }

    /** Пересчитать геометрию и видимость по текущему состоянию скролла. */
    fun update() {
        val child = scroll.getChildAt(0)
        if (child == null || scroll.height == 0) { visibility = View.GONE; return }
        // Видимая область = высота скролла минус его padding (снизу — клавиатура).
        val viewportH = (scroll.height - scroll.paddingTop - scroll.paddingBottom).coerceAtLeast(0)
        // Диапазон прокрутки — РОВНО как у ScrollView (getScrollRange):
        // контент минус видимая область. Раньше padding учитывался дважды
        // (и в «контенте», и в «видимом»): полоса появлялась раньше времени,
        // а thumb при перетаскивании не доходил до низа — drag казался
        // сломанным (жалоба «двигать пальцем нельзя»).
        scrollRange = (child.height - viewportH).coerceAtLeast(0)
        val inset = Ui.dp(context, 6)
        trackTop = (scroll.paddingTop + inset).toFloat()
        trackH = (viewportH - inset * 2).coerceAtLeast(0).toFloat()
        if (scrollRange <= 0 || trackH <= 0f) { visibility = View.GONE; return }
        // ОДИНАКОВАЯ небольшая полоса у всех заметок (просьба пользователя:
        // «сейчас они с разными длинами»): фиксированная высота вместо
        // пропорциональной объёму текста — где бы ни открывали заметку,
        // полоска одна и та же.
        thumbH = minOf(trackH, Ui.dp(context, 36).toFloat())
        val frac = if (scrollRange == 0) 0f else scroll.scrollY.toFloat() / scrollRange
        thumbY = trackTop + frac * (trackH - thumbH).coerceAtLeast(0f)
        alpha = if (dragging) 1f else 0.55f
        visibility = View.VISIBLE
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (trackH <= 0f || thumbH <= 0f) return
        val thumbW = Ui.dp(context, 4).toFloat()
        val railHalf = Ui.dp(context, 2).toFloat()
        val cx = width - Ui.dp(context, 5) - thumbW / 2f
        canvas.drawRoundRect(
            cx - railHalf, trackTop, cx + railHalf, trackTop + trackH,
            railHalf, railHalf, trackPaint
        )
        canvas.drawRoundRect(
            cx - thumbW / 2f, thumbY, cx + thumbW / 2f, thumbY + thumbH,
            thumbW / 2f, thumbW / 2f, thumbPaint
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                // Тап мимо thumb — ставим thumb под палец (как системные
                // полосы): иначе, схватив «пустое место» далеко от полоски,
                // пришлось бы тащить её через весь экран до контакта.
                if (thumbH <= 0f || event.y < thumbY || event.y > thumbY + thumbH) {
                    jumpThumbTo(event.y)
                }
                grabDy = event.y - thumbY
                alpha = 1f
            }
            MotionEvent.ACTION_MOVE -> {
                if (scrollRange > 0) {
                    val span = (trackH - thumbH).coerceAtLeast(1f)
                    val frac = ((event.y - grabDy - trackTop) / span).coerceIn(0f, 1f)
                    scroll.scrollTo(0, (frac * scrollRange).toInt())
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                alpha = 0.55f
                performClick()
            }
            else -> return false
        }
        return true
    }

    /** Мгновенно поставить thumb (и скролл) по вертикальной позиции пальца. */
    private fun jumpThumbTo(touchY: Float) {
        val span = (trackH - thumbH).coerceAtLeast(1f)
        val frac = ((touchY - thumbH / 2f - trackTop) / span).coerceIn(0f, 1f)
        scroll.scrollTo(0, (frac * scrollRange).toInt())
        update() // thumbY — по фактическому scrollY (scrollTo мог упереться в край)
    }

    override fun performClick(): Boolean = super.performClick()
}
