package com.example.obsidiankeep

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Настройки оформления ObsidianKeep (аналог диалога «Настройки» веб-версии).
 *
 * Хранятся в SharedPreferences — тот же набор опций, что и в вебе:
 *  - тема: «system» / «light» / «dark»
 *  - подложка цветных карточек: «bright» (насыщенная, по умолчанию) /
 *    «muted» (приглушённая)
 *  - сетка: «normal» (2 колонки) / «compact» (3 колонки)
 *
 * Плюс состояние UI: сортировка и активные фильтры (тег/цвет/папка).
 *
 * Все строковые литералы — русские (ключи настроек — латиница, это
 * идентификаторы, а не UI-текст).
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.getSharedPreferences("obsidiankeep", Context.MODE_PRIVATE)

    // ----- Тема -------------------------------------------------------------

    /** «system» | «light» | «dark» — по умолчанию тёмная (как в веб-версии). */
    var theme: String
        get() = sp.getString(KEY_THEME, "dark") ?: "dark"
        set(value) = sp.edit().putString(KEY_THEME, value).apply()

    // ----- Подложка цветных карточек ----------------------------------------

    /** «bright» (насыщенная, по умолчанию) | «muted» (приглушённая). */
    var tint: String
        get() = sp.getString(KEY_TINT, "bright") ?: "bright"
        set(value) = sp.edit().putString(KEY_TINT, value).apply()

    val isTintBright: Boolean get() = tint != "muted"

    // ----- Сетка ------------------------------------------------------------

    /** «normal» (2 колонки, по умолчанию) | «compact» (3 колонки). */
    var gridDensity: String
        get() = sp.getString(KEY_GRID, "normal") ?: "normal"
        set(value) = sp.edit().putString(KEY_GRID, value).apply()

    val isCompactGrid: Boolean get() = gridDensity == "compact"

    // ----- Состояние списков -------------------------------------------------

    /**
     * Сортировка — У КАЖДОГО СПИСКА СВОЯ (просьба пользователя): корень,
     * каждая папка, избранное. Хранится картой «scope → ключ» в одном
     * SharedPreferences-ключе (JSON). scope — "root" для заметок без папки,
     * id папки, "favorites"; см. [sortKeyFor].
     */
    fun sortKeyFor(scope: String): SortKey =
        runCatching {
            SortKey.valueOf(sortMap().optString(scope, SortKey.UPDATED.name))
        }.getOrDefault(SortKey.UPDATED)

    fun setSortKeyFor(scope: String, key: SortKey) {
        val map = sortMap()
        map.put(scope, key.name)
        sp.edit().putString(KEY_SORT_MAP, map.toString()).apply()
    }

    private fun sortMap(): JSONObject =
        runCatching { JSONObject(sp.getString(KEY_SORT_MAP, "{}") ?: "{}") }.getOrDefault(JSONObject())

    /** Активный фильтр по тегу (точное lowercase-имя) или null. */
    var tagFilter: String?
        get() = sp.getString(KEY_TAG_FILTER, null)
        set(value) = sp.edit().putString(KEY_TAG_FILTER, value).apply()

    /** Активный фильтр по цвету (ключ) или null. */
    var colorFilter: String?
        get() = sp.getString(KEY_COLOR_FILTER, null)
        set(value) = sp.edit().putString(KEY_COLOR_FILTER, value).apply()

    /** Открытая папка (id) или null. */
    var folderId: String?
        get() = sp.getString(KEY_FOLDER, null)
        set(value) = sp.edit().putString(KEY_FOLDER, value).apply()

    /**
     * Миграция: старая глобальная сортировка (одна на всё приложение,
     * ключ "sort_key") становится сортировкой корневого списка. Вызывается
     * один раз при первом чтении настроек после обновления.
     */
    fun migrateLegacySort() {
        val legacy = sp.getString("sort_key", null) ?: return
        sp.edit().remove("sort_key").apply()
        if (!sortMap().has("root")) {
            val key = runCatching { SortKey.valueOf(legacy) }.getOrDefault(SortKey.UPDATED)
            setSortKeyFor("root", key)
        }
    }

    /** Сбросить поисковые фильтры (кнопка «сбросить» в списке). */
    fun resetFilters() {
        tagFilter = null
        colorFilter = null
        folderId = null
    }

    companion object {
        private const val KEY_THEME = "theme"
        private const val KEY_TINT = "note_tint"
        private const val KEY_GRID = "compact_grid"
        private const val KEY_SORT_MAP = "sort_key_map"
        private const val KEY_TAG_FILTER = "tag_filter"
        private const val KEY_COLOR_FILTER = "color_filter"
        private const val KEY_FOLDER = "folder_id"
    }
}
