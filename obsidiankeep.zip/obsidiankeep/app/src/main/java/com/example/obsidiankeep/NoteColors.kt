package com.example.obsidiankeep

import android.graphics.Color
import androidx.core.graphics.ColorUtils

/**
 * Цветовые токены ObsidianKeep — единый источник для всех экранов
 * (аналог src/app/globals.css + src/lib/note-colors.ts веб-версии).
 *
 * Палитра повторяет веб-live-view: нейтральный цинк (zinc) + фиолетовый
 * акцент (violet), тёмная тема по умолчанию. Смешивание цвета карточки
 * с фоном выполняется через ColorUtils.blendARGB — аналог
 * `color-mix(in oklab, ${hex} N%, var(--card))`.
 *
 * Подложка цветных карточек: НАСЫЩЕННАЯ по умолчанию (18% подмешивания,
 * рамка 45% альфы — требование «сделать цвета менее прозрачными»),
 * «Приглушённая» в настройках возвращает 9% / 28%.
 */
object NoteColors {

    // HEX цветов карточек. «Зелёный» (#10B981) был почти неотличим от бирюзового
    // (#14B8A6), а «розовый» (#EC4899) — от красного (#F43F5E) — заменены на
    // лаймовый и фуксию (старые ключи мигрирует normalizeColor в Models.kt).
    private val HEX: Map<String, Int> = mapOf(
        "default" to 0xFF71717A.toInt(),
        "red" to 0xFFF43F5E.toInt(),
        "amber" to 0xFFF59E0B.toInt(),
        "lime" to 0xFF84CC16.toInt(),
        "teal" to 0xFF14B8A6.toInt(),
        "blue" to 0xFF0EA5E9.toInt(),
        "violet" to 0xFF8B5CF6.toInt(),
        "fuchsia" to 0xFFD946EF.toInt()
    )

    // ----- Нейтральная шкала (zinc, как --background/--card/--border в вебе) ----

    /** var(--background) тёмной темы — zinc-950. */
    const val BG_DARK = 0xFF0A0A0C.toInt()
    /** var(--background) светлой темы. */
    const val BG_LIGHT = 0xFFFFFFFF.toInt()

    /** var(--card) — фон карточек и панелей. */
    const val CARD_DARK = 0xFF18181B.toInt()
    const val CARD_LIGHT = 0xFFFFFFFF.toInt()

    /** Приподнятая поверхность (диалоги, bottom-sheet, поля ввода). */
    const val CARD_ELEVATED_DARK = 0xFF202024.toInt()
    const val CARD_ELEVATED_LIGHT = 0xFFFAFAFA.toInt()

    /** var(--border): white/8% в тёмной, zinc-200 в светлой. */
    const val BORDER_DARK = 0x15FFFFFF.toInt()
    const val BORDER_LIGHT = 0xFFE4E4E7.toInt()

    /** var(--foreground). */
    const val TEXT_LIGHT = 0xFF18181B.toInt()
    const val TEXT_DARK = 0xFFF4F4F5.toInt()

    /** var(--muted-foreground): zinc-500 / zinc-400. */
    const val MUTED_LIGHT = 0xFF71717A.toInt()
    const val MUTED_DARK = 0xFFA1A1AA.toInt()

    // ----- Акцент (violet, как --primary в вебе) --------------------------------

    const val PRIMARY_LIGHT = 0xFF7C3AED.toInt()   // violet-600 (светлая тема)
    const val PRIMARY_DARK = 0xFF8B5CF6.toInt()    // violet-500 (тёмная тема)
    const val PRIMARY_SOFT_DARK = 0xFFC4B5FD.toInt()   // violet-300 (текст чипов)
    const val PRIMARY_SOFT_LIGHT = 0xFF7C3AED.toInt()

    /** Destructive (rose) — корзина и необратимые действия. */
    const val DANGER_DARK = 0xFFFB7185.toInt()
    const val DANGER_LIGHT = 0xFFE11D48.toInt()

    /** Фон чипа (violet 15% — «менее прозрачные» цвета, как в веб-версии). */
    private const val CHIP_ALPHA = 0x26 // 15%

    // ----- Подложка цветных карточек --------------------------------------------

    /** Доля цвета в фоне карточки и альфа рамки (bright — по умолчанию). */
    private const val BG_MIX_BRIGHT = 0.18f
    private const val BORDER_ALPHA_BRIGHT = 0.45f
    private const val BG_MIX_MUTED = 0.09f
    private const val BORDER_ALPHA_MUTED = 0.28f

    fun colorHex(colorKey: String?): Int = HEX[normalizeColor(colorKey)] ?: HEX.getValue("default")

    fun colorLabel(colorKey: String?): String =
        NOTE_COLOR_LABELS[normalizeColor(colorKey)] ?: "Без цвета"

    /** Акцент темы: violet-500/600. */
    fun primary(dark: Boolean): Int = if (dark) PRIMARY_DARK else PRIMARY_LIGHT

    /** Цвет «разрушающих» действий. */
    fun danger(dark: Boolean): Int = if (dark) DANGER_DARK else DANGER_LIGHT

    /** Фон экрана var(--background). */
    fun screenBackground(dark: Boolean): Int = if (dark) BG_DARK else BG_LIGHT

    /** Фон карточки var(--card). */
    fun card(dark: Boolean): Int = if (dark) CARD_DARK else CARD_LIGHT

    /** Приподнятая поверхность (диалоги, шиты, поля). */
    fun cardElevated(dark: Boolean): Int =
        if (dark) CARD_ELEVATED_DARK else CARD_ELEVATED_LIGHT

    /** Нейтральная рамка var(--border). */
    fun border(dark: Boolean): Int = if (dark) BORDER_DARK else BORDER_LIGHT

    /** Поверхность чуть светлее/темнее карточки (шиты, крупные панели). */
    fun surfaceBackground(dark: Boolean): Int =
        ColorUtils.blendARGB(card(dark), if (dark) Color.WHITE else Color.BLACK, 0.03f)

    // ----- Карточки заметок -----------------------------------------------------

    /** Фон карточки с учётом темы и настройки подложки. */
    fun cardBackground(colorKey: String?, dark: Boolean, tintBright: Boolean): Int {
        if (colorKey == null || colorKey == "default") {
            return card(dark)
        }
        val mix = if (tintBright) BG_MIX_BRIGHT else BG_MIX_MUTED
        return ColorUtils.blendARGB(card(dark), colorHex(colorKey), mix)
    }

    /** Рамка карточки — цвет с альфой (аналог color-mix(..., transparent)). */
    fun cardBorder(colorKey: String?, tintBright: Boolean): Int {
        if (colorKey == null || colorKey == "default") {
            // Нейтральная рамка «border-border/60».
            return if (tintBright) 0x99888890.toInt() else 0x60888890.toInt()
        }
        val alpha = if (tintBright) BORDER_ALPHA_BRIGHT else BORDER_ALPHA_MUTED
        val hex = colorHex(colorKey)
        return Color.argb((alpha * 255).toInt(), Color.red(hex), Color.green(hex), Color.blue(hex))
    }

    /** Цвет сплошного маркера/точки цвета (выбор в меню, точки графа и календаря). */
    fun accent(colorKey: String?): Int = colorHex(colorKey)

    // ----- Чипы -----------------------------------------------------------------

    /** Подложка чипа тега (#имя) — фиолетовая полупрозрачная. */
    fun chipBackground(dark: Boolean): Int {
        val base = primary(dark)
        return Color.argb(CHIP_ALPHA, Color.red(base), Color.green(base), Color.blue(base))
    }

    /** Цвет текста чипа тега (violet-300 / violet-600). */
    fun chipText(dark: Boolean): Int = if (dark) PRIMARY_SOFT_DARK else PRIMARY_SOFT_LIGHT
}
