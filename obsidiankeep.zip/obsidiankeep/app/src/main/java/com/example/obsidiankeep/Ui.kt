package com.example.obsidiankeep

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.appcompat.app.AppCompatDelegate

/**
 * Мини-дизайн-система ObsidianKeep — общие строительные блоки для всех
 * экранов, чтобы приложение выглядело единообразно с веб-live-view:
 *
 *  - [Palette] — набор токенов темы (фон, карточка, рамка, текст, акцент);
 *  - [rounded] — скруглённые подложки (карточки, чипы, поля);
 *  - [iconButton] — квадратные 40dp кнопки с векторными иконками;
 *  - [chip] / [filterChip] — чипы тегов и активных фильтров;
 *  - [caption] / [sectionHeader] — типографика разделов;
 *  - [applyEdgeToEdgeInsets] — edge-to-edge для targetSdk 35.
 *
 * Всё строится в коде — без XML-лейаутов и ViewBinding. Строковые
 * литералы в UI — русские.
 */

/** Токены одной темы — передаются во все построители интерфейса. */
data class Palette(
    val dark: Boolean,
    val background: Int,
    val card: Int,
    val cardElevated: Int,
    val border: Int,
    val text: Int,
    val muted: Int,
    val primary: Int,
    val primaryText: Int,
    val chipBg: Int,
    val danger: Int
)

object Ui {

    fun palette(dark: Boolean): Palette = Palette(
        dark = dark,
        background = NoteColors.screenBackground(dark),
        card = NoteColors.card(dark),
        cardElevated = NoteColors.cardElevated(dark),
        border = NoteColors.border(dark),
        text = if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT,
        muted = if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT,
        primary = NoteColors.primary(dark),
        primaryText = if (dark) NoteColors.PRIMARY_SOFT_DARK else NoteColors.PRIMARY_SOFT_LIGHT,
        chipBg = NoteColors.chipBackground(dark),
        danger = NoteColors.danger(dark)
    )

    /**
     * Тема активности. Явный выбор (светлая/тёмная) читается из
     * AppCompatDelegate — он синхронно обновляется при переключении в
     * настройках, поэтому перерисовка (rethemeInPlace) получает НОВУЮ тему
     * сразу, не дожидаясь, пока конфигурация активности «доедет».
     * «Системная» — по конфигурации активности.
     */
    fun isDark(activity: Activity): Boolean =
        when (AppCompatDelegate.getDefaultNightMode()) {
            AppCompatDelegate.MODE_NIGHT_YES -> true
            AppCompatDelegate.MODE_NIGHT_NO -> false
            else ->
                (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                    Configuration.UI_MODE_NIGHT_YES
        }

    fun dp(context: Context, v: Int): Int =
        (v * context.resources.displayMetrics.density).toInt()

    // ----- Формы ----------------------------------------------------------------

    /** Скруглённый прямоугольник (цвет + рамка). */
    fun rounded(
        color: Int,
        radiusDp: Float,
        context: Context,
        strokeColor: Int = 0,
        strokeDp: Int = 0
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(context, radiusDp.toInt()).toFloat()
        if (strokeDp > 0) setStroke(dp(context, strokeDp), strokeColor)
    }

    /** Круг (swatch-и цветов, аватары). */
    fun circle(color: Int, context: Context, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokeDp > 0) setStroke(dp(context, strokeDp), strokeColor)
        }

    /** Панель bottom-sheet: скруглены только верхние углы (24dp). */
    fun roundedTop(color: Int, context: Context, radiusDp: Float = 24f): GradientDrawable {
        val r = dp(context, radiusDp.toInt()).toFloat()
        return GradientDrawable().apply {
            setColor(color)
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
    }

    /** Platform-ripple — подсветка нажатия для строк списков и пунктов меню. */
    fun ripple(context: Context): Drawable? {
        val outValue = TypedValue()
        context.theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
        return ContextCompat.getDrawable(context, outValue.resourceId)
    }

    // ----- Кнопки -----------------------------------------------------------------

    /**
     * Кнопка-иконка 40dp: векторная иконка + скруглённый ripple-фон.
     * Достаточная зона касания (44dp-стандарт) для пальца.
     */
    fun iconButton(
        context: Context,
        iconRes: Int,
        contentDesc: String,
        tint: Int,
        onClick: (View) -> Unit
    ): ImageButton = ImageButton(context).apply {
        setImageResource(iconRes)
        this.contentDescription = contentDesc
        background = rounded(0x00000000, 12f, context)
        imageTintList = android.content.res.ColorStateList.valueOf(tint)
        setPadding(dp(context, 8), dp(context, 8), dp(context, 8), dp(context, 8))
        val size = dp(context, 40)
        layoutParams = LinearLayout.LayoutParams(size, size)
        setOnClickListener { onClick(it) }
    }

    // ----- Типографика ------------------------------------------------------------

    /** Заголовок экрана. */
    fun title(context: Context, text: String, p: Palette, sizeSp: Float = 20f): TextView =
        TextView(context).apply {
            this.text = text
            textSize = sizeSp
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.text)
        }

    /** Подзаголовок/счётчик под заголовком. */
    fun subtitle(context: Context, text: String, p: Palette): TextView =
        TextView(context).apply {
            this.text = text
            textSize = 12f
            setTextColor(p.muted)
        }

    /** Капшен раздела (ТЕГИ / ЦВЕТ) — мелкий, разряженный, uppercase. */
    fun caption(context: Context, text: String, p: Palette): TextView =
        TextView(context).apply {
            this.text = text.uppercase()
            textSize = 10f
            letterSpacing = 0.08f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.muted)
        }

    /** Мелкий второстепенный текст. */
    fun hint(context: Context, text: String, p: Palette): TextView =
        TextView(context).apply {
            this.text = text
            textSize = 11f
            setTextColor(p.muted)
        }

    // ----- Чипы ---------------------------------------------------------------------

    /** Чип тега «#имя» (violet 15% подложка, как в веб-версии). */
    fun tagChip(context: Context, tag: String, p: Palette, onClick: (() -> Unit)? = null): TextView =
        TextView(context).apply {
            text = "#$tag"
            textSize = 11f
            setTextColor(p.primaryText)
            background = rounded(p.chipBg, 20f, context)
            setPadding(dp(context, 8), dp(context, 3), dp(context, 8), dp(context, 3))
            // Важно: у программно созданного View layoutParams == null, пока он
            // не добавлен в родителя. Как и остальные построители (divider,
            // colorSwatch, filterChip), назначаем дефолтные LP сразу — это
            // гарантирует, что любой вызов addView(chip) без явных параметров
            // не упадёт и чтение layoutParams вне дерева невозможно.
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            if (onClick != null) setOnClickListener { onClick() }
        }

    /** Чип активного фильтра с кнопкой сброса «✕». */
    fun filterChip(context: Context, label: String, p: Palette, onClear: () -> Unit): View =
        LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (p.dark) 0x1AFFFFFF.toInt() else 0x0F000000.toInt(), 20f, context)
            setPadding(dp(context, 10), dp(context, 4), dp(context, 4), dp(context, 4))
            addView(TextView(context).apply {
                text = label
                textSize = 12f
                setTextColor(p.text)
            })
            addView(TextView(context).apply {
                text = "✕"
                textSize = 12f
                setTextColor(p.muted)
                setPadding(dp(context, 8), dp(context, 2), dp(context, 6), dp(context, 2))
                setOnClickListener { onClear() }
            })
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(context, 6) }
        }

    /**
     * Радужная заливка (sweep-градиент по кругу) — свотч «Все» в фильтре
     * по цвету: визуально означает «любой цвет» и не путается с серым
     * свотчем «Без цвета» (палитра — цвета карточек из NoteColors.HEX).
     */
    fun rainbowFill(context: Context): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        gradientType = GradientDrawable.SWEEP_GRADIENT
        // Первый и последний цвет совпадают — круг замыкается без шва.
        setColors(intArrayOf(
            0xFFF43F5E.toInt(), // red
            0xFFF59E0B.toInt(), // amber
            0xFF84CC16.toInt(), // lime
            0xFF14B8A6.toInt(), // teal
            0xFF0EA5E9.toInt(), // blue
            0xFF8B5CF6.toInt(), // violet
            0xFFD946EF.toInt(), // fuchsia
            0xFFF43F5E.toInt()  // red (замыкание)
        ))
    }

    /**
     * Цветной swatch-кружок (выбор цвета, легенды). Выбор видно ВСЕГДА:
     * внешнее кольцо на расстоянии (gap) от заливки — у выбранного кольцо
     * толстое и фиолетовое, у остальных — тонкая рамка. Прежняя версия
     * рисовала обводку вплотную к заливке, и выбор «терялся».
     *
     * [rainbow] — свотч «Все» в фильтре по цвету: радужная заливка вместо
     * полупрозрачного круга (иначе он сливался с серым «Без цвета»).
     */
    fun colorSwatch(
        context: Context,
        colorKey: String?,
        selected: Boolean,
        p: Palette,
        sizeDp: Int = 28,
        rainbow: Boolean = false,
        onSelect: (String?) -> Unit
    ): View {
        val isDefault = colorKey == null || colorKey == "default"
        val fill: Drawable = when {
            rainbow && isDefault -> rainbowFill(context)
            isDefault -> circle(if (p.dark) 0x22FFFFFF.toInt() else 0x14000000.toInt(), context)
            else -> circle(NoteColors.accent(colorKey), context)
        }
        val gap = dp(context, 3)
        return FrameLayout(context).apply {
            // Внешнее кольцо: выбранное — 2dp primary, обычное — 1dp border.
            background = circle(0x00000000, context, if (selected) p.primary else p.border, dp(context, if (selected) 2 else 1))
            setPadding(gap, gap, gap, gap)
            contentDescription = when {
                rainbow && isDefault -> "Фильтр: все цвета"
                isDefault -> "Цвет: без цвета"
                else -> "Цвет: ${NoteColors.colorLabel(colorKey)}"
            }
            addView(View(context).apply {
                background = fill
            }, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            setOnClickListener { onSelect(colorKey) }
            layoutParams = LinearLayout.LayoutParams(dp(context, sizeDp), dp(context, sizeDp)).apply {
                marginEnd = dp(context, 8)
            }
        }
    }

    // ----- Пустые состояния ----------------------------------------------------------

    /** Экран «пусто»: большая иконка + заголовок + подсказка. */
    fun emptyState(context: Context, iconRes: Int, title: String, hint: String, p: Palette): View {
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(context, 32), dp(context, 48), dp(context, 32), dp(context, 48))
        }
        box.addView(ImageView(context).apply {
            setImageResource(iconRes)
            imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            alpha = 0.7f
            val s = dp(context, 44)
            layoutParams = LinearLayout.LayoutParams(s, s).apply { gravity = Gravity.CENTER }
        })
        box.addView(TextView(context).apply {
            text = title
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.text)
            gravity = Gravity.CENTER
            setPadding(0, dp(context, 12), 0, dp(context, 2))
        })
        box.addView(TextView(context).apply {
            text = hint
            textSize = 12f
            setTextColor(p.muted)
            gravity = Gravity.CENTER
        })
        return box
    }

    /** Панель-карточка: скруглённая подложка карточки + рамка + elevation. */
    fun card(context: Context, p: Palette, radiusDp: Float = 16f, stroke: Int? = null): LinearLayout =
        LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(p.card, radiusDp, context, stroke ?: p.border, if (p.dark) 1 else 1)
            elevation = dp(context, if (p.dark) 1 else 2).toFloat()
        }

    /** Тонкий разделитель внутри карточек/шитов. */
    fun divider(context: Context, p: Palette): View =
        View(context).apply {
            setBackgroundColor(p.border)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1)
            )
        }

    // ----- Даты -----------------------------------------------------------------

    /** Кэш форматов: построение SimpleDateFormat на каждую карточку дороже форматирования. */
    private val dateFormats = HashMap<String, java.text.SimpleDateFormat>()

    /**
     * Форматирование даты по русскоязычному паттерну с кэшем форматов
     * (все вызовы — с UI-потока; создание формата убрано из горячих путей
     * построения карточек/чипов).
     */
    fun formatDate(time: Long, pattern: String): String = try {
        val fmt = synchronized(dateFormats) {
            dateFormats.getOrPut(pattern) {
                java.text.SimpleDateFormat(pattern, java.util.Locale.forLanguageTag("ru"))
            }
        }
        fmt.format(java.util.Date(time))
    } catch (e: Exception) {
        ""
    }
}

/**
 * Edge-to-edge для targetSdk 35+ (Android 15): приложение ВСЕГДА рисуется
 * под системными панелями, а `adjustResize` больше не поднимает контент
 * над клавиатурой. Отступы status bar / navigation bar / вырезов накладываются
 * на контейнер `android.R.id.content`, цвет иконок статус-бара синхронизируется
 * с темой. Вызывается один раз в onCreate каждой активности.
 *
 * [imeTarget] — поведение при открытии клавиатуры:
 *  - null (по умолчанию) — весь контент поднимается над IME (стандарт);
 *  - переданный View (например, скролл с текстом в редакторе) получает
 *    отступ снизу на высоту перекрытия, а КОРЕНЬ не двигается — клавиатура
 *    ПЕРЕКРЫВАЕТ нижние панели (теги/ссылки/цвет в редакторе), как в live view,
 *    но набираемый текст остаётся видимым.
 *
 * [imeOverlay] — нижняя панель, которую клавиатура должна перекрывать.
 * ВАЖНО: панель обязана быть overlay-слоем (FrameLayout, gravity=BOTTOM)
 * ПОВЕРХ скролла, а не строкой вертикального LinearLayout — иначе при
 * сжатии окна она резервирует себе слот над клавиатурой, и после
 * translationY-компенсации этот слот остаётся пустой тёмной полосой
 * (жалоба «теги/цвет поднимаются чёрным цветом»).
 *
 * Требует пары настроек в активности (см. EditorActivity.onCreate):
 *  - API 30+: windowSoftInputMode = ADJUST_NOTHING + decorFitsSystemWindows(false)
 *    — окно НЕ сжимается и НЕ сдвигается, IME просто рисуется поверх;
 *  - высота клавиатуры определяется ДВУМЯ механизмами согласованно:
 *    insets (API 30+) и сжатие окна по GlobalLayout (манифестный adjustResize
 *    на API < 30, а также любая система, проигнорировавшая ADJUST_NOTHING).
 *    Панель при сжатии сдвигается translationY ровно на высоту сжатия —
 *    визуально уходит под клавиатуру; отступ скролла = ровно перекрытый
 *    размер (без двойной компенсации).
 *
 * [onImePaddingChanged] — вызывается, когда нижний отступ [imeTarget]
 * (высота клавиатуры) ИЗМЕНИЛСЯ: видимая область сжалась/расширилась —
 * редактор на этот момент подтягивает курсор над клавиатуру и пересчитывает
 * свою полосу прокрутки (без него сжатие области проходит незаметно).
 */
fun Activity.applyEdgeToEdgeInsets(
    imeTarget: View? = null,
    imeOverlay: View? = null,
    onImePaddingChanged: (() -> Unit)? = null
) {
    val content = findViewById<View>(android.R.id.content) ?: return

    val dark = Ui.isDark(this)
    WindowCompat.getInsetsController(window, content).isAppearanceLightStatusBars = !dark

    if (imeTarget == null) {
        ViewCompat.setOnApplyWindowInsetsListener(content) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // Клавиатура и навигационная панель не показываются одновременно —
            // берём максимум: сначала поднимаем контент над панелью, затем над IME.
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }
        return
    }

    // Режим редактора: клавиатура перекрывает нижнюю панель, поднимается
    // только область набора текста. covered/imeBottom — взаимоисключающие
    // источники высоты клавиатуры (resize против insets), оба пишутся на
    // главном потоке. imeTarget уже non-null (ранний return выше).
    val imePanel = imeOverlay ?: return

    var imeBottom = 0
    var covered = 0
    var fullHeight = 0 // высота окна без клавиатуры

    fun recomputeImePadding() {
        val panelH = imePanel.height.takeIf { it > 0 } ?: Ui.dp(this, 150)
        val pad = if (covered > 0) {
            // Окно сжалось: клавиатура заняла низ экрана, панель сдвинута
            // translationY за неё — над клавиатурой торчит только «хвост» панели.
            (panelH - covered).coerceAtLeast(0)
        } else {
            // Окно цело (ADJUST_NOTHING): панель лежит у нижнего края за IME.
            maxOf(panelH, imeBottom)
        }
        val prevPad = imeTarget.paddingBottom
        imeTarget.setPadding(0, 0, 0, pad)
        // Клавиатура открылась/закрылась — область просмотра изменилась.
        if (prevPad != pad) onImePaddingChanged?.invoke()
    }

    ViewCompat.setOnApplyWindowInsetsListener(content) { view, insets ->
        val bars = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
        imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
        recomputeImePadding()
        WindowInsetsCompat.CONSUMED
    }

    // Наблюдение за сжатием окна (adjustResize): API < 30 — единственный
    // источник высоты IME; на API 30+ с ADJUST_NOTHING covered остаётся 0
    // (панель неподвижна, клавиатуру перекрывает её сама).
    val root = content.rootView
    root.viewTreeObserver.addOnGlobalLayoutListener {
        if (root.height > fullHeight) fullHeight = root.height
        covered = (fullHeight - root.height).coerceAtLeast(0)
        // Панель уезжает вниз ровно на сжатие окна — визуально уходит под клавиатуру.
        imePanel.translationY = covered.toFloat()
        recomputeImePadding()
    }
}
