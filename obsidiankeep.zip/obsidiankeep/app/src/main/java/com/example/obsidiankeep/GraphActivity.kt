package com.example.obsidiankeep

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Экран графа связей: тулбар с возвратом и чипом-счётчиком узлов/рёбер +
 * [GraphView]. Клик по узлу открывает заметку в редакторе — как в
 * веб-live-view (клик по узлу графа → открытая заметка).
 *
 * UI построен целиком в коде. Все строковые литералы — русские.
 */
class GraphActivity : AppCompatActivity(), GraphView.OnNodeListener {

    private lateinit var stats: TextView
    private lateinit var graphView: GraphView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        applyEdgeToEdgeInsets()
    }

    override fun onResume() {
        super.onResume()
        // Сразу + после первого измерения view (rebuild безопасен при width=0).
        graphView.rebuild(isDark)
        graphView.post { graphView.rebuild(isDark) }
        updateStats()
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi(): View {
        val dark = isDark
        val p = pal
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
        }

        // Тулбар: назад + заголовок + счётчик узлов/связей (чип).
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
        }
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_back, "Назад", p.muted) { finish() })

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        header.addView(Ui.title(this, "Граф связей", p, 18f))
        header.addView(Ui.subtitle(this, "[[вики-ссылки]] между заметками", p))
        toolbar.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        stats = TextView(this).apply {
            textSize = 11.5f
            setTextColor(p.primaryText)
            background = Ui.rounded(p.chipBg, 20f, this@GraphActivity)
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        toolbar.addView(stats)
        root.addView(toolbar)

        graphView = GraphView(this).apply {
            onNodeListener = this@GraphActivity
        }
        root.addView(graphView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1f
        ))

        root.addView(TextView(this).apply {
            text = "Перетаскивайте узлы · тап по узлу открывает заметку"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            setPadding(0, dp(6), 0, dp(10))
        })
        return root
    }

    private fun updateStats() {
        stats.text = "${graphView.nodeCount()} узлов · ${graphView.edgeCount()} связей"
    }

    override fun onNodeTap(noteId: String) {
        val note = NotesStore.noteById(noteId) ?: return
        startActivity(Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_NOTE_ID, note.id)
        })
        Toast.makeText(this, note.title.ifBlank { "Без названия" }, Toast.LENGTH_SHORT).show()
    }
}
