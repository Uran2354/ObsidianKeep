package com.example.obsidiankeep

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.LeadingMarginSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.view.View
import android.widget.TextView

/**
 * Минимальный markdown → Spannable для режима «Чтение» в редакторе и
 * предпросмотра. Поддерживает то же подмножество синтаксиса, что и
 * веб-версия (MarkdownRenderer): заголовки, **жирный**, *курсив*,
 * `код`, ~~зачёркнутый~~, списки и чекбоксы, цитаты, [[вики-ссылки]]
 * и #теги — последние два кликабельны (как onOpenWikiLink/onTagClick
 * в веб-версии).
 *
 * Решение «в лоб»: построчная обработка + инлайн-спаны. Полноценный
 * парсер AST не нужен для одного пакета без внешних зависимостей.
 *
 * Все строковые литералы — русские.
 */
object Markdown {

    /**
     * Отрисовать markdown в [textView]. [onWikiLink] и [onTag] — обработчики
     * нажатий по [[вики-ссылкам]] и #тегам.
     */
    fun render(
        textView: TextView,
        md: String,
        dark: Boolean,
        onWikiLink: (title: String) -> Unit,
        onTag: (tag: String) -> Unit
    ) {
        val text = textColor(md, dark, onWikiLink, onTag)
        textView.text = text
        textView.movementMethod = LinkMovementMethod.getInstance()
        textView.highlightColor = Color.TRANSPARENT
    }

    private fun textColor(
        md: String,
        dark: Boolean,
        onWikiLink: (String) -> Unit,
        onTag: (String) -> Unit
    ): SpannableStringBuilder {
        val out = SpannableStringBuilder()
        val textColor = if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT
        val muted = if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT
        val accent = if (dark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT

        val lines = md.split('\n')
        var inCodeFence = false

        lines.forEachIndexed { index, rawLine ->
            if (index > 0) out.append('\n')
            val line = rawLine.trimEnd()

            // Заборы кода ``` — моноширинный блок.
            if (line.trim().startsWith("```")) {
                inCodeFence = !inCodeFence
                return@forEachIndexed
            }
            if (inCodeFence) {
                val start = out.length
                out.append(rawLine)
                out.setSpan(TypefaceSpanMono(), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                return@forEachIndexed
            }

            // Горизонтальная линия.
            if (Regex("^(-{3,}|\\*{3,}|_{3,})\\s*$").matches(line)) {
                out.append("──────────")
                return@forEachIndexed
            }

            // Заголовки #{1,6}.
            val heading = Regex("^(#{1,6})\\s+(.*)$").find(line)
            if (heading != null) {
                val level = heading.groupValues[1].length
                val start = out.length
                out.append(heading.groupValues[2])
                out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(
                    RelativeSizeSpan(when {
                        level == 1 -> 1.5f; level == 2 -> 1.3f; level == 3 -> 1.15f; else -> 1.05f
                    }),
                    start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                return@forEachIndexed
            }

            // Цитата.
            if (line.startsWith(">")) {
                val content = line.removePrefix(">").trim()
                val start = out.length
                out.append(inline(content, textColor, onWikiLink, onTag))
                out.setSpan(StyleSpan(Typeface.ITALIC), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(LeadingMarginSpan.Standard(0, 24), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(ForegroundColorSpanMuted(muted), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                return@forEachIndexed
            }

            // Список / чекбокс.
            val checkbox = Regex("^\\s*[-*+]\\s+\\[([ xX])]\\s*(.*)$").find(line)
            val bullet = Regex("^\\s*[-*+]\\s+(.*)$").find(line)
            val ordered = Regex("^\\s*(\\d+)\\.\\s+(.*)$").find(line)
            when {
                checkbox != null -> {
                    val done = checkbox.groupValues[1] == "x" || checkbox.groupValues[1] == "X"
                    val start = out.length
                    out.append(if (done) "☑ " else "☐ ")
                    out.append(inline(checkbox.groupValues[2], textColor, onWikiLink, onTag))
                    if (done) {
                        out.setSpan(
                            ForegroundColorSpanMuted(muted),
                            start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                    }
                    out.setSpan(LeadingMarginSpan.Standard(24), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                bullet != null -> {
                    val start = out.length
                    out.append("• ")
                    out.append(inline(bullet.groupValues[1], textColor, onWikiLink, onTag))
                    out.setSpan(LeadingMarginSpan.Standard(24), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                ordered != null -> {
                    val start = out.length
                    out.append("${ordered.groupValues[1]}. ")
                    out.append(inline(ordered.groupValues[2], textColor, onWikiLink, onTag))
                    out.setSpan(LeadingMarginSpan.Standard(24), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                line.isBlank() -> out.append("") // пустая строка
                else -> out.append(inline(line, textColor, onWikiLink, onTag))
            }
        }
        return out
    }

    /** Инлайн-разметка: [[вики]], #тег, **жирный**, `код`, ~~зачёркнутый~~, *курсив*.
     *  Обычный текст получает [textColor]; спец-спаны красят себя сами. */
    private fun inline(
        source: String,
        textColor: Int,
        onWikiLink: (String) -> Unit,
        onTag: (String) -> Unit
    ): SpannableStringBuilder {
        val out = SpannableStringBuilder()
        val accent = if (textColor == NoteColors.TEXT_DARK) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT
        val codeBg = 0x2EFFFFFF.toInt()

        // Пробегаем регулярками в порядке приоритета.
        val pattern = Regex(
            "\\[\\[([^\\[\\]#|]+?)(?:#[^\\[\\]]*)?(?:\\|[^\\[\\]]*)?\\]\\]" + // 1 вики
                "|(?:^|[\\s(>])(#[\\p{L}\\p{N}][\\p{L}\\p{N}_-]{0,31})" +      // 2 тег
                "|\\*\\*(.+?)\\*\\*" +                                          // 3 жирный
                "|`([^`]+)`" +                                                  // 4 код
                "|~~(.+?)~~" +                                                  // 5 зачёркнутый
                "|\\*([^*\\s][^*]*?)\\*"                                        // 6 курсив
        )
        var cursor = 0
        while (cursor < source.length) {
            val m = pattern.find(source, cursor)
            if (m == null) {
                val tailStart = out.length
                out.append(source.substring(cursor))
                out.setSpan(
                    android.text.style.ForegroundColorSpan(textColor),
                    tailStart, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                break
            }
            val plainStart = out.length
            out.append(source.substring(cursor, m.range.first))
            out.setSpan(
                android.text.style.ForegroundColorSpan(textColor),
                plainStart, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            val start = out.length
            when {
                m.groupValues[1].isNotEmpty() -> {
                    // [[вики-ссылка]] — акцентная, кликабельная.
                    val title = m.groupValues[1].trim()
                    out.append(title)
                    out.setSpan(
                        object : ClickableSpan() {
                            override fun onClick(widget: View) = onWikiLink(title)
                            override fun updateDrawState(ds: TextPaint) {
                                ds.color = accent
                                ds.isUnderlineText = true
                            }
                        },
                        start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                m.groupValues[2].isNotEmpty() -> {
                    // #тег — акцентный, кликабельный. Фикс ревью: альтернатива тега
                    // захватывает разделитель (^|[\s(>]) перед «#», и он терялся
                    // («Привет #тег» рендерился как «Привет#тег») — возвращаем его.
                    val tag = m.groupValues[2].substring(1).lowercase()
                    val separator = m.value.removeSuffix(m.groupValues[2])
                    out.append(separator)
                    out.append(m.groupValues[2])
                    out.setSpan(
                        object : ClickableSpan() {
                            override fun onClick(widget: View) = onTag(tag)
                            override fun updateDrawState(ds: TextPaint) {
                                ds.color = accent
                                ds.isUnderlineText = false
                                ds.typeface = Typeface.create(ds.typeface, Typeface.BOLD)
                            }
                        },
                        start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                m.groupValues[3].isNotEmpty() -> {
                    out.append(m.groupValues[3])
                    out.setSpan(StyleSpan(Typeface.BOLD), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                m.groupValues[4].isNotEmpty() -> {
                    out.append(m.groupValues[4])
                    out.setSpan(TypefaceSpanMono(), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    out.setSpan(
                        android.text.style.BackgroundColorSpan(codeBg),
                        start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                m.groupValues[5].isNotEmpty() -> {
                    out.append(m.groupValues[5])
                    out.setSpan(StrikethroughSpan(), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                m.groupValues[6].isNotEmpty() -> {
                    out.append(m.groupValues[6])
                    out.setSpan(StyleSpan(Typeface.ITALIC), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            cursor = m.range.last + 1
        }
        return out
    }

    /** Моноширинный спан (класс-обёртка, чтобы не тянуть TypefaceSpan с API-нюансами). */
    private class TypefaceSpanMono : SubscriptSpan() {
        override fun updateDrawState(tp: TextPaint) {
            tp.typeface = Typeface.MONOSPACE
        }
    }

    /** Мягкий серый цвет текста. */
    private class ForegroundColorSpanMuted(private val color: Int) :
        android.text.style.CharacterStyle() {
        override fun updateDrawState(tp: TextPaint) {
            tp.color = color
        }
    }
}
