package com.example.obsidiankeep

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Корзина ObsidianKeep — аналог trash-view веб-live-view:
 *  - список удалённых заметок с датой удаления и «осталось N дн.»
 *    (хранение 10 дней — как в веб-версии);
 *  - восстановить / удалить навсегда (с подтверждением);
 *  - «Очистить корзину» целиком (с подтверждением).
 *
 * UI построен целиком в коде (иконки — векторные res/drawable). Все
 * строковые литералы — русские.
 */
class TrashActivity : AppCompatActivity() {

    private lateinit var listColumn: LinearLayout
    private lateinit var countText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        applyEdgeToEdgeInsets()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                NotesStore.notes.collect { rebuild() }
            }
        }
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)
    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi(): View {
        val p = pal
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
        }

        // Тулбар: назад + заголовок + «Очистить корзину».
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_back, "Назад", p.muted) { finish() })
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(Ui.title(this, "Корзина", p, 18f))
        countText = Ui.subtitle(this, "", p)
        header.addView(countText)
        toolbar.addView(header)
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_trash, "Очистить корзину", p.danger) {
            confirmEmptyTrash()
        })
        root.addView(toolbar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(24))
        }
        listColumn = column
        scroll.addView(column)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1f
        ))
        return root
    }

    private fun rebuild() {
        val p = pal
        val column = listColumn
        column.removeAllViews()

        val trashed = NotesStore.query("trash")
        countText.text = "заметки удаляются через 10 дней · ${trashed.size}"
        if (trashed.isEmpty()) {
            column.addView(Ui.emptyState(this, R.drawable.ic_trash,
                "Корзина пуста", "Удалённые заметки хранятся здесь 10 дней.", p))
            return
        }

        val now = System.currentTimeMillis()
        trashed.forEach { note ->
            val deletedAt = note.deletedAt ?: now
            val daysLeft = (10L - (now - deletedAt) / (24L * 60 * 60 * 1000)).coerceAtLeast(0L)
            val locked = NotesStore.isNoteLocked(note)

            // Карточка: цветная подложка (как у живой заметки) + действия.
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(13), dp(11), dp(13), dp(11))
                background = Ui.rounded(
                    NoteColors.cardBackground(note.color, p.dark, Prefs(this@TrashActivity).isTintBright),
                    16f, this@TrashActivity,
                    NoteColors.cardBorder(note.color, Prefs(this@TrashActivity).isTintBright), 1
                )
                elevation = dp(2).toFloat()
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.topMargin = dp(8)
                layoutParams = lp
            }

            // Заголовок + иконка замка для защищённых.
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            if (locked) {
                titleRow.addView(ImageView(this).apply {
                    setImageResource(R.drawable.ic_lock)
                    imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
                }, LinearLayout.LayoutParams(dp(15), dp(15)).apply { marginEnd = dp(6) })
            }
            titleRow.addView(TextView(this).apply {
                text = note.title.ifBlank { "Без названия" }
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(p.text)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(titleRow)

            card.addView(TextView(this).apply {
                text = if (locked) {
                    "Защищённая заметка · содержимое зашифровано · удалена ${formatDate(deletedAt, "d MMM yyyy")}, осталось $daysLeft дн."
                } else {
                    "Удалена ${formatDate(deletedAt, "d MMM yyyy")} · осталось $daysLeft дн."
                }
                textSize = 11f
                setTextColor(p.muted)
                setPadding(0, dp(3), 0, dp(6))
            })

            // Действия: чипы «Восстановить» / «Удалить навсегда».
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(actionChip(R.drawable.ic_restore, "Восстановить", p.primaryText, p.chipBg) {
                confirmRestore(note)
            })
            actions.addView(actionChip(R.drawable.ic_trash, "Удалить навсегда", p.danger,
                android.graphics.Color.argb(0x1A, android.graphics.Color.red(p.danger),
                    android.graphics.Color.green(p.danger), android.graphics.Color.blue(p.danger))) {
                confirmDeleteForever(note)
            })
            card.addView(actions)
            column.addView(card)

            // Тап по карточке — то же восстановление (фикс ревью: раньше
            // предлагалось УДАЛИТЬ навсегда, что нелогично для тапа).
            card.setOnClickListener { confirmRestore(note) }
        }
    }

    /** Чип действия с иконкой. */
    private fun actionChip(iconRes: Int, label: String, textColor: Int, bg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
            background = Ui.rounded(bg, 20f, this@TrashActivity)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            layoutParams = lp
            setOnClickListener { onClick() }
        }

    /**
     * Восстановление из корзины. Заблокированную защищённую заметку нельзя
     * восстановить молча (restoreNote вернёт null) — сначала разблокируем
     * её папку, затем восстанавливаем.
     */
    private fun confirmRestore(note: Note) {
        if (NotesStore.isNoteLocked(note)) {
            val folder = NotesStore.folderById(note.folderId) ?: run {
                Toast.makeText(this, "Заметка защищена, но папка не найдена", Toast.LENGTH_LONG).show()
                return
            }
            FolderLock.showUnlock(
                this,
                folder,
                onUnlocked = { doRestore(note) }
            )
            return
        }
        doRestore(note)
    }

    private fun doRestore(note: Note) {
        val restored = NotesStore.restoreNote(note.id)
        Toast.makeText(
            this,
            if (restored != null) "Заметка восстановлена" else "Не удалось восстановить заметку",
            Toast.LENGTH_SHORT
        ).show()
        if (restored != null) {
            // Открыть восстановленную заметку — быстрый путь назад к работе.
            startActivity(Intent(this, EditorActivity::class.java).apply {
                putExtra(EditorActivity.EXTRA_NOTE_ID, note.id)
            })
        }
    }

    private fun confirmDeleteForever(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("Удалить навсегда?")
            .setMessage("«${note.title.ifBlank { "Без названия" }}» будет удалена без возможности восстановления.")
            .setPositiveButton("Удалить") { _, _ ->
                NotesStore.deleteForever(note.id)
                Toast.makeText(this, "Заметка удалена навсегда", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmEmptyTrash() {
        AlertDialog.Builder(this)
            .setTitle("Очистить корзину?")
            .setMessage("Все заметки в корзине будут удалены навсегда.")
            .setPositiveButton("Очистить") { _, _ ->
                val count = NotesStore.emptyTrash()
                Toast.makeText(this, "Удалено заметок: $count", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // formatDate делегирован в Ui.formatDate — общий кэш SimpleDateFormat.
    private fun formatDate(time: Long, pattern: String): String = Ui.formatDate(time, pattern)
}
