package com.example.obsidiankeep

import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

/**
 * Диалоги защиты папок: разблокировка (PIN **или** биометрия), установка
 * защиты, смена и снятие PIN. Используются из [MainActivity] (шторка папок)
 * и [EditorActivity] (открытие заметки защищённой папки, выбор папки).
 *
 * Политика (не хуже оригинала):
 *  - PIN — 4–16 цифр, хэш PBKDF2 в папке ([FolderPin]);
 *  - биометрия (отпечаток/лицо) разблокирует папку БЕЗ PIN, если на
 *    устройстве задан хотя бы один биометрический датчик;
 *  - 5 неверных вводов подряд — пауза 15 секунд (защита от перебора,
 *    которой в оригинале не было).
 *
 * Все строковые литералы — русские.
 */
object FolderLock {

    private const val MAX_ATTEMPTS = 5
    private const val COOLDOWN_MS = 15_000L

    /**
     * Весь крипто-код (PBKDF2 100 000 итераций, Keystore, AES) выполняется
     * ТОЛЬКО здесь — в фоновом однопоточном исполнителе. Раньше хэширование
     * PIN шло на главном потоке и подвешивало интерфейс на сотни миллисекунд
     * (жалоба пользователя на «зависание»). Результат возвращается на main.
     */
    private val cryptoExecutor: java.util.concurrent.Executor =
        java.util.concurrent.Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun runCrypto(
        status: TextView? = null,
        work: () -> Boolean,
        onResult: (Boolean) -> Unit
    ) {
        cryptoExecutor.execute {
            val ok = try {
                work()
            } catch (t: Throwable) {
                false
            }
            mainHandler.post {
                status?.visibility = TextView.GONE
                onResult(ok)
            }
        }
    }

    /** Есть ли на устройстве доступная биометрия (отпечаток/лицо). */
    fun biometricAvailable(activity: AppCompatActivity): Boolean =
        BiometricManager.from(activity)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS

    /** Показать системный BiometricPrompt и разблокировать папку при успехе. */
    fun unlockByBiometric(activity: AppCompatActivity, folder: Folder, onDone: (Boolean) -> Unit) {
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    // Разворачивание data-ключа (Keystore) — тоже в фоне.
                    runCrypto(work = { NotesStore.unlockFolderBiometric(folder.id) }) { ok -> onDone(ok) }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onDone(false)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Разблокировать папку")
            .setSubtitle("Папка «${folder.name}» защищена")
            .setNegativeButtonText("Отмена")
            .build()
        prompt.authenticate(info)
    }

    /**
     * Диалог разблокировки защищённой папки: поле PIN + (если доступна)
     * кнопка «Войти по отпечатку». При неверном PIN диалог не закрывается.
     * [onUnlocked] вызывается один раз; [onCancelled] — при отказе пользователя.
     */
    fun showUnlock(
        activity: AppCompatActivity,
        folder: Folder,
        onUnlocked: () -> Unit,
        onCancelled: () -> Unit = {}
    ) {
        var unlocked = false
        var dialog: AlertDialog? = null
        var attempts = 0
        val handler = Handler(Looper.getMainLooper())
        val status = TextView(activity).apply {
            textSize = 12f
            setTextColor(NoteColors.danger(isDark(activity)))
            setPadding(dp(activity, 4), dp(activity, 6), dp(activity, 4), 0)
            visibility = TextView.GONE
        }
        val input = EditText(activity).apply {
            hint = "PIN-код папки (${FolderPin.MIN_LENGTH}–${FolderPin.MAX_LENGTH} цифр)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(FolderPin.MAX_LENGTH))
            setSingleLine(true)
        }

        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 20), dp(activity, 8), dp(activity, 20), 0)
            addView(input)
            addView(status)
            if (biometricAvailable(activity)) {
                // Кнопка-чип «Войти по отпечатку» с иконкой замка.
                val biometric = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    background = Ui.rounded(NoteColors.chipBackground(isDark(activity)), 20f, activity)
                    setPadding(dp(activity, 14), dp(activity, 8), dp(activity, 14), dp(activity, 8))
                    isClickable = true
                    isFocusable = true
                    val iv = android.widget.ImageView(activity).apply {
                        setImageResource(R.drawable.ic_unlock)
                        imageTintList = android.content.res.ColorStateList.valueOf(
                            if (isDark(activity)) NoteColors.PRIMARY_SOFT_DARK else NoteColors.PRIMARY_SOFT_LIGHT
                        )
                    }
                    addView(iv, LinearLayout.LayoutParams(dp(activity, 16), dp(activity, 16)).apply {
                        marginEnd = dp(activity, 8)
                    })
                    addView(TextView(activity).apply {
                        text = "Войти по отпечатку"
                        textSize = 14f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(if (isDark(activity)) NoteColors.PRIMARY_SOFT_DARK else NoteColors.PRIMARY_SOFT_LIGHT)
                    })
                    setOnClickListener {
                        unlockByBiometric(activity, folder) { ok ->
                            if (ok) {
                                unlocked = true
                                dialog?.dismiss()
                                onUnlocked()
                            } else {
                                status.visibility = TextView.VISIBLE
                                status.text = "Биометрия не подтверждена"
                            }
                        }
                    }
                }
                addView(biometric, LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(activity, 14) })
            }
        }

        /** Проверить PIN; при успехе — закрыть диалог и сообщить наверх. */
        fun tryUnlock() {
            if (unlocked) return
            val pin = input.text?.toString().orEmpty()
            if (pin.isEmpty()) return
            // PBKDF2 — в фоне: интерфейс не подвисает, поле и кнопка заблокированы.
            status.visibility = TextView.VISIBLE
            status.text = "Проверка PIN…"
            val positive = dialog?.getButton(AlertDialog.BUTTON_POSITIVE)
            positive?.isEnabled = false
            input.isEnabled = false
            runCrypto(status, { NotesStore.unlockFolder(folder.id, pin) }) { ok ->
                positive?.isEnabled = true
                input.isEnabled = true
                if (ok) {
                    unlocked = true
                    dialog?.dismiss()
                    onUnlocked()
                } else {
                    attempts++
                    status.visibility = TextView.VISIBLE
                    if (attempts >= MAX_ATTEMPTS) {
                        status.text = "Слишком много попыток — подождите 15 секунд"
                        input.isEnabled = false
                        handler.postDelayed({
                            input.isEnabled = true
                            attempts = 0
                            status.visibility = TextView.GONE
                        }, COOLDOWN_MS)
                    } else {
                        status.text = "Неверный PIN (осталось попыток: ${MAX_ATTEMPTS - attempts})"
                    }
                }
            }
        }

        val dlg = AlertDialog.Builder(activity)
            .setTitle(folder.name)
            .setMessage("Папка защищена. Введите PIN или используйте биометрию.")
            .setView(container)
            .setPositiveButton("Разблокировать", null)
            .setNegativeButton("Отмена") { _, _ -> if (!unlocked) onCancelled() }
            .setOnCancelListener { if (!unlocked) onCancelled() }
            .create()
        // Переопределяем кнопку: при неверном PIN диалог остаётся открытым.
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener { tryUnlock() }
        }
        // «Разблокировать» также по Enter (actionDone).
        input.setOnEditorActionListener { _, _, _ -> tryUnlock(); true }
        dialog = dlg
        dlg.show()
    }

    /** Диалог установки защиты: PIN + подтверждение. */
    fun showProtect(activity: AppCompatActivity, folder: Folder, onProtected: () -> Unit) {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 20), dp(activity, 8), dp(activity, 20), 0)
        }
        val pin = pinInput(activity, "Придумайте PIN (4–16 цифр)")
        val confirm = pinInput(activity, "Повторите PIN")
        container.addView(pin)
        container.addView(confirm)
        container.addView(TextView(activity).apply {
            text = "Содержимое заметок папки будет зашифровано (AES + Keystore), " +
                "а вход — по PIN или отпечатку. Забытый PIN восстановить нельзя."
            textSize = 12f
            setTextColor(if (isDark(activity)) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            setPadding(0, dp(activity, 10), 0, 0)
        })

        val status = TextView(activity).apply {
            text = "Шифрование заметок папки…"
            textSize = 12f
            setTextColor(if (isDark(activity)) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            setPadding(0, dp(activity, 8), 0, 0)
            visibility = TextView.GONE
        }
        container.addView(status)

        val dlg = AlertDialog.Builder(activity)
            .setTitle("Защитить папку «${folder.name}»")
            .setView(container)
            .setPositiveButton("Защитить", null)
            .setNegativeButton("Отмена", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                val p = pin.text?.toString().orEmpty()
                val c = confirm.text?.toString().orEmpty()
                when {
                    !FolderPin.isValid(p) ->
                        Toast.makeText(activity, "PIN должен быть из ${FolderPin.MIN_LENGTH}–${FolderPin.MAX_LENGTH} цифр", Toast.LENGTH_LONG).show()
                    p != c ->
                        Toast.makeText(activity, "PIN-коды не совпадают", Toast.LENGTH_SHORT).show()
                    else -> {
                        // PBKDF2 + Keystore + перешифровка заметок — в фоне.
                        status.visibility = TextView.VISIBLE
                        val btn = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
                        btn.isEnabled = false
                        pin.isEnabled = false
                        confirm.isEnabled = false
                        runCrypto(status, { NotesStore.protectFolder(folder.id, p) }) { ok ->
                            btn.isEnabled = true
                            pin.isEnabled = true
                            confirm.isEnabled = true
                            if (ok) {
                                dlg.dismiss()
                                Toast.makeText(activity, "Папка защищена — она заблокирована до ввода PIN", Toast.LENGTH_LONG).show()
                                onProtected()
                            } else {
                                Toast.makeText(activity, "Не удалось защитить папку", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
        dlg.show()
    }

    /** Диалог смены PIN: старый + новый + подтверждение. */
    fun showChangePin(activity: AppCompatActivity, folder: Folder, onChanged: () -> Unit) {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 20), dp(activity, 8), dp(activity, 20), 0)
        }
        val old = pinInput(activity, "Текущий PIN")
        val newPin = pinInput(activity, "Новый PIN (4–16 цифр)")
        val confirm = pinInput(activity, "Повторите новый PIN")
        container.addView(old); container.addView(newPin); container.addView(confirm)

        val status = TextView(activity).apply {
            text = "Смена PIN…"
            textSize = 12f
            setTextColor(if (isDark(activity)) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            setPadding(0, dp(activity, 8), 0, 0)
            visibility = TextView.GONE
        }
        container.addView(status)

        val dlg = AlertDialog.Builder(activity)
            .setTitle("Сменить PIN — «${folder.name}»")
            .setView(container)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                val o = old.text?.toString().orEmpty()
                val n = newPin.text?.toString().orEmpty()
                val c = confirm.text?.toString().orEmpty()
                when {
                    !FolderPin.isValid(n) ->
                        Toast.makeText(activity, "Новый PIN должен быть из ${FolderPin.MIN_LENGTH}–${FolderPin.MAX_LENGTH} цифр", Toast.LENGTH_LONG).show()
                    n != c ->
                        Toast.makeText(activity, "Новые PIN-коды не совпадают", Toast.LENGTH_SHORT).show()
                    else -> {
                        status.visibility = TextView.VISIBLE
                        val btn = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
                        btn.isEnabled = false
                        runCrypto(status, { NotesStore.changeFolderPin(folder.id, o, n) }) { ok ->
                            btn.isEnabled = true
                            if (ok) {
                                dlg.dismiss()
                                Toast.makeText(activity, "PIN обновлён", Toast.LENGTH_SHORT).show()
                                onChanged()
                            } else {
                                Toast.makeText(activity, "Текущий PIN неверен", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
        dlg.show()
    }

    /** Диалог снятия защиты: нужен текущий PIN. */
    fun showUnprotect(activity: AppCompatActivity, folder: Folder, onUnprotected: () -> Unit) {
        val input = pinInput(activity, "Текущий PIN")
        val status = TextView(activity).apply {
            text = "Расшифровка заметок…"
            textSize = 12f
            setTextColor(if (isDark(activity)) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            setPadding(0, dp(activity, 8), 0, 0)
            visibility = TextView.GONE
        }
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 20), dp(activity, 8), dp(activity, 20), 0)
            addView(input)
            addView(status)
        }
        val dlg = AlertDialog.Builder(activity)
            .setTitle("Снять защиту — «${folder.name}»")
            .setMessage("Содержимое заметок будет расшифровано и сохранено открытым текстом.")
            .setView(container)
            .setPositiveButton("Снять защиту", null)
            .setNegativeButton("Отмена", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                val pin = input.text?.toString().orEmpty()
                status.visibility = TextView.VISIBLE
                val btn = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
                btn.isEnabled = false
                input.isEnabled = false
                runCrypto(status, { NotesStore.unprotectFolder(folder.id, pin) }) { ok ->
                    btn.isEnabled = true
                    input.isEnabled = true
                    if (ok) {
                        dlg.dismiss()
                        Toast.makeText(activity, "Защита снята", Toast.LENGTH_SHORT).show()
                        onUnprotected()
                    } else {
                        Toast.makeText(activity, "Неверный PIN", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        dlg.show()
    }

    // ----- Утилиты ------------------------------------------------------------

    /** Поле ввода PIN: цифры, скрытие, ограничение длины. */
    private fun pinInput(activity: AppCompatActivity, hint: String): EditText =
        EditText(activity).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(FolderPin.MAX_LENGTH))
            setSingleLine(true)
        }

    private fun dp(activity: AppCompatActivity, v: Int): Int =
        (v * activity.resources.displayMetrics.density).toInt()

    private fun isDark(activity: AppCompatActivity): Boolean =
        (activity.resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
}
