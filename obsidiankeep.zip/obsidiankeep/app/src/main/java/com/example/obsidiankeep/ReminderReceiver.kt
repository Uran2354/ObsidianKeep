package com.example.obsidiankeep

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * Приёмник будильника напоминания: показывает уведомление с заголовком
 * заметки; тап открывает [EditorActivity] с этой заметкой.
 *
 * Канал «reminders» создаётся лениво здесь же (и в [ObsidianKeepApp] —
 * на случай, если уведомления приходят раньше первого будильника).
 *
 * Все строковые литералы — русские.
 */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val noteId = intent.getStringExtra("noteId") ?: return
        val note = NotesStore.noteById(noteId)
        if (note == null || note.isTrashed || note.reminderAt == null) return
        if (note.reminderAt!! > System.currentTimeMillis() + 60_000) return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Напоминания",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = "Напоминания о заметках ObsidianKeep" }
            )
        }

        val open = Intent(context, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_NOTE_ID, note.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context,
            note.id.hashCode(),
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Заметка защищённой заблокированной папки: контент в памяти —
        // шифротекст; не «протекаем» — показываем обезличенный текст
        // (заголовок открыт, как в оригинале).
        val locked = NotesStore.isNoteLocked(note)
        val text = if (locked) {
            "Защищённая заметка — откройте и разблокируйте папку"
        } else {
            stripMarkdown(note.content, 160).ifBlank { "Откройте заметку" }
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(note.title.ifBlank { "Без названия" })
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        nm.notify(note.id.hashCode(), notification)
    }

    companion object {
        const val CHANNEL_ID = "reminders"
    }
}
