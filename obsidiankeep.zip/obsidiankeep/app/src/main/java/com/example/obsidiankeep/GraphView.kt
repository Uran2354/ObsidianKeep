package com.example.obsidiankeep

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Граф связей заметок — canvas-версия graph-view из веб-версии:
 *  - узлы = неудалённые заметки (цвет узла = цвет заметки, «default» — серый);
 *  - рёбра = [[вики-ссылки]] (цель ищется по точному заголовку без учёта регистра);
 *  - физика: отталкивание узлов, пружины по рёбрам, притяжение к центру,
 *    трение — симуляция останавливается, когда всё «успокоилось» (как
 *    остановка rAF в веб-версии);
 *  - перетаскивание узла пальцем, тап по узлу — открытие заметки.
 *
 * UI построен целиком в коде. Все строковые литералы — русские.
 */
class GraphView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface OnNodeListener {
        fun onNodeTap(noteId: String)
    }

    /** Обработчик тапа по узлу (в [GraphActivity] открывает редактор). */
    var onNodeListener: OnNodeListener? = null

    private data class Node(
        val id: String,
        val title: String,
        val color: Int,
        var x: Float,
        var y: Float,
        var vx: Float = 0f,
        var vy: Float = 0f,
        val degree: Int = 0
    )

    private val nodes = mutableListOf<Node>()
    private val edges = mutableListOf<Pair<Int, Int>>()

    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x40888890.toInt()
        strokeWidth = 2f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        // Фикс ревью: размер был в «сырых» пикселях (30f) — на разных плотностях
        // экрана подписи получались крошечными или гигантскими; теперь 12dp.
        textSize = 12f * resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
    }

    private var dragging: Node? = null
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var built = false

    /** Пересобрать граф из [NotesStore] (вызывается при изменении заметок). */
    fun rebuild(dark: Boolean) {
        nodes.clear()
        edges.clear()
        labelPaint.color = if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT

        // allNotes = true: граф строится по ВСЕМ заметкам, включая лежащие
        // в папках (без флага вид «all» без фильтров вернул бы только заметки
        // без папки — связи с ними потерялись бы).
        val notes = NotesStore.query("all", allNotes = true, sort = SortKey.UPDATED)
        // View может ещё не быть измерен (rebuild до первого layout) — берём безопасные центры.
        val cx = if (width > 0) width / 2f else 300f
        val cy = if (height > 0) height / 2f else 500f
        val spread = (min(width, height) / 4f).takeIf { it > 10f } ?: 120f
        val indexById = HashMap<String, Int>()
        notes.forEachIndexed { i, note ->
            indexById[note.id] = i
            val angle = Math.random() * 2 * Math.PI
            nodes.add(
                Node(
                    id = note.id,
                    title = note.title.ifBlank { "Без названия" },
                    color = if (note.color == "default") 0xFF8A8A94.toInt() else NoteColors.accent(note.color),
                    x = (cx + (cos(angle) * spread).toFloat()),
                    y = (cy + (sin(angle) * spread).toFloat()),
                    degree = 0
                )
            )
        }

        // Рёбра: [[цель]] → первая заметка с точным заголовком (как GET /api/graph).
        notes.forEachIndexed { i, note ->
            extractWikiLinks(note.content).forEach { target ->
                val j = notes.indexOfFirst { it.id != note.id && it.title.trim().lowercase() == target.trim().lowercase() }
                if (j >= 0) {
                    val key = if (i < j) i to j else j to i
                    if (!edges.contains(key)) {
                        edges.add(key)
                    }
                }
            }
        }

        // Степень узла влияет на радиус (как degree в GraphDataDTO).
        edges.forEach { (i, j) ->
            if (i < nodes.size) {
                val n = nodes[i]
                nodes[i] = n.copy(degree = n.degree + 1)
            }
            if (j < nodes.size) {
                val n = nodes[j]
                nodes[j] = n.copy(degree = n.degree + 1)
            }
        }
        built = true
        invalidate()
    }

    private fun cos(rad: Double): Double = kotlin.math.cos(rad)
    private fun sin(rad: Double): Double = kotlin.math.sin(rad)

    // ----- Физика -------------------------------------------------------------

    private var settled = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!built) return
        stepPhysics()
        drawEdges(canvas)
        drawNodes(canvas)
        if (!settled) postInvalidateOnAnimation()
    }

    private fun stepPhysics() {
        val maxSpeed = 14f
        var totalMovement = 0f

        // Отталкивание (кулон, ограниченный радиусом).
        for (i in nodes.indices) {
            for (j in i + 1 until nodes.size) {
                val a = nodes[i]
                val b = nodes[j]
                var dx = b.x - a.x
                var dy = b.y - a.y
                var dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                if (dist > 320f) continue
                val force = 5200f / (dist * dist)
                dx /= dist; dy /= dist
                a.vx -= dx * force; a.vy -= dy * force
                b.vx += dx * force; b.vy += dy * force
            }
        }

        // Пружины по рёбрам.
        edges.forEach { (i, j) ->
            val a = nodes[i]
            val b = nodes[j]
            var dx = b.x - a.x
            var dy = b.y - a.y
            val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
            val target = 150f
            val force = (dist - target) * 0.02f
            dx /= dist; dy /= dist
            a.vx += dx * force; a.vy += dy * force
            b.vx -= dx * force; b.vy -= dy * force
        }

        // Притяжение к центру + трение + интеграция.
        val cx = width / 2f
        val cy = height / 2f
        nodes.forEach { n ->
            if (n !== dragging) {
                n.vx += (cx - n.x) * 0.003f
                n.vy += (cy - n.y) * 0.003f
                n.vx *= 0.85f
                n.vy *= 0.85f
                val speed = sqrt(n.vx * n.vx + n.vy * n.vy)
                if (speed > maxSpeed) {
                    n.vx = n.vx / speed * maxSpeed
                    n.vy = n.vy / speed * maxSpeed
                }
                n.x += n.vx
                n.y += n.vy
                totalMovement += abs(n.vx) + abs(n.vy)
            }
            // Держим узлы в границах с отступом.
            n.x = n.x.coerceIn(50f, (width - 50f).coerceAtLeast(51f))
            n.y = n.y.coerceIn(50f, (height - 50f).coerceAtLeast(51f))
        }

        settled = totalMovement < 0.8f
    }

    private fun drawEdges(canvas: Canvas) {
        edges.forEach { (i, j) ->
            if (i < nodes.size && j < nodes.size) {
                canvas.drawLine(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y, edgePaint)
            }
        }
    }

    private fun drawNodes(canvas: Canvas) {
        val labelSize = 12f * resources.displayMetrics.density
        nodes.forEach { n ->
            val radius = 16f + min(n.degree, 6) * 2f
            nodePaint.color = n.color
            nodePaint.style = Paint.Style.FILL
            canvas.drawCircle(n.x, n.y, radius, nodePaint)
            // Подпись под узлом.
            labelPaint.textSize = labelSize
            val label = if (n.title.length > 18) n.title.take(17) + "…" else n.title
            canvas.drawText(label, n.x, n.y + radius + labelSize * 1.2f, labelPaint)
        }
    }

    /** Число рёбер (для статистики в [GraphActivity]). */
    fun edgeCount(): Int = edges.size

    /** Число узлов (для статистики в [GraphActivity]). */
    fun nodeCount(): Int = nodes.size

    private fun nodeAt(x: Float, y: Float): Node? =
        nodes.lastOrNull { n ->
            val radius = 16f + min(n.degree, 6) * 2f + 12f
            val dx = n.x - x
            val dy = n.y - y
            dx * dx + dy * dy <= radius * radius
        }

    // ----- Ввод ---------------------------------------------------------------

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                moved = false
                dragging = nodeAt(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.x - downX) > 6f || abs(event.y - downY) > 6f) moved = true
                dragging?.let { d ->
                    d.x = event.x
                    d.y = event.y
                    d.vx = 0f; d.vy = 0f
                    settled = false
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    nodeAt(event.x, event.y)?.let { n ->
                        onNodeListener?.onNodeTap(n.id)
                        return true
                    }
                }
                dragging = null
            }
            MotionEvent.ACTION_CANCEL -> dragging = null
        }
        return super.onTouchEvent(event)
    }
}
