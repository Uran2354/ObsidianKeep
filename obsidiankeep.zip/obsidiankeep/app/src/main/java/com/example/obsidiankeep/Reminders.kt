package com.example.obsidiankeep

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Планировщик напоминаний на AlarmManager.
 *
 * Решения:
 *  - Точные будильники (setExactAndAllowWhileIdle) — напоминание обязано
 *    сработать в указанную минуту. На Android 12+ требуется разрешение
 *    SCHEDULE_EXACT_ALARM; если его нет — тихий fallback на неточный
 *    будильник (напоминание придёт с небольшой задержкой, это лучше,
 *    чем падение SecurityException).
 *  - PendingIntent с FLAG_UPDATE_CURRENT — повторная установка на ту же
 *    заметку перезаписывает старый будильник.
 *
 * Все строковые литералы — русские.
 */
object Reminders {

    /**
     * Поставить (или заменить) будильник напоминания заметки.
     * Время в прошлом не планируется (пусть сработает в ближайший чек).
     */
    fun schedule(context: Context, note: Note) {
        val at = note.reminderAt ?: return
        if (at <= System.currentTimeMillis() - 30_000) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context, note.id)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        runCatching {
            if (canExact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }
    }

    /** Снять будильник напоминания (при очистке reminderAt / удалении). */
    fun cancel(context: Context, noteId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, noteId))
    }

    private fun pendingIntent(context: Context, noteId: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = "obsidiankeep.REMINDER"
            putExtra("noteId", noteId)
        }
        return PendingIntent.getBroadcast(
            context,
            noteId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
