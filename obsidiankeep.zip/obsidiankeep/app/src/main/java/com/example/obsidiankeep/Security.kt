package com.example.obsidiankeep

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Шифрование защищённых папок — перенос security/CryptoManager.kt оригинала
 * в плоский пакет (класс не зависит ни от Compose, ни от Room).
 *
 * Схема «как была» в оригинале:
 *  1. Мастер-ключ AES-256 генерируется ВНУТРИ Android Keystore и из него
 *     не извлекается — аппаратное хранилище (StrongBox/TEE, где есть).
 *  2. Для каждой защищённой папки создаётся случайный data-ключ (32 байта);
 *     им шифруется содержимое заметок (AES/GCM).
 *  3. Сам data-ключ хранится в JSON папки зашифрованным мастер-ключом
 *     Keystore ([encryptDataKey]/[decryptDataKey]) — содержимое защищено
 *     даже при компрометации notes.json на рутованном устройстве.
 *
 * PIN-коды папок ([hashPin]) хранятся как PBKDF2-HMAC-SHA256 (100 000
 * итераций, случайная соль) — восстановить PIN из хэша невозможно; сравнение
 * постоянным временем ([constantTimeEquals]) против timing-атак.
 *
 * Все строковые литералы ошибок — русские.
 */
object CryptoManager {

    private const val KEYSTORE_ALIAS = "obsidian_keep_master"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_LENGTH_BITS = 128

    /** Мастер-ключ Keystore: получить или создать (не извлекается из хранилища). */
    private fun getOrCreateMasterKey(): SecretKey {
        val keystore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        keystore.getKey(KEYSTORE_ALIAS, null)?.let { return it as SecretKey }
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        keyGen.init(
            KeyGenParameterSpec.Builder(
                KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return keyGen.generateKey()
    }

    /** Новый случайный data-ключ папки (32 байта). */
    fun generateDataKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }

    /** Обернуть data-ключ мастер-ключом Keystore (IV + шифротекст, Base64). */
    fun encryptDataKey(dataKey: ByteArray): String {
        val master = getOrCreateMasterKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, master)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(dataKey)
        return Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }

    /** Развернуть data-ключ (выбрасывает исключение, если Keystore недоступен). */
    fun decryptDataKey(encryptedKeyB64: String): ByteArray {
        val master = getOrCreateMasterKey()
        val combined = Base64.decode(encryptedKeyB64, Base64.NO_WRAP)
        val iv = combined.copyOfRange(0, GCM_IV_LENGTH)
        val encrypted = combined.copyOfRange(GCM_IV_LENGTH, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, master, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        return cipher.doFinal(encrypted)
    }

    /** Шифровать строку data-ключом папки (IV + шифротекст, Base64). */
    fun encrypt(plain: String, key: ByteArray): String {
        val iv = ByteArray(GCM_IV_LENGTH).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }

    /** Расшифровать строку data-ключом папки. */
    fun decrypt(b64: String, key: ByteArray): String {
        val combined = Base64.decode(b64, Base64.NO_WRAP)
        val iv = combined.copyOfRange(0, GCM_IV_LENGTH)
        val encrypted = combined.copyOfRange(GCM_IV_LENGTH, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }
}

/**
 * PIN-политика защищённых папок: хэширование, проверка, генерация соли.
 * Хэши хранятся в самой папке ([Folder.pinHash]/[Folder.pinSalt]).
 */
object FolderPin {

    const val MIN_LENGTH = 4
    const val MAX_LENGTH = 16

    /** Валиден ли PIN по форме: только цифры, 4–16 символов. */
    fun isValid(pin: String): Boolean =
        pin.length in MIN_LENGTH..MAX_LENGTH && pin.all { it.isDigit() }

    /** Новая случайная соль (16 байт, Base64). */
    fun newSalt(): String {
        val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** PBKDF2-HMAC-SHA256, 100 000 итераций, 256 бит — как в оригинале. */
    fun hashPin(pin: String, saltB64: String): String {
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val spec = PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }

    /** Постоянное по времени сравнение хэшей (защита от timing-атак). */
    fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) {
            result = result or (a[i].code xor b[i].code)
        }
        return result == 0
    }

    /** PIN верен для папки? (папка должна содержать pinHash+pinSalt) */
    fun verify(folder: Folder, pin: String): Boolean {
        val hash = folder.pinHash ?: return false
        val salt = folder.pinSalt ?: return false
        return constantTimeEquals(hashPin(pin, salt), hash)
    }
}
