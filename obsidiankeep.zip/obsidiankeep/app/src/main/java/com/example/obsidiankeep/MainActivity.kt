package com.example.obsidiankeep

import android.Manifest
import android.animation.LayoutTransition
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewParent
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Главный экран ObsidianKeep — визуально повторяет веб-live-view:
 *
 *  - верхняя панель: меню, заголовок раздела, «красивый выбор» сортировки
 *    (bottom-sheet со строками-опциями и цветными свотчами) и переключатель
 *    светлой/тёмной темы (иконки солнца/луны);
 *  - заметный поиск по заметкам (поле-пилюля с иконкой и кнопкой очистки,
 *    живой фильтр с дебаунсом 220 мс, как в вебе);
 *  - masonry-сетка карточек: цветная подложка (18% цвета), рамка, тень,
 *    чипы тегов, бейдж напоминания, звезда/булавка; ТАП ПО КАРТОЧКЕ
 *    открывает редактор (вся карточка — одна кликабельная поверхность),
 *    долгое нажатие — bottom-sheet действий;
 *  - шторка: быстрый поиск → Заметки → Избранное → Напоминания → Календарь
 *    → Граф связей → Теги → **Настройки** → Папки (прокручиваемый раздел
 *    со своей линией прокрутки; низ шторки фиксирован) → Корзина; активный
 *    пункт выделен фиолетовой подложкой, у папок — иконка замка и счётчик;
 *  - защита папок: тап по заблокированной папке → [FolderLock] (PIN или
 *    биометрия), разблокировка сбрасывается при сворачивании приложения.
 *
 * UI построен целиком в коде (иконки — векторные res/drawable). Все
 * строковые литералы — русские.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var drawerList: LinearLayout
    private lateinit var headerTitle: TextView
    private lateinit var headerSubtitle: TextView
    private lateinit var themeButton: ImageButton
    private lateinit var searchInput: EditText
    private lateinit var searchClear: ImageView
    private lateinit var filterChipsRow: HorizontalScrollView
    private lateinit var chipsRow: LinearLayout
    private lateinit var notesGrid: LinearLayout
    private lateinit var emptyBox: FrameLayout
    private lateinit var emptyText: TextView
    private lateinit var snackbarHost: FrameLayout

    // Шторка: фиксированный верх (drawerList), прокручиваемые папки
    // (drawerFolders) и фиксированный низ (drawerBottom).
    private lateinit var drawerFolders: LinearLayout
    private lateinit var drawerBottom: LinearLayout
    private lateinit var drawerSearchInput: EditText

    /** Защита от рекурсии при синхронизации двух поисковых полей. */
    private var syncingSearchFields = false

    /**
     * Источник активного запроса. Основное поле ищет ТОЛЬКО по заметкам
     * текущего списка (в папках не ищет), быстрый поиск шторки — по всем
     * заметкам И ПО ПАПКАМ тоже. Поля зеркалят текст, поэтому источник
     * запоминается отдельно (см. watcher'ы полей).
     */
    private var searchFromDrawer = false

    /** Секция совпавших папок под быстрым поиском (только в шторке). */
    private lateinit var drawerFolderMatches: LinearLayout

    /** Открытый bottom-sheet сортировки — пересобирается при выборе. */
    private var sortSheet: BottomSheetDialog? = null
    private var sortBox: LinearLayout? = null

    /** Текущий режим списка: «all» | «favorites» | «upcoming». */
    private var view: String = "all"

    private val searchHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        // Старая глобальная сортировка (до «своей у каждой папки») → в корень.
        prefs.migrateLegacySort()
        // Не запоминать место просмотра (просьба пользователя: «при выходе
        // чтобы Заметки открывал, а не где вышел»): новый запуск всегда
        // открывает корневой список «Заметки» — папка/тег/цвет из прошлой
        // сессии сбрасываются. Тема, подложка, сетка и сортировки остаются.
        // При пересоздании активити (поворот, возврат в живую задачу)
        // состояние НЕ сбрасываем — это не «выход».
        if (savedInstanceState == null) prefs.resetFilters()
        applyThemeMode()
        requestNotificationPermissionIfNeeded()

        setContentView(buildUi())
        applyEdgeToEdgeInsets()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    NotesStore.notes.collect { renderNotes() }
                }
                launch {
                    NotesStore.folders.collect { buildDrawer() }
                }
                launch {
                    // Разблокировка/блокировка папок меняет и списки, и шторку.
                    NotesStore.unlockedFolderIds.collect {
                        renderNotes()
                        buildDrawer()
                    }
                }
            }
        }
    }

    /** Разрешение уведомлений на Android 13+ (без него молчат напоминания). */
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    /** Тема из настроек (применяется и в [ObsidianKeepApp] при старте). */
    private fun applyThemeMode() {
        AppCompatDelegate.setDefaultNightMode(
            when (prefs.theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)
    private fun dp(v: Int): Int = Ui.dp(this, v)

    // ----- UI построен целиком в коде (без XML-лейаутов) ---------------------

    private fun buildUi(): View {
        val p = pal
        val root = DrawerLayout(this)

        // --- Контентная область ---
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
        }

        // Верхняя панель: меню | заголовок | сортировка | тема.
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_menu, "Открыть меню", p.muted) {
            drawerLayout.openDrawer(Gravity.START)
        })

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        headerTitle = Ui.title(this, "Заметки", p, 18f)
        headerSubtitle = Ui.subtitle(this, "", p)
        header.addView(headerTitle)
        header.addView(headerSubtitle)
        toolbar.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // «Красивый выбор» сортировки — bottom-sheet со строками и свотчами.
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_sort, "Сортировка и фильтры", p.muted) {
            showSortSheet()
        })

        // Переключатель светлой/тёмной темы (вместо прежней сортировки по цвету).
        themeButton = Ui.iconButton(this, R.drawable.ic_sun, "Переключить тему", p.muted) {
            toggleTheme()
        }
        toolbar.addView(themeButton)
        updateThemeIcon()
        content.addView(toolbar)

        // Поиск: заметная пилюля с иконкой лупы и кнопкой очистки.
        content.addView(buildSearchBar())

        // Активные фильтры (чипы со сбросом).
        chipsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        filterChipsRow = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipsRow)
            visibility = View.GONE
        }
        content.addView(filterChipsRow)

        // Сетка карточек: горизонтальный LinearLayout с N колонками,
        // каждая колонка — вертикальный LinearLayout (masonry-подход веб-версии).
        notesGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(2), dp(8), dp(96))
        }
        emptyText = TextView(this)
        emptyBox = FrameLayout(this).apply {
            visibility = View.GONE
            addView(emptyText)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(emptyBox)
                addView(notesGrid)
            })
        }
        content.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1f
        ))

        // FAB «создать заметку».
        val fab = FloatingActionButton(this).apply {
            contentDescription = "Создать заметку"
            setImageResource(R.drawable.ic_plus)
            imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(p.primary)
            setOnClickListener { createNoteAndOpen() }
        }
        val fabParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, dp(16), dp(20))
        }
        val fabHost = FrameLayout(this).apply {
            addView(content, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            addView(fab, fabParams)
        }
        snackbarHost = fabHost

        // --- Шторка навигации ---
        // Структура: фиксированный верх (логотип, быстрый поиск, пункты),
        // ПРОКРУЧИВАЕМЫЙ раздел папок со своей линией прокрутки и фиксированный
        // низ (корзина + подпись) — подпись «Вдохновлено…» больше не
        // проваливается вниз, сколько бы папок ни было создано.
        drawerList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(14), dp(10), dp(4))
        }
        drawerFolders = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val foldersScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(drawerFolders, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        drawerBottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(14))
        }
        // Секция совпавших папок быстрого поиска — переиспользуется между
        // пересборками шторки ([buildDrawer] вставляет её после поиска).
        drawerFolderMatches = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val drawerRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.card)
            addView(drawerList)
            addView(foldersScroll, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ))
            addView(drawerBottom)
        }
        val drawerParams = DrawerLayout.LayoutParams(dp(296), ViewGroup.LayoutParams.MATCH_PARENT).apply {
            gravity = Gravity.START
        }

        root.addView(fabHost, DrawerLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        root.addView(drawerRoot, drawerParams)

        drawerLayout = root
        buildDrawer()
        return root
    }

    /** Строка поиска: пилюля с иконкой лупы и кнопкой очистки (видна при вводе). */
    private fun buildSearchBar(): View {
        val p = pal
        val field = EditText(this).apply {
            hint = "Поиск по заметкам…"
            isSingleLine = true
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = null
            setPadding(dp(8), dp(9), dp(8), dp(9))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    searchClear.visibility =
                        if (s?.isNotEmpty() == true) View.VISIBLE else View.GONE
                    // Запрос введён в основное поле: поиск — только по заметкам
                    // текущего списка, папки не участвуют.
                    searchFromDrawer = false
                    // Зеркалим запрос в поле быстрого поиска шторки (без рекурсии).
                    if (!syncingSearchFields && ::drawerSearchInput.isInitialized) {
                        syncingSearchFields = true
                        drawerSearchInput.setText(s?.toString() ?: "")
                        syncingSearchFields = false
                    }
                    // Дебаунс 220 мс — как в веб-версии.
                    searchHandler.removeCallbacksAndMessages(null)
                    searchHandler.postDelayed({ renderNotes() }, 220)
                }
            })
        }
        searchInput = field

        val clear = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            contentDescription = "Очистить поиск"
            setPadding(dp(10), dp(10), dp(10), dp(10))
            visibility = View.GONE
            setOnClickListener {
                searchInput.setText("")
                renderNotes()
            }
        }
        searchClear = clear

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            // Исправление прежней версии: рамка задавалась без strokeWidth
            // и поле поиска было невидимым. Теперь пилюля нарисована явно.
            background = Ui.rounded(p.cardElevated, 24f, this@MainActivity, p.border, 1)
            setPadding(dp(10), 0, dp(4), 0)
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_search)
            imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            setPadding(dp(4), dp(8), dp(8), dp(8))
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(40)))
        row.addView(field, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(clear, LinearLayout.LayoutParams(dp(40), dp(40)))

        return FrameLayout(this).apply {
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(row, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
    }

    /** Солнце на тёмной теме (переключиться на светлую), луна — наоборот. */
    private fun updateThemeIcon() {
        val p = pal
        themeButton.setImageResource(if (p.dark) R.drawable.ic_sun else R.drawable.ic_moon)
        themeButton.imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
    }

    /** Светлая ↔ тёмная тема одним нажатием (как ThemeToggle в веб-версии). */
    private fun toggleTheme() {
        prefs.theme = if (isDark) "light" else "dark"
        applyThemeMode() // активити пересоздаётся автоматически
    }

    // ----- Шторка навигации ---------------------------------------------------

    /** Перестроить шторку (вызывается при старте и изменении папок). */
    private fun buildDrawer() {
        val p = pal
        drawerList.removeAllViews()

        // Логотип: фиолетовый квадрат с иконкой + название.
        val logo = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(2), dp(8), dp(10))
        }
        logo.addView(FrameLayout(this).apply {
            background = Ui.rounded(p.primary, 12f, this@MainActivity)
            val iv = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_note)
                imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            addView(iv, FrameLayout.LayoutParams(dp(40), dp(40)))
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
        logo.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "ObsidianKeep"
                textSize = 17f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(p.text)
            })
            addView(TextView(this@MainActivity).apply {
                text = "заметки и база знаний"
                textSize = 11f
                setTextColor(p.muted)
            })
        })
        drawerList.addView(logo)

        // Быстрый поиск прямо в шторке — ведёт тот же запрос, что и
        // основная пилюля: список за шторкой фильтруется на лету.
        drawerList.addView(buildDrawerSearch())

        // Секция совпавших папок (видна только при активном быстром поиске —
        // именно он, в отличие от основного поля, находит папки).
        drawerList.addView(drawerFolderMatches)

        // Пункты навигации. «Заметки» — заметки без папки (перемещённая в
        // папку заметка исчезает отсюда). НАСТРОЙКИ — сразу после «Теги».
        drawerList.addView(drawerItem("Заметки", R.drawable.ic_note, view == "all" && prefs.folderId == null) {
            view = "all"
            prefs.folderId = null
            onNavigate()
        })
        drawerList.addView(drawerItem("Избранное", R.drawable.ic_star_outline, view == "favorites") {
            view = "favorites"
            onNavigate()
        })
        drawerList.addView(drawerItem("Напоминания", R.drawable.ic_bell, view == "upcoming") {
            view = "upcoming"
            onNavigate()
        })
        drawerList.addView(drawerItem("Календарь", R.drawable.ic_calendar, false) {
            startActivity(Intent(this, CalendarActivity::class.java))
            drawerLayout.closeDrawer(Gravity.START)
        })
        drawerList.addView(drawerItem("Граф связей", R.drawable.ic_graph, false) {
            startActivity(Intent(this, GraphActivity::class.java))
            drawerLayout.closeDrawer(Gravity.START)
        })
        drawerList.addView(drawerItem("Теги", R.drawable.ic_tag, false) {
            startActivity(Intent(this, TagsActivity::class.java))
            drawerLayout.closeDrawer(Gravity.START)
        })
        // «Настройки» сразу после «Теги».
        drawerList.addView(drawerItem("Настройки", R.drawable.ic_settings, false) {
            showSettingsDialog()
        })

        // Раздел «Папки»: заголовок фиксирован, сами папки — в прокручиваемом
        // контейнере со своей линией прокрутки.
        drawerList.addView(sectionHeader("Папки", "Создать") { showCreateFolderDialog() })
        val folders = NotesStore.folders.value
        drawerFolders.removeAllViews()
        // Транзишен расступания ставится только на время перетаскивания —
        // после пересборки шторки его не оставляем.
        drawerFolders.layoutTransition = null
        if (folders.isEmpty()) {
            drawerFolders.addView(Ui.hint(this, "Папок пока нет", p).apply {
                setPadding(dp(16), dp(4), dp(12), dp(6))
            })
        }
        folders.forEach { folder ->
            val locked = NotesStore.isFolderLocked(folder.id)
            val protected = folder.isProtected
            val icon = when {
                protected && locked -> R.drawable.ic_lock
                protected -> R.drawable.ic_unlock
                else -> R.drawable.ic_folder
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(9))
                background = if (view == "all" && prefs.folderId == folder.id) {
                    Ui.rounded(p.chipBg, 12f, this@MainActivity)
                } else Ui.ripple(this@MainActivity)
                isClickable = true
                isFocusable = true
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                imageTintList = android.content.res.ColorStateList.valueOf(
                    if (protected) p.primary else p.muted
                )
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(10) })
            row.addView(TextView(this).apply {
                text = folder.name
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(p.text)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = NotesStore.noteCountIn(folder.id).toString()
                textSize = 11f
                setTextColor(p.muted)
                background = Ui.rounded(if (p.dark) 0x14FFFFFF.toInt() else 0x0D000000.toInt(), 12f, this@MainActivity)
                setPadding(dp(7), dp(2), dp(7), dp(2))
            })
            row.tag = folder.id
            row.setOnClickListener {
                // Тап по защищённой заблокированной папке — сначала разблокировка.
                if (NotesStore.isFolderLocked(folder.id)) {
                    promptUnlockFolder(folder)
                } else {
                    view = "all"
                    prefs.folderId = folder.id
                    onNavigate()
                }
            }
            // Ручной порядок папок: долгое нажатие поднимает строку в режим
            // перетаскивания (вверх/вниз по списку), а отпускание БЕЗ движения
            // открывает прежнюю шторку действий папки.
            val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
            var downRawX = 0f
            var downRawY = 0f
            var dragArmed = false
            val longPressRunnable = Runnable {
                dragArmed = true
                row.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                startFolderDrag(row)
            }
            row.setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        dragArmed = false
                        v.handler?.postDelayed(longPressRunnable, 450L)
                        false // обычный прокрут/тап остаются у ScrollView/строки
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val s = folderDragSession
                        when {
                            s != null && s.draggedView == v -> {
                                s.lastRawY = event.rawY
                                handleFolderDragMove(s)
                                true
                            }
                            !dragArmed && (
                                Math.abs(event.rawY - downRawY) > touchSlop ||
                                Math.abs(event.rawX - downRawX) > touchSlop
                                ) -> {
                                // Листает шторку (или закрывает её свайпом) —
                                // отменить долгий тап.
                                v.handler?.removeCallbacks(longPressRunnable)
                                false
                            }
                            else -> dragArmed // тащим: касание только наше
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.handler?.removeCallbacks(longPressRunnable)
                        val s = folderDragSession
                        when {
                            s != null && s.draggedView == v -> {
                                if (event.actionMasked == MotionEvent.ACTION_CANCEL && s.reflowing) {
                                    // Свой CANCEL от removeView внутри жеста — не ронять drag.
                                    true
                                } else {
                                    finishFolderDrag(
                                        s,
                                        openSheet = event.actionMasked == MotionEvent.ACTION_UP && !s.moved
                                    )
                                    true
                                }
                            }
                            // Долгий тап уже отработал — не дать UP стать кликом.
                            dragArmed -> true
                            else -> false
                        }
                    }
                    else -> false
                }
            }
            drawerFolders.addView(row)
        }

        // Фиксированный низ шторки: корзина и подпись всегда на месте.
        drawerBottom.removeAllViews()
        drawerBottom.addView(Ui.divider(this, p).also {
            (it.layoutParams as LinearLayout.LayoutParams).setMargins(dp(8), dp(8), dp(8), dp(8))
        })
        drawerBottom.addView(drawerItem("Корзина", R.drawable.ic_trash, false) {
            startActivity(Intent(this, TrashActivity::class.java))
            drawerLayout.closeDrawer(Gravity.START)
        })

        drawerBottom.addView(Ui.hint(this, "Markdown · вики-ссылки · теги\nВдохновлено Obsidian и Google Keep", p).apply {
            setPadding(dp(12), dp(10), dp(12), dp(2))
        })

        // Синхронизировать секцию совпавших папок с текущим запросом
        // (шторка могла пересобраться при изменении папок/навигации).
        updateFolderMatches()
    }

    /** Быстрый поиск в шторке: зеркало основного поля (тот же запрос, тот же дебаунс). */
    private fun buildDrawerSearch(): View {
        val p = pal
        val field = EditText(this).apply {
            hint = "Быстрый поиск…"
            isSingleLine = true
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(p.text)
            setHintTextColor(p.muted)
            background = null
            setPadding(dp(8), dp(8), dp(8), dp(8))
            // Начальное значение — текущий запрос (без запуска watcher'ов).
            syncingSearchFields = true
            setText(searchInput.text?.toString() ?: "")
            syncingSearchFields = false
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    if (syncingSearchFields) return
                    syncingSearchFields = true
                    // Основное поле само запустит дебаунс-рендер и обратную синхронизацию.
                    searchInput.setText(s?.toString() ?: "")
                    syncingSearchFields = false
                    // Запрос введён в БЫСТРЫЙ поиск: он ищет по всем заметкам
                    // и папкам тоже (в отличие от основного поля).
                    searchFromDrawer = true
                    updateFolderMatches()
                }
            })
            // «Поиск» на клавиатуре — закрыть шторку и показать результат.
            setOnEditorActionListener { _, _, _ ->
                drawerLayout.closeDrawer(Gravity.START)
                true
            }
        }
        drawerSearchInput = field

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(p.cardElevated, 22f, this@MainActivity, p.border, 1)
            setPadding(dp(10), 0, dp(6), 0)
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(4), dp(4), dp(4), dp(8)) }
            layoutParams = lp
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_search)
            imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            setPadding(dp(2), dp(7), dp(7), dp(7))
        }, LinearLayout.LayoutParams(dp(30), dp(36)))
        row.addView(field, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            contentDescription = "Очистить быстрый поиск"
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener {
                field.setText("")
                renderNotes()
            }
        }, LinearLayout.LayoutParams(dp(34), dp(36)))
        return row
    }

    /**
     * Секция «Папки» под быстрым поиском: папки, чьё имя содержит запрос.
     * Только для быстрого поиска шторки — основной поиск по заметкам папки
     * не трогает. Тап — открыть папку (заблокированную — сначала разблокировать).
     */
    private fun updateFolderMatches() {
        if (!::drawerSearchInput.isInitialized) return
        val box = drawerFolderMatches
        box.removeAllViews()
        val query = drawerSearchInput.text?.toString()?.trim().orEmpty()
        val matches = if (query.isEmpty()) emptyList() else NotesStore.folders.value
            .filter { it.name.lowercase().contains(query.lowercase()) }
        if (!searchFromDrawer || matches.isEmpty()) {
            box.visibility = View.GONE
            return
        }
        box.visibility = View.VISIBLE
        box.addView(Ui.caption(this, "Папки", pal).apply {
            setPadding(dp(12), dp(8), dp(12), dp(2))
        })
        matches.forEach { folder ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = Ui.ripple(this@MainActivity)
                isClickable = true
                isFocusable = true
            }
            row.addView(ImageView(this).apply {
                setImageResource(if (folder.isProtected) R.drawable.ic_lock else R.drawable.ic_folder)
                imageTintList = android.content.res.ColorStateList.valueOf(
                    if (folder.isProtected) pal.primary else pal.muted
                )
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(10) })
            row.addView(TextView(this).apply {
                text = folder.name
                textSize = 13.5f
                setTextColor(pal.text)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply {
                text = NotesStore.noteCountIn(folder.id).toString()
                textSize = 11f
                setTextColor(pal.muted)
            })
            row.setOnClickListener {
                if (NotesStore.isFolderLocked(folder.id)) {
                    promptUnlockFolder(folder)
                } else {
                    view = "all"
                    prefs.folderId = folder.id
                    onNavigate()
                }
            }
            box.addView(row)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Отложенные дебаунс-рендеры не должны держать активити после закрытия.
        searchHandler.removeCallbacksAndMessages(null)
        // Выход из приложения (Back/смахивание из недавних): забыть место
        // просмотра — следующий запуск откроет «Заметки». Пересоздание
        // активити (поворот) — не выход: состояние остаётся.
        if (isFinishing && ::prefs.isInitialized) prefs.resetFilters()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Смена системной темы / uiMode: активити НЕ пересоздаётся
        // (configChanges="uiMode" в манифесте) — пересобираем UI на месте.
        if (::searchInput.isInitialized) rethemeInPlace()
    }

    private fun onNavigate() {
        searchFromDrawer = false
        prefs.tagFilter = null
        prefs.colorFilter = null
        buildDrawer()
        renderNotes()
        drawerLayout.closeDrawer(Gravity.START)
    }

    /** Пункт шторки: иконка + подпись, активный — фиолетовая подложка. */
    private fun drawerItem(label: String, iconRes: Int, active: Boolean, onClick: () -> Unit): View {
        val p = pal
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = if (active) {
                Ui.rounded(p.chipBg, 12f, this@MainActivity)
            } else Ui.ripple(this@MainActivity)
            isClickable = true
            isFocusable = true
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                imageTintList = android.content.res.ColorStateList.valueOf(
                    if (active) p.primary else p.muted
                )
            }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginEnd = dp(12) })
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 14f
                setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (active) p.primary else p.text)
            })
            setOnClickListener { onClick() }
        }
    }

    private fun sectionHeader(label: String, actionLabel: String, onAction: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(4))
            addView(Ui.caption(this@MainActivity, label, pal).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = "+ $actionLabel"
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(pal.primary)
                setPadding(dp(8), dp(4), dp(4), dp(4))
                setOnClickListener { onAction() }
            })
        }

    // ----- Список заметок -------------------------------------------------------

    /**
     * Scope сортировки и ручного порядка текущего списка: сортировка —
     * СВОЯ У КАЖДОГО СПИСКА (просьба пользователя): корень, каждая папка
     * и избранное настраиваются независимо.
     */
    private fun sortScope(): String = when {
        view == "favorites" -> "favorites"
        view == "upcoming" -> "upcoming"
        else -> prefs.folderId ?: "root"
    }

    /** Человекочитаемое имя scope — подзаголовок в шторке сортировки. */
    private fun sortScopeTitle(): String = when (val s = sortScope()) {
        "root" -> "Заметки без папки"
        "favorites" -> "Избранное"
        "upcoming" -> "Напоминания"
        else -> NotesStore.folderById(s)?.name ?: "Папка"
    }

    private fun renderNotes() {
        // Данные изменились ПОСРЕДИ перетаскивания (редкий emit из хранилища):
        // корректно завершить drag — иначе пересборка сетки оставит поднятую
        // карточку висеть в воздухе без потока касаний. finishCardDrag сам
        // вызовет renderNotes() повторно, к этому моменту session уже null.
        dragSession?.let { finishCardDrag(it, openSheet = false) }
        val p = pal
        val folderId = prefs.folderId.takeIf { view == "all" }
        val queryText = searchInput.text?.toString()?.trim().orEmpty()
        val notes = NotesStore.query(
            view = view,
            folderId = folderId,
            tag = prefs.tagFilter,
            color = prefs.colorFilter,
            q = queryText,
            // Основное поле ищет только по заметкам текущего списка;
            // быстрый поиск шторки — по всем заметкам и папкам тоже.
            folderScope = !searchFromDrawer,
            sort = prefs.sortKeyFor(sortScope())
        )

        // Заголовок.
        val query = queryText
        val sweepActive = prefs.tagFilter != null || prefs.colorFilter != null || query.isNotEmpty()
        headerTitle.text = when {
            view == "favorites" -> "Избранное"
            view == "upcoming" -> "Напоминания"
            folderId != null -> NotesStore.folderById(folderId)?.name ?: "Папка"
            else -> "Заметки"
        }
        headerSubtitle.text = when {
            view == "favorites" -> "Избранные заметки · ${notes.size}"
            view == "upcoming" -> "Запланировано · ${notes.size}"
            folderId != null -> "В папке · ${notes.size}"
            sweepActive -> "Найдено: ${notes.size}"
            else -> "Заметки без папки · ${notes.size}"
        }

        // Чипы активных фильтров.
        chipsRow.removeAllViews()
        val hasFilters = prefs.tagFilter != null || prefs.colorFilter != null ||
            (searchInput.text?.toString()?.trim()?.isNotEmpty() == true)
        filterChipsRow.visibility = if (hasFilters) View.VISIBLE else View.GONE
        prefs.tagFilter?.let { chipsRow.addView(Ui.filterChip(this, "#$it", p) {
            prefs.tagFilter = null; renderNotes(); buildDrawer()
        }) }
        prefs.colorFilter?.let {
            chipsRow.addView(Ui.filterChip(this, "Цвет: ${NoteColors.colorLabel(it)}", p) {
                prefs.colorFilter = null; renderNotes(); buildDrawer()
            })
        }

        // Пусто?
        val emptyView = when {
            view == "favorites" -> Ui.emptyState(this, R.drawable.ic_star_outline,
                "Нет избранного", "Отмечайте важные заметки звёздочкой.", p)
            view == "upcoming" -> Ui.emptyState(this, R.drawable.ic_bell,
                "Напоминаний нет", "Откройте заметку и задайте дату с временем.", p)
            query.isNotEmpty() -> Ui.emptyState(this, R.drawable.ic_search,
                "Ничего не найдено", "По запросу «$query» заметок нет.", p)
            else -> Ui.emptyState(this, R.drawable.ic_note,
                "Здесь пока пусто", "Создайте первую заметку — она появится в сетке.", p)
        }
        emptyBox.removeAllViews()
        emptyBox.addView(emptyView)
        emptyBox.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
        notesGrid.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE

        // Сетка: 2 колонки (обычная) / 3 (компактная).
        notesGrid.removeAllViews()
        if (notes.isEmpty()) return
        val columns = if (prefs.isCompactGrid) 3 else 2
        val columnViews = (0 until columns).map {
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                }
            }
        }
        notes.forEachIndexed { index, note ->
            columnViews[index % columns].addView(buildNoteCard(note))
        }
        columnViews.forEach { notesGrid.addView(it) }
    }

    /**
     * Карточка заметки: корень — FrameLayout, вся поверхность которого
     * кликабельна (тап открывает редактор, долгое — действия). Внутренний
     * контейнер не «съедает» касания: клик guaranteed доходит до корня.
     */
    private fun buildNoteCard(note: Note): View {
        val p = pal
        val card = FrameLayout(this).apply {
            // Цветная подложка (насыщенная по умолчанию) + рамка цвета карточки.
            background = Ui.rounded(
                NoteColors.cardBackground(note.color, p.dark, prefs.isTintBright),
                16f, this@MainActivity,
                NoteColors.cardBorder(note.color, prefs.isTintBright), 1
            )
            elevation = dp(2).toFloat()
            isClickable = true
            isFocusable = true
            foreground = Ui.ripple(this@MainActivity)
            setOnClickListener { openEditor(note.id) }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(10)) }
        }

        // Ручной порядок: долгое нажатие поднимает карточку в режим
        // перетаскивания (движение пальца двигает её по сетке), а
        // отпускание БЕЗ движения открывает прежнюю шторку действий.
        // В «Напоминаниях» перетаскивания нет (порядок задаёт время).
        card.tag = note.id
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawY = 0f
        var dragArmed = false
        val longPressRunnable = Runnable {
            dragArmed = true
            card.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (view == "upcoming") showNoteSheet(note) else startCardDrag(card)
        }
        card.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    dragArmed = false
                    v.handler?.postDelayed(longPressRunnable, 450L)
                    false // обычный прокрут/тап остаются у ScrollView/карточки
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = dragSession
                    when {
                        s != null && s.draggedView == v -> {
                            s.lastRawX = event.rawX
                            s.lastRawY = event.rawY
                            handleCardDragMove(s)
                            true
                        }
                        !dragArmed && Math.abs(event.rawY - downRawY) > touchSlop -> {
                            // Пользователь просто листает список — отменить долгий тап.
                            v.handler?.removeCallbacks(longPressRunnable)
                            false
                        }
                        else -> dragArmed // тащим: касание только наше
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.handler?.removeCallbacks(longPressRunnable)
                    val s = dragSession
                    when {
                        s != null && s.draggedView == v -> {
                            if (event.actionMasked == MotionEvent.ACTION_CANCEL && s.reflowing) {
                                // Свой CANCEL от removeView внутри жеста — не ронять drag.
                                true
                            } else {
                                finishCardDrag(
                                    s,
                                    openSheet = event.actionMasked == MotionEvent.ACTION_UP && !s.moved
                                )
                                true
                            }
                        }
                        // Долгий тап уже отработал (шторка открыта) — не дать
                        // UP превратиться в клик «открыть редактор».
                        dragArmed -> true
                        else -> false
                    }
                }
                else -> false
            }
        }

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }

        // Папка + пин/звезда.
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val folderLabel = NotesStore.folderLabel(note)
        if (folderLabel != null) {
            top.addView(TextView(this).apply {
                text = folderLabel.uppercase()
                textSize = 8.5f
                letterSpacing = 0.08f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(p.muted)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        } else {
            top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        }
        if (note.isPinned) {
            top.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_pin)
                imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            }, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginStart = dp(4) })
        }
        if (note.isFavorite) {
            top.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_star)
                imageTintList = android.content.res.ColorStateList.valueOf(0xFFF59E0B.toInt())
            }, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginStart = dp(6) })
        }
        body.addView(top)

        // Заголовок.
        body.addView(TextView(this).apply {
            text = note.title.ifBlank { "Без названия" }
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(p.text)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(5)
            layoutParams = lp
        })

        // Превью контента / плашка защиты.
        if (NotesStore.isNoteLocked(note)) {
            body.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.topMargin = dp(4)
                layoutParams = lp
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_lock)
                    imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
                }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { marginEnd = dp(5) })
                addView(TextView(this@MainActivity).apply {
                    text = "Защищённая заметка"
                    textSize = 12f
                    setTextColor(p.muted)
                })
            })
        } else {
            val excerpt = stripMarkdown(note.content, 220)
            if (excerpt.isNotEmpty()) {
                body.addView(TextView(this).apply {
                    text = excerpt
                    textSize = 12f
                    setTextColor(p.muted)
                    maxLines = 8
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.topMargin = dp(4)
                    layoutParams = lp
                })
            }
        }

        // Теги + напоминание.
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        note.tags.take(3).forEach { tag ->
            chips.addView(Ui.tagChip(this, tag, p) {
                view = "all"
                prefs.folderId = null
                prefs.tagFilter = tag
                renderNotes()
                buildDrawer()
            }.also { chipView ->
                // Чип создан программно и ещё не добавлен в родителя — его
                // layoutParams == null. Никогда не читаем его, а назначаем
                // свежие LinearLayout.LayoutParams (иначе NPE, см. отчёт о краше).
                chipView.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(4) }
            })
        }
        if (note.tags.size > 3) {
            chips.addView(TextView(this).apply {
                text = "+${note.tags.size - 3}"
                textSize = 10f
                setTextColor(p.muted)
                setPadding(dp(4), 0, dp(4), 0)
            })
        }
        note.reminderAt?.let { at ->
            chips.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(p.chipBg, 20f, this@MainActivity)
                setPadding(dp(7), dp(2), dp(8), dp(2))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_bell)
                    imageTintList = android.content.res.ColorStateList.valueOf(p.primaryText)
                }, LinearLayout.LayoutParams(dp(11), dp(11)).apply { marginEnd = dp(4) })
                addView(TextView(this@MainActivity).apply {
                    text = formatDate(at, "d MMM, HH:mm")
                    textSize = 10f
                    setTextColor(p.primaryText)
                })
            }.also { badge ->
                // Аналогично: badge ещё не в дереве — layoutParams == null.
                badge.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(4) }
            })
        }
        body.addView(chips)

        // Дата внизу справа.
        body.addView(TextView(this).apply {
            text = formatDate(note.updatedAt, "d MMM yyyy")
            textSize = 10f
            setTextColor(p.muted)
            gravity = Gravity.END
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
        })

        card.addView(body)
        return card
    }

    // ----- Drag&drop карточек (ручной порядок заметок) ---------------------------

    /** Активное перетаскивание карточки (null — сейчас ничего не тащат). */
    private var dragSession: CardDragSession? = null

    private val dragHandler = Handler(Looper.getMainLooper())

    private class CardDragSession(
        val scope: String,
        val grid: ViewGroup,
        val scroll: ScrollView?,
        val draggedView: View,
        val columns: Int,
        var lastCol: Int,
        var lastPos: Int,
        var moved: Boolean = false,
        var lastRawX: Float = 0f,
        var lastRawY: Float = 0f,
        /** true, пока handleCardDragMove сам переставляет карточку (remove/add
         *  внутри активного жеста) — CANCEL, прилетевший в этот момент, свой,
         *  перетаскивание продолжается. */
        var reflowing: Boolean = false
    )

    /** Автопрокрутка списка, пока карточку держат у верхнего/нижнего края. */
    private val dragAutoScroll = object : Runnable {
        override fun run() {
            val s = dragSession ?: return
            val scroll = s.scroll
            if (scroll != null && s.lastRawY > 0f) {
                val loc = IntArray(2)
                scroll.getLocationOnScreen(loc)
                val relY = s.lastRawY - loc[1]
                val edge = dp(56)
                val delta = when {
                    relY < edge -> -((edge - relY).toInt().coerceAtLeast(dp(8)))
                    relY > scroll.height - edge -> (relY - (scroll.height - edge)).toInt().coerceAtLeast(dp(8))
                    else -> 0
                }
                if (delta != 0) {
                    scroll.smoothScrollBy(0, delta * 2)
                    handleCardDragMove(s) // карточки уехали под неподвижный палец
                }
            }
            dragHandler.postDelayed(this, 24L)
        }
    }

    /** Поднять карточку в режим перетаскивания (вызывается по долгому тапу). */
    private fun startCardDrag(card: View) {
        val p = pal
        val grid = notesGrid
        if (grid.childCount == 0) return
        var scroll: ScrollView? = null
        var parent: ViewParent? = card.parent
        while (parent != null) {
            if (parent is ScrollView) { scroll = parent; break }
            parent = (parent as? View)?.parent
        }
        // Текущий слот (колонка, позиция вставки среди ЧУЖИХ карточек) —
        // чтобы первый MOVE над тем же местом не считался перемещением.
        // pos считается так же, как в handleCardDragMove (сама карточка
        // исключается из списка), поэтому для карточки с индексом idx это
        // idx + 1 — иначе первый же MOVE даёт фиктивную перестановку «на
        // то же место», moved=true и шторка перестаёт открываться.
        var col = 0; var pos = 0
        for (i in 0 until grid.childCount) {
            val colView = grid.getChildAt(i) as? ViewGroup ?: continue
            val idx = colView.indexOfChild(card)
            if (idx >= 0) { col = i; pos = idx + 1; break }
        }
        dragSession = CardDragSession(
            scope = sortScope(),
            grid = grid,
            scroll = scroll,
            draggedView = card,
            columns = if (prefs.isCompactGrid) 3 else 2,
            lastCol = col,
            lastPos = pos
        )
        // ScrollView не должен перехватывать касание — теперь им управляет карточка.
        card.parent?.requestDisallowInterceptTouchEvent(true)
        card.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.95f).setDuration(100).start()
        card.elevation = dp(10).toFloat()
        // ЖИВАЯ ДИНАМИКА (просьба «чтобы было видно куда»): соседи плавно
        // расступаются (слот под карточку виден во время движения), а поднятая
        // карточка подсвечивается рамкой акцентного цвета. Транзишен ставится
        // ТОЛЬКО на время перетаскивания и уходит вместе с пересборкой сетки.
        val dragNote = (card.tag as? String)?.let { NotesStore.noteById(it) }
        if (dragNote != null) {
            card.background = Ui.rounded(
                NoteColors.cardBackground(dragNote.color, p.dark, prefs.isTintBright),
                16f, this, p.primary, 2
            )
        }
        for (i in 0 until grid.childCount) {
            (grid.getChildAt(i) as? ViewGroup)?.layoutTransition = LayoutTransition().apply {
                disableTransitionType(LayoutTransition.APPEARING)
                disableTransitionType(LayoutTransition.DISAPPEARING)
                disableTransitionType(LayoutTransition.CHANGE_APPEARING)
                disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
                enableTransitionType(LayoutTransition.CHANGING)
                setDuration(140)
            }
        }
        dragHandler.post(dragAutoScroll)
    }

    /** Двигать карточку за пальцем: вычислить слот и переставить view. */
    private fun handleCardDragMove(s: CardDragSession) {
        val grid = s.grid
        val loc = IntArray(2)
        grid.getLocationOnScreen(loc)
        val gx = s.lastRawX - loc[0]
        val colW = (grid.width / s.columns).coerceAtLeast(1)
        val col = (gx / colW).toInt().coerceIn(0, s.columns - 1)
        val column = grid.getChildAt(col) as? ViewGroup ?: return
        // Вставка перед первым чужим ребёнком, чей центр ниже пальца.
        var pos = column.childCount
        for (i in 0 until column.childCount) {
            val child = column.getChildAt(i)
            if (child == s.draggedView) continue
            val c = IntArray(2)
            child.getLocationOnScreen(c)
            if (s.lastRawY < c[1] + child.height / 2f) { pos = i; break }
        }
        if (col == s.lastCol && pos == s.lastPos) return
        // pos посчитан по исходным индексам (с самой карточкой в списке):
        // если карточка в этой же колонке и стоит ВЫШЕ цели — после её
        // удаления индекс вставки сдвигается на 1 влево.
        val oldParent = s.draggedView.parent as? ViewGroup
        val sameColumn = oldParent === column
        val oldIdx = if (sameColumn) oldParent?.indexOfChild(s.draggedView) ?: -1 else -1
        var insertAt = pos
        if (sameColumn && oldIdx in 0 until pos) insertAt = (pos - 1).coerceAtLeast(0)
        s.reflowing = true
        oldParent?.removeView(s.draggedView)
        column.addView(s.draggedView, insertAt.coerceIn(0, column.childCount))
        s.reflowing = false
        s.lastCol = col
        s.lastPos = pos
        s.moved = true
        // Тактильный тик на каждый новый слот — «куда упадёт» чувствуется.
        s.draggedView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    /**
     * Завершить перетаскивание: палец не двигался — открыть шторку действий
     * (прежнее поведение долгого тапа); двигался — сохранить новый порядок
     * и переключить сортировку списка на «Вручную».
     */
    private fun finishCardDrag(s: CardDragSession, openSheet: Boolean) {
        dragHandler.removeCallbacks(dragAutoScroll)
        dragSession = null
        s.draggedView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
        s.draggedView.elevation = dp(2).toFloat()
        if (openSheet) {
            // Пересобрать сетку: снять с карточки подъём (масштаб/рамку перетаскивания).
            renderNotes()
            val note = (s.draggedView.tag as? String)?.let { NotesStore.noteById(it) }
            if (note != null) showNoteSheet(note)
            return
        }
        persistManualOrder(s.scope, deriveGridOrderIds(s.grid))
        val switched = prefs.sortKeyFor(s.scope) != SortKey.MANUAL
        prefs.setSortKeyFor(s.scope, SortKey.MANUAL)
        renderNotes()
        if (switched) Toast.makeText(this, "Порядок сохранён · сортировка «Вручную»", Toast.LENGTH_SHORT).show()
    }

    /** Плоский порядок карточек сетки: колонки читаются round-robin (как строятся). */
    private fun deriveGridOrderIds(grid: ViewGroup): List<String> {
        // ВАЖНО: mapNotNull получает ИНДЕКС, нужен именно getChildAt(it) —
        // «it as? ViewGroup» на Int всегда null (порядок не сохранялся бы вовсе).
        val cols = (0 until grid.childCount).mapNotNull { i -> grid.getChildAt(i) as? ViewGroup }
        val rows = cols.maxOfOrNull { it.childCount } ?: 0
        val ids = mutableListOf<String>()
        for (r in 0 until rows) for (c in cols.indices) {
            if (r < cols[c].childCount) (cols[c].getChildAt(r).tag as? String)?.let(ids::add)
        }
        return ids
    }

    /**
     * Слить новый порядок видимых карточек с полным порядком scope:
     * заметки, скрытые фильтром/поиском, сохраняют свои слоты, новые
     * (которых в сохранённом порядке не было) — дописываются в конец.
     */
    private fun persistManualOrder(scope: String, visibleOrder: List<String>) {
        if (visibleOrder.isEmpty()) return
        val full = NotesStore.manualOrder(scope)
        val visibleSet = visibleOrder.toSet()
        var vi = 0
        val merged = mutableListOf<String>()
        full.forEach { id -> if (visibleSet.contains(id)) merged.add(visibleOrder[vi++]) else merged.add(id) }
        merged.addAll(visibleOrder.drop(vi))
        NotesStore.setManualOrder(scope, merged)
    }

    // ----- Drag&drop папок в шторке (ручной порядок) ------------------------------

    /** Активное перетаскивание строки папки (null — сейчас ничего не тащат). */
    private var folderDragSession: FolderDragSession? = null

    private class FolderDragSession(
        val draggedView: View,
        var lastRawY: Float = 0f,
        var moved: Boolean = false,
        /** true, пока handleFolderDragMove сам переставляет строку
         *  (remove/add внутри активного жеста) — CANCEL, прилетевший в этот
         *  момент, свой, перетаскивание продолжается. */
        var reflowing: Boolean = false
    )

    /** Поднять строку папки в режим перетаскивания (вызывается по долгому тапу). */
    private fun startFolderDrag(row: View) {
        if (drawerFolders.childCount < 2) {
            // Переставлять нечего — долгий тап ведёт себя по-старому: шторка папки.
            (row.tag as? String)?.let { id -> NotesStore.folderById(id)?.let(::showFolderSheet) }
            return
        }
        val p = pal
        folderDragSession = FolderDragSession(row)
        // ScrollView шторки не должен перехватывать касание — теперь им управляет строка.
        row.parent?.requestDisallowInterceptTouchEvent(true)
        row.animate().scaleX(1.02f).scaleY(1.02f).alpha(0.96f).setDuration(100).start()
        row.elevation = dp(8).toFloat()
        // ЖИВАЯ ДИНАМИКА, как у карточек: соседи плавно расступаются (видно,
        // куда встанет строка), поднятая строка — с рамкой акцентного цвета.
        row.background = Ui.rounded(p.chipBg, 12f, this, p.primary, 2)
        drawerFolders.layoutTransition = LayoutTransition().apply {
            disableTransitionType(LayoutTransition.APPEARING)
            disableTransitionType(LayoutTransition.DISAPPEARING)
            disableTransitionType(LayoutTransition.CHANGE_APPEARING)
            disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
            enableTransitionType(LayoutTransition.CHANGING)
            setDuration(140)
        }
    }

    /** Двигать строку папки за пальцем: вычислить слот и переставить view. */
    private fun handleFolderDragMove(s: FolderDragSession) {
        val list = drawerFolders
        val row = s.draggedView
        val from = list.indexOfChild(row)
        if (from < 0) return
        // Вставка перед первым ЧУЖИМ ребёнком, чей ЦЕНТР НИЖЕ пальца
        // (палец выше центра) — как hit-test карточек.
        var target = list.childCount
        for (i in 0 until list.childCount) {
            if (i == from) continue
            val child = list.getChildAt(i)
            val c = IntArray(2)
            child.getLocationOnScreen(c)
            if (s.lastRawY < c[1] + child.height / 2f) { target = i; break }
        }
        // target посчитан по исходным индексам (с самой строкой в списке):
        // если строка стоит ВЫШЕ цели — после её удаления индекс сдвигается на 1.
        var insertAt = target
        if (from < target) insertAt = target - 1
        if (insertAt == from) return
        s.reflowing = true
        list.removeView(row)
        list.addView(row, insertAt.coerceIn(0, list.childCount))
        s.reflowing = false
        s.moved = true
        // Тактильный тик на каждый новый слот — «куда упадёт» чувствуется.
        row.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    /**
     * Завершить перетаскивание папки: палец не двигался — открыть шторку
     * действий папки (прежнее поведение долгого тапа); двигался — сохранить
     * новый порядок (folders.json хранит папки массивом — порядок списка и
     * есть сохранённый порядок; шторку пересоберёт folders.collect).
     */
    private fun finishFolderDrag(s: FolderDragSession, openSheet: Boolean) {
        folderDragSession = null
        drawerFolders.layoutTransition = null
        s.draggedView.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
        s.draggedView.elevation = 0f
        if (openSheet) {
            // Пересобрать шторку: снять с строки подъём (масштаб/рамку перетаскивания).
            buildDrawer()
            (s.draggedView.tag as? String)?.let { id ->
                NotesStore.folderById(id)?.let(::showFolderSheet)
            }
            return
        }
        val ids = (0 until drawerFolders.childCount)
            .mapNotNull { i -> drawerFolders.getChildAt(i).tag as? String }
        NotesStore.setFolderOrder(ids)
    }

    // ----- Bottom-sheets (красивые выборы вместо PopupMenu) -----------------------

    /** Каркас bottom-sheet: ручка + контейнер на приподнятой карточке. */
    private fun sheetContainer(): LinearLayout {
        val p = pal
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.roundedTop(p.cardElevated, this@MainActivity)
            setPadding(dp(8), dp(10), dp(8), dp(14))
        }
    }

    private fun sheetHandle(parent: LinearLayout) {
        parent.addView(View(this).apply {
            background = Ui.rounded(if (pal.dark) 0x33FFFFFF.toInt() else 0x1A000000.toInt(), 2f, this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
    }

    private fun sheetTitle(parent: LinearLayout, text: String) {
        parent.addView(Ui.title(this, text, pal, 16f).apply {
            setPadding(dp(12), dp(10), dp(12), dp(4))
        })
    }

    /** Строка bottom-sheet с иконкой, подписью, описанием и опциональной галкой. */
    private fun sheetRow(
        parent: LinearLayout,
        iconRes: Int,
        label: String,
        description: String? = null,
        selected: Boolean = false,
        danger: Boolean = false,
        onClick: () -> Unit
    ) {
        val p = pal
        val color = when {
            danger -> p.danger
            selected -> p.primary
            else -> p.text
        }
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = Ui.ripple(this@MainActivity)
            isClickable = true
            isFocusable = true
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                imageTintList = android.content.res.ColorStateList.valueOf(
                    if (danger) p.danger else if (selected) p.primary else p.muted
                )
            }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginEnd = dp(14) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@MainActivity).apply {
                    text = label
                    textSize = 14f
                    setTypeface(typeface, if (selected) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(color)
                })
                if (description != null) {
                    addView(TextView(this@MainActivity).apply {
                        text = description
                        textSize = 11f
                        setTextColor(p.muted)
                    })
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (selected) {
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_check)
                    imageTintList = android.content.res.ColorStateList.valueOf(p.primary)
                }, LinearLayout.LayoutParams(dp(18), dp(18)))
            }
            setOnClickListener { onClick() }
        })
    }

    /**
     * «Красивый выбор» сортировки и цвета: bottom-sheet с четырьмя
     * вариантами сортировки (иконка + подпись + галка) и свотчами цветов
     * карточки. Подсветка и галочка обновляются СРАЗУ при выборе — шторка
     * остаётся открытой и пересобирается с новым состоянием.
     */
    private fun showSortSheet() {
        val dialog = BottomSheetDialog(this)
        sortSheet = dialog
        val box = sheetContainer()
        sortBox = box
        rebuildSortSheet()
        dialog.setContentView(box)
        dialog.setOnDismissListener { sortSheet = null; sortBox = null }
        dialog.show()
    }

    /** Пересобрать содержимое шторки сортировки с текущим состоянием. */
    private fun rebuildSortSheet() {
        val box = sortBox ?: return
        val p = pal
        box.removeAllViews()
        sheetHandle(box)
        sheetTitle(box, "Сортировка")

        val descriptions = mapOf(
            SortKey.UPDATED to "сначала изменённые недавно",
            SortKey.CREATED to "сначала созданные недавно",
            SortKey.TITLE to "по заголовку А→Я",
            SortKey.REMINDER to "ближайшие напоминания",
            SortKey.MANUAL to "свой порядок — зажми карточку и перетащи"
        )
        val icons = mapOf(
            SortKey.UPDATED to R.drawable.ic_edit,
            SortKey.CREATED to R.drawable.ic_note,
            SortKey.TITLE to R.drawable.ic_text,
            SortKey.REMINDER to R.drawable.ic_bell,
            SortKey.MANUAL to R.drawable.ic_list
        )
        // Сортировка теперь У КАЖДОГО СПИСКА своя — показываем, какой именно.
        box.addView(Ui.hint(this, "Для: ${sortScopeTitle()} · у каждой папки свой порядок", p).apply {
            setPadding(dp(14), 0, dp(12), dp(6))
        })
        val currentSort = prefs.sortKeyFor(sortScope())
        SortKey.values().forEach { key ->
            sheetRow(box, icons.getValue(key), key.label, descriptions.getValue(key), key == currentSort) {
                prefs.setSortKeyFor(sortScope(), key)
                renderNotes()
                rebuildSortSheet() // живая подсветка с галочкой
            }
        }

        // Импорт .md — между сортировкой и фильтром по цвету (по просьбе:
        // «добавь импорт md после сортировки и перед фильтром по цвету»).
        box.addView(Ui.divider(this, p).also {
            (it.layoutParams as LinearLayout.LayoutParams).setMargins(dp(12), dp(8), dp(12), dp(8))
        })
        sheetRow(box, R.drawable.ic_note, "Импорт .md", "Создать заметки из Markdown-файлов") {
            sortSheet?.dismiss()
            importMdLauncher.launch(arrayOf("*/*"))
        }

        box.addView(Ui.divider(this, p).also {
            (it.layoutParams as LinearLayout.LayoutParams).setMargins(dp(12), dp(8), dp(12), dp(8))
        })
        box.addView(Ui.caption(this, "Цвет карточки", pal).apply {
            setPadding(dp(14), 0, dp(12), dp(6))
        })

        // Ряд свотчей: «любой цвет» (радужный) + 8 цветов; активный фильтр обведён.
        // ВАЖНО: normalizeColor(null) == "default" (серый), поэтому признак
        // «фильтр вообще включён» считается отдельно — иначе при фильтре «Все»
        // подсвечивался и серый свотч одновременно (жалоба пользователя).
        // Старые ключи (green/pink) нормализуются — подсветка не теряется.
        val hasColorFilter = prefs.colorFilter != null
        val activeColor = normalizeColor(prefs.colorFilter)
        val swatchRow = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val swatches = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(2), dp(12), dp(6))
        }
        swatches.addView(Ui.colorSwatch(this, null, !hasColorFilter, p, 32, rainbow = true) {
            prefs.colorFilter = null
            renderNotes(); buildDrawer()
            rebuildSortSheet() // выбор цвета видно сразу
        })
        NOTE_COLOR_KEYS.forEach { key ->
            swatches.addView(Ui.colorSwatch(this, key, hasColorFilter && activeColor == key, p, 32) {
                prefs.colorFilter = if (prefs.colorFilter == key) null else key
                renderNotes(); buildDrawer()
                rebuildSortSheet()
            })
        }
        swatchRow.addView(swatches)
        box.addView(swatchRow)
        box.addView(Ui.hint(this, "Фильтр показывает заметки выбранного цвета", p).apply {
            setPadding(dp(14), dp(2), dp(12), 0)
        })
    }

    /** Действия по заметке: избранное, закрепление, папка, экспорт, цвет, корзина. */
    private fun showNoteSheet(note: Note) {
        val dialog = BottomSheetDialog(this)
        val box = sheetContainer()
        sheetHandle(box)
        sheetTitle(box, note.title.ifBlank { "Без названия" })

        sheetRow(box, if (note.isFavorite) R.drawable.ic_star else R.drawable.ic_star_outline,
            if (note.isFavorite) "Убрать из избранного" else "В избранное") {
            dialog.dismiss()
            NotesStore.updateNote(note.id, isFavorite = !note.isFavorite)
            renderNotes()
        }
        sheetRow(box, R.drawable.ic_pin, if (note.isPinned) "Открепить" else "Закрепить") {
            dialog.dismiss()
            NotesStore.updateNote(note.id, isPinned = !note.isPinned)
            renderNotes()
        }
        // Перемещение в папку прямо из списка (долгое нажатие).
        sheetRow(box, R.drawable.ic_folder, "Переместить в папку…") {
            dialog.dismiss()
            showMoveToFolderDialog(note)
        }
        // Экспорт .md — то же окно «Поделиться», что и в редакторе.
        sheetRow(box, R.drawable.ic_link, "Экспорт (.md)") {
            dialog.dismiss()
            exportNote(note)
        }
        // Копировать весь текст заметки в буфер обмена (без окна «Поделиться»).
        sheetRow(box, R.drawable.ic_copy, "Копировать текст") {
            dialog.dismiss()
            val target = NotesStore.noteById(note.id)
            if (target == null || NotesStore.isNoteLocked(target)) {
                // Контент заблокированной заметки в памяти — шифротекст.
                Toast.makeText(this, "Заметка защищена — сначала разблокируйте её папку", Toast.LENGTH_LONG).show()
            } else {
                val text = (target.title + "\n\n" + target.content).trim()
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText(target.title.ifBlank { "Заметка" }, text))
                Toast.makeText(this, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        }
        sheetRow(box, R.drawable.ic_palette, "Цвет…") {
            dialog.dismiss()
            showColorSheet(note)
        }
        sheetRow(box, R.drawable.ic_trash, "В корзину", danger = true) {
            dialog.dismiss()
            trashWithUndo(note)
        }

        dialog.setContentView(box)
        dialog.show()
    }

    /**
     * Переместить заметку в другую папку (или вынуть из текущей — «Без папки»).
     * Выбор заблокированной защищённой папки — сначала разблокировка [FolderLock].
     */
    private fun showMoveToFolderDialog(note: Note) {
        if (NotesStore.isNoteLocked(note)) {
            Toast.makeText(this, "Заметка защищена — сначала разблокируйте её папку", Toast.LENGTH_LONG).show()
            return
        }
        val folders = NotesStore.folders.value
        val items = mutableListOf("Без папки") + folders.map {
            it.name + if (it.isProtected) " · защищена" else ""
        }
        val checked = folders.indexOfFirst { it.id == note.folderId } + 1
        AlertDialog.Builder(this)
            .setTitle("Переместить в папку")
            .setSingleChoiceItems(items.toTypedArray(), checked) { dialog, which ->
                val target = if (which == 0) null else folders[which - 1]
                if (target != null && NotesStore.isFolderLocked(target.id)) {
                    dialog.dismiss()
                    FolderLock.showUnlock(
                        this,
                        target,
                        onUnlocked = { moveNoteToFolder(note.id, target.id) }
                    )
                    return@setSingleChoiceItems
                }
                dialog.dismiss()
                moveNoteToFolder(note.id, target?.id, clear = which == 0)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Применить перемещение и обновить списки (счётчики папок тоже). */
    private fun moveNoteToFolder(noteId: String, folderId: String?, clear: Boolean = folderId == null) {
        val moved = NotesStore.updateNote(noteId, folderId = folderId, clearFolder = clear)
        if (moved == null) {
            Toast.makeText(this, "Не удалось переместить заметку", Toast.LENGTH_SHORT).show()
        } else {
            val label = NotesStore.folderById(moved.folderId)?.name
            Toast.makeText(
                this,
                if (label == null) "Заметка вынута из папки" else "Перемещено в «$label»",
                Toast.LENGTH_SHORT
            ).show()
        }
        renderNotes()
        buildDrawer()
    }

    /** Экспорт .md из списка — системное окно «Поделиться» РЕАЛЬНЫМ файлом. */
    private fun exportNote(note: Note) {
        val target = NotesStore.noteById(note.id) ?: return
        if (NotesStore.isNoteLocked(target)) {
            // Контент заблокированной заметки в памяти — шифротекст: делиться им нельзя.
            Toast.makeText(this, "Заметка защищена — сначала разблокируйте её папку", Toast.LENGTH_LONG).show()
            return
        }
        // «Экспорт (.md)» теперь буквально ФАЙЛ (FileProvider, EXTRA_STREAM):
        // его можно сохранить на Диск, приложить к письму, отправить в чат —
        // раньше шёл только текст, и часть приложений файл не принимала.
        if (!NoteShare.shareFile(this, target)) {
            Toast.makeText(this, "Не удалось создать файл для экспорта", Toast.LENGTH_LONG).show()
        }
    }

    /** Выбор цвета карточки: свотчи с обводкой у выбранного. */
    private fun showColorSheet(note: Note) {
        val p = pal
        val box = sheetContainer()
        sheetHandle(box)
        sheetTitle(box, "Цвет карточки")

        val swatchRow = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val swatches = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(4), dp(12), dp(10))
        }
        NOTE_COLOR_KEYS.forEach { key ->
            swatches.addView(Ui.colorSwatch(this, key, key == note.color, p, 32) { picked ->
                NotesStore.updateNote(note.id, color = picked ?: "default")
                renderNotes()
            })
        }
        swatchRow.addView(swatches)
        box.addView(swatchRow)
        box.addView(Ui.hint(this, "Сейчас: ${NoteColors.colorLabel(note.color)}", p).apply {
            setPadding(dp(14), dp(2), dp(12), dp(6))
        })

        BottomSheetDialog(this).apply {
            setContentView(box)
            show()
        }
    }

    /** Действия по папке (долгое нажатие в шторке). */
    private fun showFolderSheet(folder: Folder) {
        val locked = NotesStore.isFolderLocked(folder.id)
        val box = sheetContainer()
        sheetHandle(box)
        sheetTitle(box, folder.name)

        sheetRow(box, R.drawable.ic_edit, "Переименовать") { showRenameFolderDialog(folder) }
        if (!folder.isProtected) {
            sheetRow(box, R.drawable.ic_lock, "Защитить папку…") {
                FolderLock.showProtect(this, folder) {
                    buildDrawer()
                    renderNotes()
                }
            }
        } else {
            if (locked) sheetRow(box, R.drawable.ic_unlock, "Разблокировать…") {
                promptUnlockFolder(folder)
            }
            sheetRow(box, R.drawable.ic_lock, "Сменить PIN…") {
                if (locked) {
                    Toast.makeText(this, "Сначала разблокируйте папку", Toast.LENGTH_SHORT).show()
                } else {
                    FolderLock.showChangePin(this, folder) { buildDrawer() }
                }
            }
            sheetRow(box, R.drawable.ic_unlock, "Снять защиту…") {
                if (locked) {
                    Toast.makeText(this, "Сначала разблокируйте папку", Toast.LENGTH_SHORT).show()
                } else {
                    FolderLock.showUnprotect(this, folder) {
                        buildDrawer()
                        renderNotes()
                    }
                }
            }
        }
        sheetRow(box, R.drawable.ic_trash, "Удалить папку", danger = true) {
            confirmDeleteFolder(folder)
        }

        BottomSheetDialog(this).apply {
            setContentView(box)
            show()
        }
    }

    /** В корзину с возможностью «Отменить» (undo-Snackbar, как в веб-версии). */
    private fun trashWithUndo(note: Note) {
        NotesStore.trashNote(note.id)
        Snackbar.make(snackbarHost, "Заметка перемещена в корзину", Snackbar.LENGTH_LONG)
            .setAction("Отменить") { NotesStore.restoreNote(note.id) }
            .show()
    }

    /** Разблокировать защищённую папку (PIN или биометрия). */
    private fun promptUnlockFolder(folder: Folder) {
        FolderLock.showUnlock(
            this,
            folder,
            onUnlocked = {
                Toast.makeText(this, "Папка «${folder.name}» разблокирована", Toast.LENGTH_SHORT).show()
                renderNotes()
                buildDrawer()
            }
        )
    }

    /** Удаление папки: защищённую можно удалить только разблокированной. */
    private fun confirmDeleteFolder(folder: Folder) {
        if (NotesStore.isFolderLocked(folder.id)) {
            Toast.makeText(this, "Папка защищена — сначала разблокируйте её", Toast.LENGTH_LONG).show()
            promptUnlockFolder(folder)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Удалить папку?")
            .setMessage("Папка «${folder.name}» будет удалена, заметки останутся без папки.")
            .setPositiveButton("Удалить") { _, _ ->
                NotesStore.deleteFolder(folder.id)
                if (prefs.folderId == folder.id) prefs.folderId = null
                Toast.makeText(this@MainActivity, "Папка «${folder.name}» удалена, заметки сохранены", Toast.LENGTH_SHORT).show()
                buildDrawer()
                renderNotes()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ----- Диалоги -----------------------------------------------------------------

    /**
     * Импорт .md: системный выбор файлов (можно несколько). Файлы читаются
     * в фоне, из каждого создаётся заметка (заголовок = имя файла, как в
     * Obsidian). Импорт идёт в открытую папку (если она не заблокирована).
     */
    private val importMdLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (!uris.isNullOrEmpty()) importMdFiles(uris)
        }

    private fun importMdFiles(uris: List<Uri>) {
        val targetFolder = prefs.folderId.takeIf { view == "all" }
        if (targetFolder != null && NotesStore.isFolderLocked(targetFolder)) {
            Toast.makeText(this, "Папка защищена — сначала разблокируйте её", Toast.LENGTH_LONG).show()
            return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            var imported = 0
            var skipped = 0
            uris.forEach { uri ->
                val name = queryDisplayName(uri)
                val text = runCatching {
                    contentResolver.openInputStream(uri)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                }.getOrNull()
                val okName = name != null && MD_EXTENSIONS.any { name.lowercase().endsWith(".$it") }
                if (text == null || !okName) {
                    skipped++
                    return@forEach
                }
                val note = NotesStore.createNote(
                    title = name.substringBeforeLast('.').trim().take(120),
                    content = text,
                    folderId = targetFolder
                )
                if (note != null) imported++ else skipped++
            }
            withContext(Dispatchers.Main) {
                renderNotes()
                Toast.makeText(
                    this@MainActivity,
                    if (skipped == 0) "Импортировано заметок: $imported"
                    else "Импортировано: $imported · пропущено: $skipped",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /** Имя файла из SAF-URI (null, если провайдер его не отдал). */
    private fun queryDisplayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    /** Диалог настроек: подложка / сетка / резервная копия (аналог веб-версии).
     *  Темы в настройках НЕТ — она переключается кнопкой на тулбаре
     *  (солнце/луна), держать два переключателя одной настройки избыточно
     *  (просьба пользователя).
     *  Пересоздаётся после каждого изменения, чтобы подсветка сегментов
     *  и карточки на фоне обновлялись «вживую». */
    private var settingsDialog: AlertDialog? = null

    private fun showSettingsDialog() {
        drawerLayout.closeDrawer(Gravity.START)
        // Защита от двойного окна: не открывать второй диалог поверх.
        if (settingsDialog?.isShowing == true) return
        val p = pal
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }

        // Темы здесь нет — переключается кнопкой на тулбаре (toggleTheme).

        container.addView(Ui.caption(this, "Цвет подложки заметок", p).apply {
            textSize = 13f
            setTextColor(p.text)
            letterSpacing = 0f
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            layoutParams = lp
        })
        container.addView(Ui.hint(this, "Насколько плотно цветная карточка подкрашивается своим цветом.", p))
        container.addView(segmentedRow(listOf("Насыщенная", "Приглушённая"), if (prefs.isTintBright) 0 else 1) { index ->
            prefs.tint = if (index == 0) "bright" else "muted"
            refreshAfterSettingsChange()
        })

        container.addView(Ui.caption(this, "Сетка заметок", p).apply {
            textSize = 13f
            setTextColor(p.text)
            letterSpacing = 0f
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            layoutParams = lp
        })
        container.addView(Ui.hint(this, "Компактная — больше колонок, карточки мельче.", p))
        container.addView(segmentedRow(listOf("Обычная", "Компактная"), if (prefs.isCompactGrid) 1 else 0) { index ->
            prefs.gridDensity = if (index == 1) "compact" else "normal"
            refreshAfterSettingsChange()
        })

        // Резервная копия: весь хранилище (папки + заметки, включая корзину)
        // в один JSON-файл через системный выбор файла (SAF).
        container.addView(Ui.caption(this, "Резервная копия", p).apply {
            textSize = 13f
            setTextColor(p.text)
            letterSpacing = 0f
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(14)
            layoutParams = lp
        })
        container.addView(Ui.hint(this, "Все заметки и папки — в один файл. Защищённые папки восстановятся только на этом устройстве: ключ шифрования привязан к Android.", p))
        container.addView(backupButtonsRow())

        settingsDialog = AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setView(container)
            .setPositiveButton("Готово", null)
            .show()
        // Фон диалога — фон приложения (в тёмной теме ЧЁРНЫЙ zinc-950),
        // а не серый системный.
        settingsDialog?.window?.setBackgroundDrawable(
            Ui.rounded(p.background, 6f, this, NoteColors.border(pal.dark), 1)
        )
    }

    // ----- Резервная копия: UI и SAF-поток -------------------------------------

    /** Ряд из двух кнопок: «Экспорт в файл» и «Восстановить из файла». */
    private fun backupButtonsRow(): View {
        val p = pal
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        fun backupButton(label: String, endMargin: Int = 0, onClick: () -> Unit): TextView =
            TextView(this).apply {
                text = label
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(p.text)
                background = Ui.rounded(
                    if (p.dark) 0x1AFFFFFF.toInt() else 0x14000000.toInt(), 12f, this@MainActivity
                )
                setPadding(dp(10), dp(10), dp(10), dp(10))
                isClickable = true
                isFocusable = true
                foreground = Ui.ripple(this@MainActivity)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMarginEnd(dp(endMargin))
                }
                setOnClickListener { onClick() }
            }
        row.addView(backupButton("Экспорт в файл", 8) { backupExportLauncher.launch(backupFileName()) })
        row.addView(backupButton("Восстановить из файла") { backupImportLauncher.launch(BACKUP_MIME_TYPES) })
        return row
    }

    /** Имя файла копии по умолчанию: obsidiankeep-backup-2026-10-09.json. */
    private fun backupFileName(): String = "obsidiankeep-backup-" +
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json"

    private val backupExportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) exportBackupTo(uri)
        }

    private val backupImportLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importBackupFrom(uri)
        }

    private fun exportBackupTo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching {
                val json = NotesStore.buildBackup()
                val written = contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toString(2).toByteArray(Charsets.UTF_8)); out.flush(); true
                } ?: false
                if (written) json else null
            }.getOrNull()
            withContext(Dispatchers.Main) {
                if (result == null) {
                    Toast.makeText(this@MainActivity, "Не удалось записать файл копии", Toast.LENGTH_LONG).show()
                } else {
                    val notes = result.optJSONArray("notes")?.length() ?: 0
                    val folders = result.optJSONArray("folders")?.length() ?: 0
                    Toast.makeText(
                        this@MainActivity,
                        "Копия сохранена: заметок $notes · папок $folders",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun importBackupFrom(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching {
                val text = contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Файл не читается")
                NotesStore.restoreBackup(JSONObject(text))
            }
            withContext(Dispatchers.Main) {
                result.fold({ report ->
                    // Обновить списки за диалогом и заново поставить будильники
                    // восстановленных напоминаний (как при старте процесса).
                    renderNotes()
                    buildDrawer()
                    NotesStore.notes.value
                        .filter { !it.isTrashed && it.reminderAt != null }
                        .forEach { Reminders.schedule(this@MainActivity, it) }
                    val parts = mutableListOf<String>()
                    if (report.notesAdded == 0 && report.notesUpdated == 0 && report.foldersAdded == 0) {
                        parts += "новых данных нет"
                    } else {
                        parts += if (report.notesUpdated == 0) "+${report.notesAdded} заметок"
                        else "+${report.notesAdded}, обновлено ${report.notesUpdated}"
                        if (report.foldersAdded > 0) parts += "папок +${report.foldersAdded}"
                    }
                    if (report.notesSkipped > 0) parts += "пропущено ${report.notesSkipped}"
                    Toast.makeText(this@MainActivity, "Восстановлено: ${parts.joinToString(" · ")}", Toast.LENGTH_LONG).show()
                }, { e ->
                    Toast.makeText(
                        this@MainActivity,
                        "Не удалось восстановить: ${e.message ?: "неизвестная ошибка"}",
                        Toast.LENGTH_LONG
                    ).show()
                })
            }
        }
    }

    /**
     * Мгновенная смена темы БЕЗ пересоздания активити: пересобираем все
     * экраны с новой палитрой. В манифесте у MainActivity стоит
     * configChanges="uiMode", поэтому AppCompatDelegate не триггерит
     * медленный recreate (это и был «тормоз» настроек), а диалог
     * пересобирается на месте — смена темы видна сразу.
     */
    private fun rethemeInPlace() {
        val query = if (::searchInput.isInitialized) searchInput.text?.toString().orEmpty() else ""
        setContentView(buildUi())
        applyEdgeToEdgeInsets()
        searchInput.setText(query)
        renderNotes()
        if (settingsDialog?.isShowing == true) {
            settingsDialog?.dismiss()
            showSettingsDialog()
        }
    }

    /** Перерисовать списки и переоткрыть диалог (без recreate-активити). */
    private fun refreshAfterSettingsChange() {
        settingsDialog?.dismiss()
        renderNotes()
        buildDrawer()
        showSettingsDialog()
    }

    /** Сегментированный переключатель (как в диалоге настроек веб-версии). */
    private fun segmentedRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val p = pal
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(if (p.dark) 0x14FFFFFF.toInt() else 0x0A000000.toInt(), 12f, this@MainActivity)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        options.forEachIndexed { index, label ->
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(10), dp(8), dp(10))
                if (index == selected) {
                    background = Ui.rounded(p.cardElevated, 9f, this@MainActivity, p.primary, 1)
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (p.dark) NoteColors.PRIMARY_SOFT_DARK else p.primary)
                } else {
                    setTextColor(p.muted)
                }
                setOnClickListener {
                    onSelect(index)
                }
            }
            row.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        return row
    }

    private fun showCreateFolderDialog() {
        val input = EditText(this).apply {
            hint = "Название папки"
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(60))
        }
        AlertDialog.Builder(this)
            .setTitle("Новая папка")
            .setMessage("Папки помогают группировать заметки.")
            .setView(input)
            .setPositiveButton("Создать") { _, _ ->
                val folder = NotesStore.createFolder(input.text?.toString()?.trim().orEmpty())
                if (folder == null) {
                    Toast.makeText(this, "Папка с таким названием уже есть", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Папка «${folder.name}» создана", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showRenameFolderDialog(folder: Folder) {
        // Хранилище отклоняет переименование заблокированной папки —
        // не показываем диалог с заведомо ложным сообщением о дубликате.
        if (NotesStore.isFolderLocked(folder.id)) {
            Toast.makeText(this, "Папка защищена — сначала разблокируйте её", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            setText(folder.name)
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(60))
        }
        AlertDialog.Builder(this)
            .setTitle("Переименовать папку")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val renamed = NotesStore.renameFolder(folder.id, input.text?.toString()?.trim().orEmpty())
                if (renamed == null) {
                    Toast.makeText(this, "Папка с таким названием уже есть", Toast.LENGTH_SHORT).show()
                } else {
                    buildDrawer()
                    renderNotes()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ----- Действия -----------------------------------------------------------------

    private fun createNoteAndOpen() {
        val targetFolder = prefs.folderId.takeIf { view == "all" }
        if (targetFolder != null && NotesStore.isFolderLocked(targetFolder)) {
            // Создание заметки в заблокированной защищённой папке запрещено —
            // иначе заметка была бы невидима до разблокировки.
            val folder = NotesStore.folderById(targetFolder)
            if (folder != null) {
                Toast.makeText(this, "Папка защищена — сначала разблокируйте её", Toast.LENGTH_LONG).show()
                promptUnlockFolder(folder)
            }
            return
        }
        val note = NotesStore.createNote(folderId = targetFolder) ?: return
        openEditor(note.id)
    }

    private fun openEditor(noteId: String) {
        startActivity(Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_NOTE_ID, noteId)
        })
    }

    // ----- Служебное ---------------------------------------------------------------

    private fun formatDate(time: Long, pattern: String): String = Ui.formatDate(time, pattern)

    private companion object {
        /** Расширения файлов, принимаемые импортом .md. */
        val MD_EXTENSIONS = listOf("md", "markdown", "mdown", "txt")

        /** MIME-типы, которые пикер предлагает для выбора файла копии. */
        val BACKUP_MIME_TYPES = arrayOf("application/json", "text/plain", "application/octet-stream")
    }
}
