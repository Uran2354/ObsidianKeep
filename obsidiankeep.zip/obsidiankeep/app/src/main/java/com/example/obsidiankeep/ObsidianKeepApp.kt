package com.example.obsidiankeep

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate

/**
 * Application-класс: инициализирует [NotesStore] (загрузка JSON из filesDir,
 * автоп очистка корзины), перепланирует будильники напоминаний — после
 * загрузки хранилища и после перезагрузки устройства (BootReceiver не
 * используется намеренно: планирование при старте процесса проще и
 * надёжнее для одного пакета без лишних манифест-сущностей) — и
 * автоматически блокирует защищённые папки, когда приложение уходит в фон:
 *
 * [ActivityLifecycleCallbacks] считает запущенные (onStart/onStop)
 * активности; когда счётчик доходит до нуля — пользователь свернул
 * приложение или переключился на другое — вызывается [NotesStore.lockAll]:
 * содержимое заметок снова шифруется, сессии разблокировки и ключи
 * стираются из памяти (авто-блокировка строже оригинала, где таймаут
 * настраивался в секундах).
 *
 * Все строковые литералы — русские.
 */
class ObsidianKeepApp : Application() {

    /** Число активностей в состоянии STARTED (0 = приложение в фоне). */
    private var startedActivities = 0

    override fun onCreate() {
        super.onCreate()
        // Тема оформления — при старте процесса (а не только в MainActivity):
        // иначе при запуске с уведомления (сразу EditorActivity) тема
        // применялась бы только после первого открытия главного экрана.
        AppCompatDelegate.setDefaultNightMode(
            when (Prefs(this).theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
        NotesStore.init(this)
        // Перепланировать напоминания всех активных заметок.
        NotesStore.notes.value
            .filter { !it.isTrashed && it.reminderAt != null }
            .forEach { Reminders.schedule(this, it) }

        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedActivities++
            }

            override fun onActivityStopped(activity: Activity) {
                startedActivities = (startedActivities - 1).coerceAtLeast(0)
                if (startedActivities == 0) {
                    // Приложение ушло в фон — заблокировать все защищённые папки.
                    NotesStore.lockAll()
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityResumed(activity: Activity) = Unit
            override fun onActivityPaused(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }
}
