package com.example.obsidiankeep

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import java.util.Calendar
import java.util.Locale

/**
 * Календарь напоминаний ObsidianKeep — четыре режима, как в оригинальном
 * CalendarScreen (WEEK/MONTH/YEAR/DAY) и лучше прежней версии zip'а,
 * где был только месяц:
 *
 *  - **Неделя** — строка из 7 дней (неделя с понедельника) со счётчиками
 *    напоминаний; тап выбирает день;
 *  - **Месяц** — сетка 7×N с точками напоминаний, подсветка «сегодня» и
 *    выбранного дня;
 *  - **Год** — 12 месяцев плиткой со счётчиками; тап по месяцу открывает
 *    его вид «Месяц» (как YearView → MonthView в оригинале);
 *  - **День** — детальный список напоминаний выбранного дня (время, цвет,
 *    заголовок); тап открывает заметку, долгое нажатие — меню
 *    (убрать напоминание / в корзину).
 *
 * Общие элементы: ‹ › навигация по периоду (шаг зависит от режима),
 * кнопка «Сегодня», переключатель режимов и панель выбранного дня со
 * списком + «+ Добавить напоминание» (создаёт заметку с reminderAt и
 * открывает редактор; если 09:00 уже прошло — берём now+1 мин).
 * По просьбе пользователя НАД кнопками Неделя/Месяц/Год/День текста нет:
 * заголовок «Календарь» перенесён в тулбар (сразу после стрелки назад),
 * блок «Ближайшие напоминания» — под панель дня (в конец экрана).
 *
 * Данные — [NotesStore.withReminders] (все напоминания, не только будущие:
 * фикс ревью — раньше точки строились по view «upcoming», и прошедшие
 * напоминания исчезали из сетки). Заблокированные папки исключены.
 *
 * UI построен целиком в коде. Все строковые литералы — русские.
 */
class CalendarActivity : AppCompatActivity() {

    /** Режимы календаря (как CalendarViewMode в оригинале). */
    private enum class Mode(val label: String) {
        WEEK("Неделя"), MONTH("Месяц"), YEAR("Год"), DAY("День")
    }

    private var mode: Mode = Mode.MONTH
    private var displayed: Calendar = Calendar.getInstance()
    private var selectedDay: Calendar = Calendar.getInstance()

    private lateinit var modeRow: LinearLayout
    private lateinit var periodTitle: TextView
    private lateinit var bodyBox: LinearLayout
    private lateinit var dayPanel: LinearLayout
    private lateinit var upcomingBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        applyEdgeToEdgeInsets()
        rebuildAll()
    }

    override fun onResume() {
        super.onResume()
        rebuildAll()
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ----- UI построен целиком в коде (без XML-лейаутов) ---------------------

    private fun buildUi(): View {
        val dark = isDark
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(NoteColors.screenBackground(dark))
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
        }
        val backButton = Ui.iconButton(this, R.drawable.ic_back, "Назад", pal.muted) { finish() }
        toolbar.addView(backButton)
        // Заголовок «Календарь» — сразу после стрелки назад (просьба
        // пользователя). Распорка толкает чип «Сегодня» вправо.
        toolbar.addView(Ui.title(this, "Календарь", pal, 17f).apply {
            // Чип ещё не в родителе — layoutParams == null, назначаем свежие LP.
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMarginStart(dp(6)) }
        })
        toolbar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        // «Сегодня» — сброс периода и выбранного дня (чип, как в вебе).
        val todayButton = TextView(this).apply {
            text = "Сегодня"
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(pal.primaryText)
            background = Ui.rounded(pal.chipBg, 20f, this@CalendarActivity)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                displayed = Calendar.getInstance()
                selectedDay = Calendar.getInstance()
                rebuildAll()
            }
        }
        toolbar.addView(todayButton)
        root.addView(toolbar)

        val scroll = android.widget.ScrollView(this).apply { isFillViewport = true }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(20))
        }
        scroll.addView(column)

        // Переключатель режимов Неделя/Месяц/Год/День — сразу под тулбаром,
        // никакого текста над ним (просьба пользователя).
        modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(4)
            layoutParams = lp
        }
        column.addView(modeRow)

        // Навигация по периоду: ‹ Название ›.
        val periodRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        val prev = Ui.iconButton(this, R.drawable.ic_chevron_left, "Предыдущий период", pal.muted) {
            navigatePeriod(-1)
        }
        val next = Ui.iconButton(this, R.drawable.ic_chevron_right, "Следующий период", pal.muted) {
            navigatePeriod(1)
        }
        periodTitle = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT)
        }
        periodRow.addView(prev)
        periodRow.addView(periodTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        periodRow.addView(next)
        column.addView(periodRow)

        // Тело режима (неделя / месяц / год; в режиме «День» пусто —
        // детальный список ниже).
        bodyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
        }
        column.addView(bodyBox)

        // Панель выбранного дня (видна во всех режимах, как в оригинале) —
        // карточка с рамкой, как панель дня в веб-версии.
        dayPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(NoteColors.cardElevated(dark), 14f, this@CalendarActivity, pal.border, 1)
            setPadding(dp(12), dp(10), dp(12), dp(12))
            elevation = dp(2).toFloat()
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            layoutParams = lp
        }
        column.addView(dayPanel)

        // Ближайшие напоминания (лучше оригинала — в нём блока не было) —
        // в КОНЦЕ экрана: над кнопками режимов текста быть не должно.
        column.addView(caption("Ближайшие напоминания"), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })
        upcomingBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(upcomingBox)

        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1f
        ))
        return root
    }

    private fun caption(text: String): TextView = Ui.caption(this, text, pal)

    // ----- Пересборка ----------------------------------------------------------

    private fun rebuildAll() {
        rebuildUpcoming()
        rebuildModeRow()
        updatePeriodTitle()
        rebuildBody()
        rebuildDayPanel()
    }

    private fun rebuildModeRow() {
        modeRow.removeAllViews()
        Mode.values().forEach { m ->
            val chip = TextView(this).apply {
                text = m.label
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(8), dp(10), dp(8))
                val selected = m == mode
                setTypeface(typeface, if (selected) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(
                    if (selected) Color.WHITE
                    else if (isDark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT
                )
                background = rounded(
                    if (selected) (if (isDark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT)
                    else if (isDark) 0x14FFFFFF.toInt() else 0x0F000000.toInt(),
                    dp(14).toFloat()
                )
                setOnClickListener { mode = m; rebuildAll() }
            }
            modeRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
    }

    /** Шаг навигации ‹ ›: неделя/месяц/год/день — по текущему режиму. */
    private fun navigatePeriod(direction: Int) {
        when (mode) {
            Mode.WEEK -> displayed.add(Calendar.WEEK_OF_YEAR, direction)
            Mode.MONTH -> displayed.add(Calendar.MONTH, direction)
            Mode.YEAR -> displayed.add(Calendar.YEAR, direction)
            Mode.DAY -> {
                displayed.add(Calendar.DAY_OF_MONTH, direction)
                selectedDay = displayed.clone() as Calendar
            }
        }
        updatePeriodTitle()
        rebuildBody()
        if (mode == Mode.DAY) rebuildDayPanel()
    }

    /** Заголовок периода: диапазон недели / месяц+год / год / полная дата. */
    private fun updatePeriodTitle() {
        val ru = Locale.forLanguageTag("ru")
        periodTitle.text = when (mode) {
            Mode.WEEK -> {
                val weekStart = Calendar.getInstance().apply {
                    timeInMillis = displayed.timeInMillis
                    set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
                }
                // Ui.formatDate — общий кэш форматов (без new SimpleDateFormat на каждый вызов).
                val start = Ui.formatDate(weekStart.timeInMillis, "d MMM")
                val end = Ui.formatDate(weekStart.timeInMillis + 6L * 86_400_000, "d MMM")
                "$start — $end".replaceFirstChar { it.uppercase() }
            }
            Mode.MONTH -> (displayed.getDisplayName(Calendar.MONTH, Calendar.LONG, ru) ?: "")
                .replaceFirstChar { it.uppercase() } + " " + displayed.get(Calendar.YEAR)
            Mode.YEAR -> displayed.get(Calendar.YEAR).toString()
            Mode.DAY -> Ui.formatDate(selectedDay.timeInMillis, "d MMMM yyyy")
                .replaceFirstChar { it.uppercase() }
        }
    }

    private fun rebuildBody() {
        bodyBox.removeAllViews()
        when (mode) {
            Mode.WEEK -> buildWeekBody()
            Mode.MONTH -> buildMonthBody()
            Mode.YEAR -> buildYearBody()
            Mode.DAY -> buildDayBody()
        }
    }

    // ----- Режим «Неделя» --------------------------------------------------------

    /** 7 дней текущей недели: карточка-ячейка с рамкой, выделение — кольцо (как в вебе). */
    private fun buildWeekBody() {
        val dark = isDark
        val weekStart = Calendar.getInstance().apply {
            timeInMillis = displayed.timeInMillis
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val byDay = remindersByDay()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dayNames = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
        for (i in 0 until 7) {
            val day = (weekStart.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, i) }
            val isSelected = sameDay(day, selectedDay)
            val isToday = sameDay(day, today())
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                // Карточка дня: у выбранного — фиолетовое кольцо и подложка.
                background = rounded(
                    if (isSelected) (if (dark) 0x2AA78BFA.toInt() else 0x1A7C3AED.toInt())
                    else NoteColors.cardElevated(dark),
                    dp(12).toFloat(),
                    if (isSelected) NoteColors.primary(dark) else NoteColors.border(dark),
                    if (isSelected) dp(2) else dp(1)
                )
                val lp = LinearLayout.LayoutParams(0, dp(64), 1f)
                lp.setMargins(dp(2), 0, dp(2), 0)
                layoutParams = lp
                addView(TextView(this@CalendarActivity).apply {
                    text = dayNames[i]
                    textSize = 10f
                    gravity = Gravity.CENTER
                    setTextColor(if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
                })
                addView(TextView(this@CalendarActivity).apply {
                    text = day.get(Calendar.DAY_OF_MONTH).toString()
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, if (isToday) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(
                        when {
                            isSelected || isToday -> if (dark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT
                            else -> if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT
                        }
                    )
                })
                addView(TextView(this@CalendarActivity).apply {
                    val n = (byDay[dayKey(day)] ?: emptyList()).size
                    text = if (n > 0) "•$n" else ""
                    textSize = 10f
                    gravity = Gravity.CENTER
                    setTextColor(NoteColors.primary(dark))
                })
                setOnClickListener {
                    selectedDay = day.clone() as Calendar
                    rebuildAll()
                }
            }
            row.addView(cell)
        }
        bodyBox.addView(row)
    }

    // ----- Режим «Месяц» -----------------------------------------------------------

    /**
     * Месячная сетка как в веб-live-view: каждая ячейка — карточка с рамкой,
     * у выбранного дня — фиолетовое кольцо и подложка, номер «сегодня» — в
     * идеально КРУГЛОЙ плашке (фиксированный квадрат 20dp — раньше овал
     * растягивался по ширине ячейки), точки напоминаний — цветом заметки.
     */
    private fun buildMonthBody() {
        val dark = isDark
        val byDay = remindersByDay()
        val todayC = today()

        // Дни недели.
        val weekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dayNames = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
        dayNames.forEach { name ->
            weekRow.addView(TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        bodyBox.addView(weekRow)

        // Ячейки: первая неделя смещена на (dayOfWeek: Пн=1..Вс=7) - 1.
        val cursor = (displayed.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val firstOffset = (cursor.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Пн→0 … Вс→6
        val daysInMonth = cursor.getActualMaximum(Calendar.DAY_OF_MONTH)

        var cell = 0
        var weekRow2: LinearLayout? = null

        fun newWeek() {
            weekRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            bodyBox.addView(weekRow2, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }

        // Пустые ячейки перед первым днём.
        for (i in 0 until firstOffset) {
            if (cell % 7 == 0) newWeek()
            weekRow2!!.addView(View(this), LinearLayout.LayoutParams(0, dp(46), 1f))
            cell++
        }

        for (day in 1..daysInMonth) {
            if (cell % 7 == 0) newWeek()
            val dayCal = (displayed.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }
            val isToday = sameDay(dayCal, todayC)
            val isSelected = sameDay(dayCal, selectedDay)
            val dayNotes = byDay[dayKey(dayCal)] ?: emptyList()

            val cellView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                // Карточка дня (как bg-card в вебе); выбранная — ring + tint.
                background = rounded(
                    if (isSelected) (if (dark) 0x2AA78BFA.toInt() else 0x1A7C3AED.toInt())
                    else NoteColors.cardElevated(dark),
                    dp(10).toFloat(),
                    if (isSelected) NoteColors.primary(dark) else NoteColors.border(dark),
                    if (isSelected) dp(2) else dp(1)
                )
                val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                layoutParams = lp

                // Номер дня: «сегодня» — в маленьком идеальном круге (20dp).
                if (isToday) {
                    addView(FrameLayout(this@CalendarActivity).apply {
                        background = circle(NoteColors.primary(dark))
                        addView(TextView(this@CalendarActivity).apply {
                            text = day.toString()
                            textSize = 11f
                            setTypeface(typeface, Typeface.BOLD)
                            setTextColor(Color.WHITE)
                            gravity = Gravity.CENTER
                        }, FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }, LinearLayout.LayoutParams(dp(20), dp(20)))
                } else {
                    addView(TextView(this@CalendarActivity).apply {
                        text = day.toString()
                        textSize = 12f
                        gravity = Gravity.CENTER
                        setTextColor(
                            if (isSelected) (if (dark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT)
                            else if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT
                        )
                    })
                }

                // Точки напоминаний — цветом заметки, максимум 3 + «+N».
                if (dayNotes.isNotEmpty()) {
                    addView(LinearLayout(this@CalendarActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        dayNotes.take(3).forEach { n ->
                            addView(View(this@CalendarActivity).apply {
                                background = circle(NoteColors.accent(n.color))
                            }, LinearLayout.LayoutParams(dp(5), dp(5)).apply { marginEnd = dp(2) })
                        }
                        if (dayNotes.size > 3) {
                            addView(TextView(this@CalendarActivity).apply {
                                text = "+${dayNotes.size - 3}"
                                textSize = 8f
                                setTextColor(if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
                            })
                        }
                    })
                }

                setOnClickListener {
                    selectedDay = dayCal.clone() as Calendar
                    rebuildAll()
                }
            }
            weekRow2!!.addView(cellView)
            cell++
        }
    }

    // ----- Режим «Год» ---------------------------------------------------------------

    /** 12 месяцев плиткой (3×4): имя месяца + число напоминаний, как YearView. */
    private fun buildYearBody() {
        val dark = isDark
        val year = displayed.get(Calendar.YEAR)
        val reminders = NotesStore.withReminders()
        val monthStart = Calendar.getInstance()
        val counts = IntArray(12)
        reminders.forEach { note ->
            monthStart.timeInMillis = note.reminderAt ?: return@forEach
            if (monthStart.get(Calendar.YEAR) == year) {
                counts[monthStart.get(Calendar.MONTH)]++
            }
        }

        val ru = Locale.forLanguageTag("ru")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (rowIdx in 0 until 4) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in 0 until 3) {
                val month = rowIdx * 3 + col
                val isCurrent = year == today().get(Calendar.YEAR) && month == today().get(Calendar.MONTH)
                val cell = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(6), dp(10), dp(6), dp(10))
                    val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                    layoutParams = lp
                    background = rounded(
                        NoteColors.cardElevated(dark),
                        dp(10).toFloat(),
                        if (isCurrent) NoteColors.primary(dark) else NoteColors.border(dark),
                        if (isCurrent) dp(2) else dp(1)
                    )
                    addView(TextView(this@CalendarActivity).apply {
                        text = monthName(month, ru)
                        textSize = 13f
                        gravity = Gravity.CENTER
                        setTypeface(typeface, if (isCurrent) Typeface.BOLD else Typeface.NORMAL)
                        setTextColor(if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT)
                    })
                    if (counts[month] > 0) {
                        addView(TextView(this@CalendarActivity).apply {
                            text = "${counts[month]}"
                            textSize = 11f
                            gravity = Gravity.CENTER
                            setTextColor(NoteColors.primary(dark))
                        })
                    }
                    setOnClickListener {
                        // Тап по месяцу → вид «Месяц» этого месяца (как в оригинале).
                        displayed = Calendar.getInstance().apply {
                            set(year, month, 1, 0, 0, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val sel = selectedDay
                        if (sel.get(Calendar.YEAR) != year || sel.get(Calendar.MONTH) != month) {
                            selectedDay = displayed.clone() as Calendar
                        }
                        mode = Mode.MONTH
                        rebuildAll()
                    }
                }
                row.addView(cell)
            }
            grid.addView(row)
        }
        bodyBox.addView(grid)
    }

    // ----- Режим «День» ----------------------------------------------------------------

    /**
     * Тело режима «День»: детальный список выбранного дня с временем, цветом
     * и заголовком (как DayView оригинала + действия). Панель снизу остаётся,
     * поэтому здесь только расширенный список — крупнее, чем в панели.
     */
    private fun buildDayBody() {
        rebuildDayPanel()
    }

    // ----- Ближайшие напоминания ---------------------------------------------------------

    /** Список ближайших напоминаний (как view «upcoming» веб-версии). */
    private fun rebuildUpcoming() {
        upcomingBox.removeAllViews()
        val upcoming = NotesStore.query("upcoming")
        if (upcoming.isEmpty()) {
            upcomingBox.addView(TextView(this).apply {
                text = "Напоминаний нет\nОткройте заметку и задайте дату с временем."
                textSize = 13f
                setTextColor(if (isDark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
                setPadding(0, dp(4), 0, dp(8))
            })
            return
        }
        upcoming.take(3).forEach { note ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = rounded(NoteColors.cardBackground(note.color, isDark, tintBright()), dp(12).toFloat())
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.topMargin = dp(4)
                layoutParams = lp
                isClickable = true
                isFocusable = true
                setOnClickListener { openNote(note.id) }
            }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_bell)
                imageTintList = android.content.res.ColorStateList.valueOf(NoteColors.primary(isDark))
            }, LinearLayout.LayoutParams(dp(15), dp(15)).apply { marginEnd = dp(7) })
            row.addView(TextView(this).apply {
                text = formatDate(note.reminderAt ?: 0L, "d MMM, HH:mm")
                textSize = 12f
                setTextColor(if (isDark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT)
                setPadding(0, 0, dp(8), 0)
            })
            row.addView(TextView(this).apply {
                text = note.title.ifBlank { "Без названия" }
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (isDark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            upcomingBox.addView(row)
        }
    }

    private fun tintBright(): Boolean = Prefs(this).isTintBright

    // ----- Панель выбранного дня -----------------------------------------------------------

    /** Панель выбранного дня: напоминания дня + кнопка «Добавить напоминание». */
    private fun rebuildDayPanel() {
        val dark = isDark
        dayPanel.removeAllViews()

        val items = NotesStore.withReminders().filter { sameDay(toCalendar(it.reminderAt ?: 0L), selectedDay) }

        val title = TextView(this).apply {
            text = formatDate(selectedDay.timeInMillis, "d MMMM yyyy")
                .replaceFirstChar { it.uppercase() } + " · " + items.size
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT)
            setPadding(dp(2), 0, 0, dp(4))
        }
        dayPanel.addView(title)

        if (items.isEmpty()) {
            dayPanel.addView(TextView(this).apply {
                text = if (mode == Mode.DAY) "На этот день напоминаний нет.\nНажмите «+ Добавить напоминание»."
                else "На этот день напоминаний нет."
                textSize = 13f
                setTextColor(if (dark) NoteColors.MUTED_DARK else NoteColors.MUTED_LIGHT)
                setPadding(0, dp(4), 0, dp(8))
            })
        } else {
            items.forEach { note ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = Ui.rounded(if (dark) 0x0FFFFFFF.toInt() else 0x08000000.toInt(), 10f, this@CalendarActivity)
                    setPadding(dp(8), dp(7), dp(8), dp(7))
                    isClickable = true
                    isFocusable = true
                    foreground = Ui.ripple(this@CalendarActivity)
                    setOnClickListener { openNote(note.id) }
                    // Долгое нажатие — действия (убрать напоминание / в корзину).
                    setOnLongClickListener { showEventMenu(note); true }
                }
                row.addView(View(this).apply {
                    background = circle(NoteColors.accent(note.color))
                    val lp = LinearLayout.LayoutParams(dp(10), dp(10))
                    lp.marginEnd = dp(8)
                    layoutParams = lp
                })
                row.addView(TextView(this).apply {
                    text = formatDate(note.reminderAt ?: 0L, "HH:mm")
                    textSize = 13f
                    setTextColor(if (dark) NoteColors.PRIMARY_DARK else NoteColors.PRIMARY_LIGHT)
                    setPadding(0, 0, dp(8), 0)
                })
                row.addView(TextView(this).apply {
                    text = note.title.ifBlank { "Без названия" }
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(if (dark) NoteColors.TEXT_DARK else NoteColors.TEXT_LIGHT)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                dayPanel.addView(row)
            }
        }

        val add = TextView(this).apply {
            text = "+ Добавить напоминание"
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(pal.primaryText)
            background = Ui.rounded(pal.chipBg, 20f, this@CalendarActivity)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            layoutParams = lp
            setOnClickListener { createReminderForSelectedDay() }
        }
        dayPanel.addView(add)
    }

    /** Меню события дня: убрать напоминание или отправить заметку в корзину. */
    private fun showEventMenu(note: Note) {
        val popup = PopupMenu(this, window.decorView, Gravity.CENTER)
        popup.menu.add(0, 1, 0, "Убрать напоминание")
        popup.menu.add(0, 2, 1, "Заметку в корзину")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    NotesStore.updateNote(note.id, clearReminder = true)
                    Reminders.cancel(this, note.id)
                    Toast.makeText(this, "Напоминание убрано", Toast.LENGTH_SHORT).show()
                    rebuildAll()
                }
                2 -> confirmTrash(note)
            }
            true
        }
        popup.show()
    }

    /** Подтверждение удаления заметки из календаря (мягкое — в корзину). */
    private fun confirmTrash(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("В корзину?")
            .setMessage("Заметка «${note.title.ifBlank { "Без названия" }}» будет перемещена в корзину (10 дней на восстановление).")
            .setPositiveButton("В корзину") { _, _ ->
                NotesStore.trashNote(note.id)
                Toast.makeText(this, "Заметка перемещена в корзину", Toast.LENGTH_SHORT).show()
                rebuildAll()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /**
     * Создать заметку с reminderAt на выбранный день (09:00) и открыть редактор.
     * Если 09:00 уже прошло (выбран сегодня) — берём now + 1 минута (иначе
     * AlarmManager молча не запланировал бы будильник в прошлом).
     */
    private fun createReminderForSelectedDay() {
        val at = (selectedDay.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val finalAt = if (at <= System.currentTimeMillis()) {
            val now = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
            now.apply { set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        } else at
        val note = NotesStore.createNote(reminderAt = finalAt) ?: run {
            Toast.makeText(this, "Папка заблокирована — разблокируйте её, чтобы создавать заметки", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Заметка создана — задайте заголовок и текст", Toast.LENGTH_SHORT).show()
        openNote(note.id)
    }

    private fun openNote(noteId: String) {
        startActivity(Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_NOTE_ID, noteId)
        })
    }

    // ----- Утилиты -----------------------------------------------------------------

    private fun monthName(month: Int, ru: Locale): String {
        val cal = Calendar.getInstance().apply { set(2024, month, 1) }
        return cal.getDisplayName(Calendar.MONTH, Calendar.LONG, ru)
            ?.replaceFirstChar { it.uppercase() } ?: ""
    }

    private fun today(): Calendar = Calendar.getInstance()

    /** Группировка напоминаний по дню за ОДИН проход (оптимизация ревью:
     *  раньше для каждой ячейки сетки заново сканировался весь список). */
    private fun remindersByDay(): Map<Int, List<Note>> {
        val map = HashMap<Int, List<Note>>()
        NotesStore.withReminders().forEach { n ->
            val ms = n.reminderAt ?: return@forEach
            val key = dayKey(toCalendar(ms))
            map[key] = (map[key] ?: emptyList()) + n
        }
        return map
    }

    private fun dayKey(c: Calendar): Int =
        c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)

    private fun sameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    private fun toCalendar(ms: Long): Calendar = Calendar.getInstance().apply { timeInMillis = ms }

    private fun rounded(
        color: Int,
        radiusPx: Float,
        strokeColor: Int = 0,
        strokeWidth: Int = 0
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

    private fun circle(color: Int): GradientDrawable =
        GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    // formatDate делегирован в Ui.formatDate — там общий кэш SimpleDateFormat
    // (построение формата на каждую строку дня/напоминания — лишняя работа).
    private fun formatDate(time: Long, pattern: String): String = Ui.formatDate(time, pattern)
}
