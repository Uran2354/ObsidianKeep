package com.example.obsidiankeep

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/**
 * Облако тегов — аналог tags-view веб-live-view: размер подписи растёт с
 * числом заметок (масштаб 0.9–1.8), у каждого тега — счётчик «×N».
 * Тап по тегу раскрывает под ним список заметок (строки-карточки с иконкой
 * и превью); тап по заметке открывает редактор. Долгое состояние фильтра
 * («показывать только этот тег в списке») живёт в Prefs.tagFilter — им
 * пользуются карточки главной.
 *
 * Открывается и с выбранным тегом: EditorActivity передаёт [EXTRA_TAG]
 * (из чипов тегов и тапов по #тегам в режиме «Чтение») — под тегом сразу
 * раскрывается список заметок.
 *
 * UI построен целиком в коде (иконки — векторные res/drawable). Все
 * строковые литералы — русские.
 */
class TagsActivity : AppCompatActivity() {

    private lateinit var cloudBox: LinearLayout
    private lateinit var countText: TextView
    private lateinit var resultList: LinearLayout
    private var selectedTag: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedTag = intent?.getStringExtra(EXTRA_TAG)
        setContentView(buildUi())
        applyEdgeToEdgeInsets()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                NotesStore.notes.collect { rebuild() }
            }
        }
    }

    private val isDark: Boolean get() = Ui.isDark(this)
    private val pal: Palette get() = Ui.palette(isDark)
    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi(): View {
        val p = pal
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
        }

        // Тулбар: назад + заголовок + счётчик.
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        toolbar.addView(Ui.iconButton(this, R.drawable.ic_back, "Назад", p.muted) { finish() })
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        header.addView(Ui.title(this, "Теги", p, 18f))
        countText = Ui.subtitle(this, "", p)
        header.addView(countText)
        toolbar.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(toolbar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(24))
        }
        scroll.addView(column)

        cloudBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        column.addView(cloudBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        resultList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            layoutParams = lp
        }
        column.addView(resultList)

        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, 1f
        ))
        return root
    }

    private fun rebuild() {
        val p = pal
        val counts = NotesStore.tagCounts()
        countText.text = "всего тегов: ${counts.size}"

        cloudBox.removeAllViews()
        if (counts.isEmpty()) {
            cloudBox.addView(Ui.emptyState(this, R.drawable.ic_tag,
                "Тегов пока нет", "Добавьте #тег в текст любой заметки.", p))
        } else {
            val maxCount = counts.first().second.coerceAtLeast(1)

            // Облако: чипы со масштабом и счётчиком, раскладка простым флоу
            // (строки примерно до 26 «условных символов» — надёжно без измерений).
            var row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.CENTER_HORIZONTAL }
            }
            var rowWeight = 0.0
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            counts.forEach { (tag, count) ->
                val scale = 0.9f + 0.9f * (count.toFloat() / maxCount.toFloat())
                val chip = makeCloudChip(tag, count, scale)
                row.addView(chip)
                rowWeight += tag.length * scale + 3.5
                if (rowWeight > 26.0) {
                    wrap.addView(row, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, dp(2), 0, dp(2)) })
                    row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    rowWeight = 0.0
                }
            }
            if (row.childCount > 0) {
                wrap.addView(row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(2), 0, dp(2)) })
            }
            cloudBox.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(wrap)
            })
        }

        // Список заметок выбранного тега.
        resultList.removeAllViews()
        val tag = selectedTag ?: return
        val notes = NotesStore.query("all", tag = tag)
        resultList.addView(Ui.caption(this, "Заметки с тегом #$tag · ${notes.size}", p).apply {
            setPadding(dp(4), dp(8), 0, dp(6))
        })
        notes.forEach { note ->
            resultList.addView(noteRow(note))
        }
    }

    /** Чип облака: масштаб по счётчику + «×N», выбранный — фиолетовый. */
    private fun makeCloudChip(tag: String, count: Int, scale: Float): TextView {
        val p = pal
        val selected = selectedTag == tag
        return TextView(this).apply {
            text = "#$tag  ×$count"
            textSize = 13f * scale
            setTypeface(typeface, if (selected) Typeface.BOLD else Typeface.NORMAL)
            setTextColor(if (selected) p.primaryText else p.text)
            background = Ui.rounded(
                if (selected) p.chipBg else (if (p.dark) 0x14FFFFFF.toInt() else 0x0A000000.toInt()),
                20f, this@TagsActivity
            )
            setPadding(dp(10), dp(6), dp(10), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
            setOnClickListener {
                selectedTag = if (selectedTag == tag) null else tag
                rebuild()
            }
        }
    }

    /** Строка заметки выбранного тега — карточка с иконкой и превью. */
    private fun noteRow(note: Note): View {
        val p = pal
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(p.card, 12f, this@TagsActivity, p.border, 1)
            elevation = dp(1).toFloat()
            setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6)
            layoutParams = lp
            isClickable = true
            isFocusable = true
            foreground = Ui.ripple(this@TagsActivity)

            addView(ImageView(this@TagsActivity).apply {
                setImageResource(if (NotesStore.isNoteLocked(note)) R.drawable.ic_lock else R.drawable.ic_note)
                imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(10) })

            addView(LinearLayout(this@TagsActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@TagsActivity).apply {
                    text = note.title.ifBlank { "Без названия" }
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(p.text)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                if (!NotesStore.isNoteLocked(note)) {
                    addView(TextView(this@TagsActivity).apply {
                        text = stripMarkdown(note.content, 70)
                        textSize = 12f
                        setTextColor(p.muted)
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            setOnClickListener {
                startActivity(Intent(this@TagsActivity, EditorActivity::class.java).apply {
                    putExtra(EditorActivity.EXTRA_NOTE_ID, note.id)
                })
            }
        }
    }

    companion object {
        /** Экстра intent: тег, который надо сразу выбрать (облако + список заметок). */
        const val EXTRA_TAG = "tag"
    }
}
