package com.example.obsidiankeep

import org.json.JSONObject

/**
 * Модели данных ObsidianKeep и разбор markdown-контента.
 *
 * Требование «плоского одного пакета»: никаких сущностей Room/Hilt —
 * заметки и папки — простые data-классы, сериализация в JSON вручную
 * через platform-`org.json` (без внешних зависимостей). Хранение —
 * файл в filesDir (см. [NotesStore]).
 *
 * Теги НЕ хранятся отдельно: они выводятся из контента (#хэштеги) при
 * каждом чтении — тот же контракт, что в веб-версии (`extractTags`).
 *
 * Все строковые литералы — русские.
 */

// ----- Цвета карточек (8, как в веб-версии) ------------------------------

/** Ключи цветов заметки. «default» — без цвета (нейтральная карточка). */
val NOTE_COLOR_KEYS: List<String> =
    listOf("default", "red", "amber", "lime", "teal", "blue", "violet", "fuchsia")

/** Русские подписи цветов (для меню выбора). */
val NOTE_COLOR_LABELS: Map<String, String> = mapOf(
    "default" to "Без цвета",
    "red" to "Красная",
    "amber" to "Янтарная",
    "lime" to "Лаймовая",
    "teal" to "Бирюзовая",
    "blue" to "Голубая",
    "violet" to "Фиолетовая",
    "fuchsia" to "Фуксия"
)

/**
 * Миграция старой палитры: «зелёная» (#10B981) была почти неотличима от
 * «бирюзовой» (#14B8A6), а «розовая» (#EC4899) — от «красной» (#F43F5E).
 * Они заменены на лаймовую и фуксию; старые ключи на диске переводятся
 * на новые при каждом чтении (и сохраняются при ближайшей записи).
 */
private val LEGACY_COLOR_KEYS: Map<String, String> = mapOf(
    "green" to "lime",
    "pink" to "fuchsia"
)

/**
 * Валидация ключа цвета: неизвестное значение → «default», ключи старой
 * палитры (green/pink) → новые (lime/fuchsia). Контракт веб-версии.
 */
fun normalizeColor(raw: String?): String =
    when {
        raw == null -> "default"
        NOTE_COLOR_KEYS.contains(raw) -> raw
        else -> LEGACY_COLOR_KEYS[raw] ?: "default"
    }

// ----- Сущности -----------------------------------------------------------

/**
 * Заметка. Времена — epoch millis (в веб-версии ISO-строки, здесь Long
 * удобнее для AlarmManager и сортировок; формат хранения локальный).
 *
 * [isEncrypted] — заметка защищённой папки: в notes.json её content
 * лежит шифротекстом AES/GCM (см. [CryptoManager]), а в памяти после
 * разблокировки папки — открытый текст. Флаг означает «при записи
 * на диск content надо шифровать ключом папки».
 */
data class Note(
    val id: String,
    val title: String,
    val content: String,
    val color: String,          // ключ из [NOTE_COLOR_KEYS], уже нормализован
    val folderId: String?,      // null = без папки
    val isFavorite: Boolean,
    val isPinned: Boolean,
    val deletedAt: Long?,       // null = активная; иначе — в корзине
    val reminderAt: Long?,      // null = напоминания нет
    val isEncrypted: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
) {
    /** Теги заметки — выводятся из контента (#хэштеги, уникальные, lowercase). */
    val tags: List<String> get() = extractTags(content)

    val isTrashed: Boolean get() = deletedAt != null

    fun withUpdatedAt(now: Long): Note = copy(updatedAt = now)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("content", content)
        .put("color", color)
        .put("folderId", folderId ?: JSONObject.NULL)
        .put("isFavorite", isFavorite)
        .put("isPinned", isPinned)
        .put("deletedAt", deletedAt ?: JSONObject.NULL)
        .put("reminderAt", reminderAt ?: JSONObject.NULL)
        .put("isEncrypted", isEncrypted)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)

    companion object {
        fun fromJson(o: JSONObject): Note = Note(
            id = o.optString("id", ""),
            title = o.optString("title", ""),
            content = o.optString("content", ""),
            color = normalizeColor(o.optString("color", "default")),
            folderId = if (o.isNull("folderId")) null else o.optString("folderId"),
            isFavorite = o.optBoolean("isFavorite", false),
            isPinned = o.optBoolean("isPinned", false),
            deletedAt = if (o.isNull("deletedAt")) null else o.optLong("deletedAt"),
            reminderAt = if (o.isNull("reminderAt")) null else o.optLong("reminderAt"),
            isEncrypted = o.optBoolean("isEncrypted", false),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
        )
    }
}

/**
 * Папка. Удаление папки не удаляет заметки (folderId сбрасывается в null).
 *
 * Защита папки (как в оригинале ObsidianKeep):
 *  - [pinHash]/[pinSalt] — PBKDF2-хэш персонального PIN-кода папки (4–16 цифр);
 *  - [encryptedKey] — ключ шифрования содержимого заметок, обёрнутый
 *    мастер-ключом Android Keystore (AES/GCM): на диске заметки
 *    зашифрованы даже на рутованном устройстве;
 *  - разблокировка — PIN **или** биометрия (см. [FolderLock]); сессия
 *    разблокировки живёт в памяти ([NotesStore.unlockedFolderIds]) и
 *    сбрасывается при сворачивании приложения.
 */
data class Folder(
    val id: String,
    val name: String,
    val createdAt: Long,
    val isProtected: Boolean = false,
    val encryptedKey: String? = null,
    val pinHash: String? = null,
    val pinSalt: String? = null
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("createdAt", createdAt)
        .put("isProtected", isProtected)
        .put("encryptedKey", encryptedKey ?: JSONObject.NULL)
        .put("pinHash", pinHash ?: JSONObject.NULL)
        .put("pinSalt", pinSalt ?: JSONObject.NULL)

    companion object {
        fun fromJson(o: JSONObject): Folder = Folder(
            id = o.optString("id", ""),
            name = o.optString("name", ""),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            isProtected = o.optBoolean("isProtected", false),
            encryptedKey = if (o.isNull("encryptedKey")) null else o.optString("encryptedKey"),
            pinHash = if (o.isNull("pinHash")) null else o.optString("pinHash"),
            pinSalt = if (o.isNull("pinSalt")) null else o.optString("pinSalt")
        )
    }
}

// ----- Разбор markdown (контракт веб-версии extract.ts) --------------------

/** Уникальные #теги из контента (lowercase, 1–32 символа буквы/цифры/_/-). */
fun extractTags(content: String): List<String> {
    val found = LinkedHashSet<String>()
    // Регэксп веб-версии: тег обязан начинаться после начала строки/пробела/(/>
    val regex = Regex("(?:^|[\\s(>)])#([\\p{L}\\p{N}][\\p{L}\\p{N}_-]{0,31})")
    for (m in regex.findAll(content)) {
        found.add(m.groupValues[1].trim().lowercase())
    }
    return found.toList()
}

/** Уникальные цели [[вики-ссылок]] из контента (без якорей и алиасов). */
fun extractWikiLinks(content: String): List<String> {
    val found = LinkedHashSet<String>()
    val regex = Regex("\\[\\[([^\\[\\]#|]+?)(?:#[^\\[\\]]*)?(?:\\|[^\\[\\]]*)?\\]\\]")
    for (m in regex.findAll(content)) {
        val title = m.groupValues[1].trim()
        if (title.isNotEmpty()) found.add(title)
    }
    return found.toList()
}

/** Убрать markdown-синтаксис для превью карточки (как stripMarkdown в веб-версии). */
fun stripMarkdown(md: String, maxLen: Int = 280): String {
    val text = md
        .replace(Regex("!\\[([^\\]]*)\\]\\(([^)\\s]+)(?:\\s+\"[^\"]*\")?\\)"), "[изображение] $1")
        .replace(Regex("\\[([^\\]]*)\\]\\(([^)\\s]+)(?:\\s+\"[^\"]*\")?\\)"), "$1")
        .replace(Regex("\\[\\[([^\\[\\]|]+?)(?:\\|[^\\[\\]]*)?\\]\\]"), "$1")
        .replace(Regex("^#{1,6}\\s+", RegexOption.MULTILINE), "")
        .replace(Regex("(\\*\\*|__)(.*?)\\1"), "$2")
        .replace(Regex("(\\*|_)(.*?)\\1"), "$2")
        .replace(Regex("~~(.*?)~~"), "$1")
        .replace(Regex("`([^`]*)`"), "$1")
        .replace(Regex("^>\\s?", RegexOption.MULTILINE), "")
        .replace(Regex("^(-{3,}|\\*{3,}|_{3,})\\s*$", RegexOption.MULTILINE), "")
        .replace(Regex("^\\s*[-*+]\\s+\\[[ xX]\\]\\s*", RegexOption.MULTILINE), "☐ ")
        .replace(Regex("^\\s*[-*+]\\s+", RegexOption.MULTILINE), "• ")
        .replace(Regex("^\\s*\\d+\\.\\s+", RegexOption.MULTILINE), "• ")
        .replace(Regex("<[^>]+>"), "")
        .replace(Regex("\\n{2,}"), "\n")
        .trim()
    return if (text.length > maxLen) text.take(maxLen).trimEnd() + "…" else text
}

/** Экранирование строки для встраивания в RegExp. */
fun escapeRegExp(input: String): String =
    input.replace(Regex("[.*+?^\${}()|[\\]\\\\]"), "\\\\$&")

// ----- Сортировка и фильтры -----------------------------------------------

/** Ключи сортировки (4 варианта веб-версии + ручной порядок с drag&drop). */
enum class SortKey(val label: String) {
    UPDATED("Недавние"),
    CREATED("Новые"),
    TITLE("По алфавиту"),
    REMINDER("По напоминанию"),
    MANUAL("Вручную")
}

/** Сравнение заголовков: пустые («Без названия») всегда в конце, как в веб-версии. */
fun titleCompare(a: Note, b: Note): Int {
    val ta = a.title.trim()
    val tb = b.title.trim()
    if (ta.isEmpty() && tb.isEmpty()) return 0
    if (ta.isEmpty()) return 1
    if (tb.isEmpty()) return -1
    return ta.lowercase().compareTo(tb.lowercase())
}
