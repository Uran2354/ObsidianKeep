package com.example.obsidiankeep

import android.app.Activity
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/**
 * Экспорт заметки через системное окно «Поделиться».
 *
 * Два канала:
 *  - [shareFile] — РЕАЛЬНЫЙ .md-файл (FileProvider, EXTRA_STREAM): файл можно
 *    сохранить на Диск, приложить к письму, отправить в мессенджер. Раньше
 *    «Экспорт (.md)» шёл только ТЕКСТОМ (EXTRA_TEXT), из-за чего часть
 *    приложений не давала получить файл — «поделиться не получается»;
 *  - [shareText] — просто текст (ACTION_SEND, EXTRA_TEXT) для мессенджеров.
 *
 * Обе функции безопасны: провал запуска (нет получателей и т.п.) не роняет
 * приложение, а показывает тост. Заблокированные заметки шифротекстом —
 * гард делает вызывающий код (там же тост «разблокируйте папку»).
 */
object NoteShare {

    /** Поделиться заметкой реальным .md-файлом. false — не удалось записать/запустить. */
    fun shareFile(activity: Activity, note: Note): Boolean {
        val file = runCatching { writeExportFile(activity, note) }.getOrNull() ?: return false
        val uri = FileProvider.getUriForFile(activity, activity.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/markdown"
            putExtra(Intent.EXTRA_SUBJECT, note.title.ifBlank { "Без названия" })
            putExtra(Intent.EXTRA_STREAM, uri)
            // Право чтения файла — целевому приложению (иначе получатель
            // видит «файл недоступен»).
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return startChooser(activity, send)
    }

    /** Поделиться заметкой текстом (заголовок + контент). */
    fun shareText(activity: Activity, note: Note): Boolean {
        val text = StringBuilder("# ").append(note.title).append("\n\n").append(note.content).toString()
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, note.title.ifBlank { "Без названия" })
            putExtra(Intent.EXTRA_TEXT, text)
        }
        return startChooser(activity, send)
    }

    private fun startChooser(activity: Activity, send: Intent): Boolean =
        runCatching {
            activity.startActivity(Intent.createChooser(send, "Поделиться заметкой"))
        }.onFailure {
            Toast.makeText(activity, "Не удалось открыть окно «Поделиться»", Toast.LENGTH_LONG).show()
        }.isSuccess

    /** Записать заметку в cacheDir/shared/<имя>.md; экспорты старше суток чистятся. */
    private fun writeExportFile(activity: Activity, note: Note): File {
        val dir = File(activity.cacheDir, "shared").apply { mkdirs() }
        val dayAgo = System.currentTimeMillis() - 24 * 60 * 60 * 1000
        dir.listFiles()?.forEach { if (it.lastModified() < dayAgo) it.delete() }
        // Имя файла = заголовок (безопасные символы), без расширения внутри имени.
        val safe = note.title.ifBlank { "Заметка" }
            .replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_")
            .trim().take(50).ifBlank { "Заметка" }
        val file = File(dir, "$safe.md")
        file.writeText(
            StringBuilder("# ").append(note.title).append("\n\n").append(note.content).toString()
        )
        return file
    }
}
