package com.example.obsidiankeep

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Локальное хранилище заметок и папок — единая точка правды для всех экранов
 * (аналог API-роутов веб-версии, но целиком офлайн).
 *
 * Решения:
 *  - Персистенция — JSON-файлы в filesDir/obsidiankeep/ (notes.json,
 *    folders.json), атомарная запись через tmp+rename. Room/Hilt не
 *    используются сознательно: требование «плоского одного пакета» без
 *    кодогенерации и DI-фреймворков.
 *  - Запись на диск асинхронная ([ioExecutor]): поток StateFlow обновляется
 *    мгновенно под [lock], а сериализация JSON уходит в однопоточный
 *    executor — автосохранение в редакторе (каждые 700 мс) не дёргает UI-поток.
 *    Порядок записи сохраняется, single-writer → гонок нет.
 *  - Реактивность — [MutableStateFlow]: экраны собирают состояние через
 *    repeatOnLifecycle (аналог хуков веб-версии).
 *  - Теги выводятся из контента, папка удаляется без каскада на заметки.
 *  - Корзина: deletedAt = now; автоп purge заметок старше 10 дней — при
 *    каждом запуске приложения ([purgeTrash]).
 *  - Защищённые папки: заметки с isEncrypted=true лежат на диске
 *    шифротекстом; в памяти они расшифрованы только пока папка разблокирована
 *    ([unlockedFolderIds]/[unlockedKeys]); заблокированные заметки скрыты из
 *    всех выборок ([query], [tagCounts], [backlinksFor], [findByTitle],
 *    [withReminders]) — как в оригинале с unlockedFolderIds.
 *
 * Все строковые литералы — русские.
 */
object NotesStore {

    private const val TRASH_RETENTION_MS = 10L * 24 * 60 * 60 * 1000

    private val lock = ReentrantLock()
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "obsidiankeep-io").apply { isDaemon = true }
    }

    private lateinit var notesFile: File
    private lateinit var foldersFile: File
    private lateinit var ordersFile: File

    private val _notes = MutableStateFlow<List<Note>>(emptyList())
    val notes: StateFlow<List<Note>> get() = _notes

    private val _folders = MutableStateFlow<List<Folder>>(emptyList())
    val folders: StateFlow<List<Folder>> get() = _folders

    /** Ручной порядок заметок по scope ("root"/id папки/"favorites"). */
    private val manualOrders = HashMap<String, List<String>>()

    // ----- Защищённые папки (сессия разблокировки) ------------------------------

    /** Id папок, разблокированных в этой сессии (сбрасывается в [lockAll]). */
    private val _unlockedFolderIds = MutableStateFlow<Set<String>>(emptySet())
    val unlockedFolderIds: StateFlow<Set<String>> get() = _unlockedFolderIds

    /** Data-ключи разблокированных папок (только память, не диск). */
    private val unlockedKeys = HashMap<String, ByteArray>()

    /** Инициализация (вызывается из [ObsidianKeepApp]). Идемпотентна. */
    fun init(context: Context) {
        lock.withLock {
            if (::notesFile.isInitialized) return
            val dir = File(context.filesDir, "obsidiankeep").apply { mkdirs() }
            notesFile = File(dir, "notes.json")
            foldersFile = File(dir, "folders.json")
            ordersFile = File(dir, "orders.json")
            _notes.value = loadNotes()
            _folders.value = loadFolders()
            manualOrders.clear()
            manualOrders.putAll(loadOrders())
        }
        // Автоочистка корзины старше 10 дней (контракт веб-версии).
        purgeTrash(System.currentTimeMillis())
    }

    // ----- Персистенция -------------------------------------------------------

    /**
     * Загрузка с защитой от порчи: при ошибке разбора файл сохраняется как
     * *.corrupt-<время> (данные не затираются молча), хранилище стартует пустым.
     */
    private fun loadNotes(): List<Note> {
        if (!notesFile.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(notesFile.readText())
            (0 until arr.length()).map { Note.fromJson(arr.getJSONObject(it)) }
        }.getOrElse {
            notesFile.renameTo(File(notesFile.parentFile, "notes.json.corrupt-${System.currentTimeMillis()}"))
            emptyList()
        }
    }

    private fun loadFolders(): List<Folder> {
        if (!foldersFile.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(foldersFile.readText())
            (0 until arr.length()).map { Folder.fromJson(arr.getJSONObject(it)) }
        }.getOrElse {
            foldersFile.renameTo(File(foldersFile.parentFile, "folders.json.corrupt-${System.currentTimeMillis()}"))
            emptyList()
        }
    }

    /** Карта «scope → список id» с диска; битый файл — как с заметками, в *.corrupt. */
    private fun loadOrders(): Map<String, List<String>> {
        if (!::ordersFile.isInitialized || !ordersFile.exists()) return emptyMap()
        return runCatching {
            val root = JSONObject(ordersFile.readText())
            val scopes = root.getJSONObject("scopes")
            val map = HashMap<String, List<String>>()
            scopes.keys().forEach { scope ->
                val arr = scopes.getJSONArray(scope)
                map[scope] = (0 until arr.length()).map { arr.getString(it) }
            }
            map
        }.getOrElse {
            ordersFile.renameTo(File(ordersFile.parentFile, "orders.json.corrupt-${System.currentTimeMillis()}"))
            emptyMap()
        }
    }

    /** Сохранить ручной порядок scope (drag&drop). Сохранение асинхронное. */
    fun setManualOrder(scope: String, ids: List<String>) {
        lock.withLock {
            manualOrders[scope] = ids
            ioExecutor.execute {
                val scopes = JSONObject()
                manualOrders.forEach { (s, list) ->
                    val arr = JSONArray()
                    list.forEach { arr.put(it) }
                    scopes.put(s, arr)
                }
                atomicWrite(ordersFile, JSONObject().put("scopes", scopes).toString(2))
            }
        }
    }

    /** Сохранённый ручной порядок scope (пустой — порядок не задан). */
    fun manualOrder(scope: String): List<String> = manualOrders[scope].orEmpty()

    /**
     * Запланировать асинхронную запись заметок. Снимок списка берётся ПОД
     * lock (иммутабельные списки — безопасно читать в executor), а контент
     * защищённых заметок шифруется в момент записи, если ключ папки в кэше
     * (папка разблокирована) — на диск всегда попадает шифротекст.
     */
    private fun saveNotesLocked() {
        val snapshot = _notes.value.toList()
        val foldersSnapshot = _folders.value.toList()
        ioExecutor.execute {
            val arr = JSONArray()
            snapshot.forEach { arr.put(noteToJson(it, foldersSnapshot)) }
            atomicWrite(notesFile, arr.toString(2))
        }
    }

    /** JSON заметки для диска: защищённые заметки пишутся шифротекстом. */
    private fun noteToJson(note: Note, folders: List<Folder>): JSONObject {
        val needEncrypt = note.isEncrypted && note.folderId != null &&
            folders.any { it.id == note.folderId && it.isProtected }
        val content = if (needEncrypt) {
            val key = unlockedKeys[note.folderId]
            if (key != null) CryptoManager.encrypt(note.content, key) else note.content
        } else {
            note.content
        }
        return JSONObject()
            .put("id", note.id)
            .put("title", note.title)
            .put("content", content)
            .put("color", note.color)
            .put("folderId", note.folderId ?: JSONObject.NULL)
            .put("isFavorite", note.isFavorite)
            .put("isPinned", note.isPinned)
            .put("deletedAt", note.deletedAt ?: JSONObject.NULL)
            .put("reminderAt", note.reminderAt ?: JSONObject.NULL)
            .put("isEncrypted", note.isEncrypted)
            .put("createdAt", note.createdAt)
            .put("updatedAt", note.updatedAt)
    }

    private fun saveFoldersLocked() {
        val snapshot = _folders.value.toList()
        ioExecutor.execute {
            val arr = JSONArray()
            snapshot.forEach { arr.put(it.toJson()) }
            atomicWrite(foldersFile, arr.toString(2))
        }
    }

    /** Атомарная запись: сначала tmp, затем rename (не потерять данные при сбое). */
    private fun atomicWrite(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) {
            target.writeText(text)
            tmp.delete()
        }
    }

    // ----- Защита папок ---------------------------------------------------------

    /** Защищена ли папка и не разблокирована ли она сейчас. */
    fun isFolderLocked(folderId: String?): Boolean {
        if (folderId == null) return false
        val folder = folderById(folderId) ?: return false
        return folder.isProtected && !_unlockedFolderIds.value.contains(folderId)
    }

    /** Заметка недоступна для чтения/правки (защищённая папка заблокирована)? */
    fun isNoteLocked(note: Note): Boolean = note.isEncrypted && isFolderLocked(note.folderId)

    /**
     * Разблокировать папку по PIN. Возвращает false при неверном PIN
     * (или папка не защищена — тогда разблокировать нечего).
     */
    fun unlockFolder(folderId: String, pin: String): Boolean {
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
            if (!folder.isProtected) return true
            if (!FolderPin.verify(folder, pin)) return false
            val key = runCatching {
                CryptoManager.decryptDataKey(folder.encryptedKey ?: return false)
            }.getOrNull() ?: return false
            unlockedKeys[folderId] = key
            _unlockedFolderIds.value = _unlockedFolderIds.value + folderId
            // Расшифровать содержимое заметок папки в памяти (диск остаётся шифром).
            decryptFolderNotesLocked(folderId)
            return true
        }
    }

    /**
     * Разблокировать папку по биометрии (PIN не требуется — как в оригинале,
     * где биометрия была альтернативой). Вызывается после успешного
     * BiometricPrompt в [FolderLock].
     */
    fun unlockFolderBiometric(folderId: String): Boolean {
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
            if (!folder.isProtected) return true
            val key = runCatching {
                CryptoManager.decryptDataKey(folder.encryptedKey ?: return false)
            }.getOrNull() ?: return false
            unlockedKeys[folderId] = key
            _unlockedFolderIds.value = _unlockedFolderIds.value + folderId
            decryptFolderNotesLocked(folderId)
            return true
        }
    }

    /** Заблокировать папку: содержимое снова шифруется, ключ удаляется. */
    fun lockFolder(folderId: String) {
        lock.withLock {
            if (!_unlockedFolderIds.value.contains(folderId)) return
            encryptFolderNotesLocked(folderId)
            unlockedKeys.remove(folderId)
            _unlockedFolderIds.value = _unlockedFolderIds.value - folderId
            saveNotesLocked()
        }
    }

    /** Заблокировать ВСЕ папки (сворачивание приложения — авто-блокировка). */
    fun lockAll() {
        val ids = _unlockedFolderIds.value.toList()
        ids.forEach { lockFolder(it) }
    }

    /**
     * Защитить папку: сгенерировать data-ключ, зашифровать содержимое всех
     * её заметок (в т.ч. в памяти), сохранить PIN-хэш. Как в оригинале,
     * папка остаётся ЗАБЛОКИРОВАННОЙ — сразу после установки защиты.
     */
    fun protectFolder(folderId: String, pin: String): Boolean {
        if (!FolderPin.isValid(pin)) return false
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
            if (folder.isProtected) return false
            val salt = FolderPin.newSalt()
            val hash = FolderPin.hashPin(pin, salt)
            val dataKey = CryptoManager.generateDataKey()
            val wrapped = runCatching { CryptoManager.encryptDataKey(dataKey) }.getOrNull() ?: return false
            val now = System.currentTimeMillis()
            _notes.value = _notes.value.map { note ->
                if (note.folderId == folderId && !note.isEncrypted && !note.isTrashed) {
                    note.copy(
                        content = CryptoManager.encrypt(note.content, dataKey),
                        isEncrypted = true,
                        updatedAt = now
                    )
                } else note
            }
            _folders.value = _folders.value.map {
                if (it.id == folderId) it.copy(
                    isProtected = true,
                    encryptedKey = wrapped,
                    pinHash = hash,
                    pinSalt = salt
                ) else it
            }
            saveFoldersLocked()
            saveNotesLocked()
            return true
        }
    }

    /** Снять защиту (требуется PIN): расшифровать заметки, очистить ключи. */
    fun unprotectFolder(folderId: String, pin: String): Boolean {
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
            if (!folder.isProtected) return true
            if (!FolderPin.verify(folder, pin)) return false
            if (!_unlockedFolderIds.value.contains(folderId)) {
                if (!unlockFolderInternalLocked(folderId)) return false
            }
            decryptFolderNotesLocked(folderId)
            val now = System.currentTimeMillis()
            _notes.value = _notes.value.map { note ->
                if (note.folderId == folderId && note.isEncrypted) {
                    note.copy(isEncrypted = false, updatedAt = now)
                } else note
            }
            _folders.value = _folders.value.map {
                if (it.id == folderId) it.copy(
                    isProtected = false,
                    encryptedKey = null,
                    pinHash = null,
                    pinSalt = null
                ) else it
            }
            unlockedKeys.remove(folderId)
            _unlockedFolderIds.value = _unlockedFolderIds.value - folderId
            saveFoldersLocked()
            saveNotesLocked()
            return true
        }
    }

    /** Сменить PIN папки (старый должен быть верен). */
    fun changeFolderPin(folderId: String, oldPin: String, newPin: String): Boolean {
        if (!FolderPin.isValid(newPin)) return false
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
            if (!folder.isProtected) return false
            if (!FolderPin.verify(folder, oldPin)) return false
            val salt = FolderPin.newSalt()
            val hash = FolderPin.hashPin(newPin, salt)
            _folders.value = _folders.value.map {
                if (it.id == folderId) it.copy(pinHash = hash, pinSalt = salt) else it
            }
            saveFoldersLocked()
            return true
        }
    }

    /** Внутренняя разблокировка без проверки PIN (уже вызван под lock). */
    private fun unlockFolderInternalLocked(folderId: String): Boolean {
        val folder = _folders.value.firstOrNull { it.id == folderId } ?: return false
        if (!folder.isProtected) return true
        val key = runCatching {
            CryptoManager.decryptDataKey(folder.encryptedKey ?: return false)
        }.getOrNull() ?: return false
        unlockedKeys[folderId] = key
        _unlockedFolderIds.value = _unlockedFolderIds.value + folderId
        decryptFolderNotesLocked(folderId)
        return true
    }

    /** Расшифровать в памяти содержимое заметок папки (папка разблокирована). */
    private fun decryptFolderNotesLocked(folderId: String) {
        val key = unlockedKeys[folderId] ?: return
        _notes.value = _notes.value.map { note ->
            if (note.folderId == folderId && note.isEncrypted) {
                val plain = runCatching { CryptoManager.decrypt(note.content, key) }.getOrNull()
                if (plain != null) note.copy(content = plain) else note
            } else note
        }
    }

    /** Зашифровать в памяти содержимое заметок папки (перед блокировкой). */
    private fun encryptFolderNotesLocked(folderId: String) {
        val key = unlockedKeys[folderId] ?: return
        _notes.value = _notes.value.map { note ->
            if (note.folderId == folderId && note.isEncrypted) {
                note.copy(content = CryptoManager.encrypt(note.content, key))
            } else note
        }
    }

    // ----- Заметки -------------------------------------------------------------

    /**
     * Создать заметку; возвращает готовый объект (id/времена проставлены).
     * null — если целевая папка защищена и заблокирована (UI сначала
     * предложит разблокировать) либо имя заметки создать нельзя.
     */
    fun createNote(
        title: String = "",
        content: String = "",
        color: String = "default",
        folderId: String? = null,
        reminderAt: Long? = null
    ): Note? {
        if (isFolderLocked(folderId)) return null
        val now = System.currentTimeMillis()
        val note = Note(
            id = UUID.randomUUID().toString(),
            title = title,
            content = content,
            color = normalizeColor(color),
            folderId = folderId,
            isFavorite = false,
            isPinned = false,
            deletedAt = null,
            reminderAt = reminderAt,
            isEncrypted = folderId != null && (folderById(folderId)?.isProtected == true),
            createdAt = now,
            updatedAt = now
        )
        lock.withLock {
            _notes.value = listOf(note) + _notes.value
            saveNotesLocked()
        }
        return note
    }

    /**
     * Частичное обновление (аналог PATCH /api/notes/[id]). Поля null в
     * [reminderAt]/[deletedAt] сбрасывают соответствующее поле.
     * Возвращает null, если заметка не найдена или заблокирована.
     *
     * Перенос между папками обрабатывает шифрование: в защищённую папку
     * (разблокированную) — контент шифруется, из защищённой — расшифровывается.
     * Перенос В заблокированную защищённую папку запрещён (null).
     */
    fun updateNote(
        id: String,
        title: String? = null,
        content: String? = null,
        color: String? = null,
        folderId: String? = null,
        clearFolder: Boolean = false,
        isFavorite: Boolean? = null,
        isPinned: Boolean? = null,
        reminderAt: Long? = null,
        clearReminder: Boolean = false,
        deletedAt: Long? = null,
        clearDeleted: Boolean = false
    ): Note? {
        val now = System.currentTimeMillis()
        var updated: Note? = null
        lock.withLock {
            val current = _notes.value.firstOrNull { it.id == id } ?: return updated
            if (isNoteLocked(current)) return updated

            // Целевая папка: null = «осталась прежней».
            val targetFolderId: String? =
                if (clearFolder) null else if (folderId != null) folderId else current.folderId
            if (targetFolderId != current.folderId && isFolderLocked(targetFolderId)) {
                // Перенос в заблокированную защищённую папку запрещён.
                return updated
            }

            var next = current.copy(
                title = title ?: current.title,
                content = content ?: current.content,
                color = if (color != null) normalizeColor(color) else current.color,
                folderId = targetFolderId,
                isFavorite = isFavorite ?: current.isFavorite,
                isPinned = isPinned ?: current.isPinned,
                reminderAt = if (clearReminder) null else (reminderAt ?: current.reminderAt),
                deletedAt = if (clearDeleted) null else (deletedAt ?: current.deletedAt),
                updatedAt = now
            )

            // Переход «шифрованность» при смене папки.
            if (targetFolderId != current.folderId) {
                val targetProtected = targetFolderId != null &&
                    (_folders.value.firstOrNull { it.id == targetFolderId }?.isProtected == true)
                when {
                    targetProtected && !next.isEncrypted -> {
                        // В защищённую папку: контент шифруется (папка точно разблокирована —
                        // иначе isFolderLocked вернул бы null выше).
                        val key = unlockedKeys[targetFolderId]
                        if (key != null) {
                            next = next.copy(content = CryptoManager.encrypt(next.content, key), isEncrypted = true)
                        }
                    }
                    !targetProtected && next.isEncrypted -> {
                        // Из защищённой папки наружу: контент остаётся открытой строкой
                        // в памяти (она уже расшифрована при разблокировке).
                        next = next.copy(isEncrypted = false)
                    }
                }
            }

            _notes.value = _notes.value.map { if (it.id == id) next else it }
            saveNotesLocked()
            updated = next
        }
        return updated
    }

    /** В корзину (мягкое удаление). Возвращает обновлённую заметку или null. */
    fun trashNote(id: String): Note? =
        updateNote(id, deletedAt = System.currentTimeMillis())

    /** Восстановить из корзины. */
    fun restoreNote(id: String): Note? = updateNote(id, clearDeleted = true)

    /** Перманентное удаление (из корзины). */
    fun deleteForever(id: String) {
        lock.withLock {
            _notes.value = _notes.value.filterNot { it.id == id }
            saveNotesLocked()
        }
    }

    /** Очистить корзину целиком; возвращает число удалённых заметок. */
    fun emptyTrash(): Int {
        var count = 0
        lock.withLock {
            val (trashed, rest) = _notes.value.partition { it.isTrashed }
            count = trashed.size
            _notes.value = rest
            saveNotesLocked()
        }
        return count
    }

    /** Перманентно удалить заметки, лежащие в корзине дольше 10 дней. */
    fun purgeTrash(now: Long = System.currentTimeMillis()): Int {
        var count = 0
        lock.withLock {
            val (expired, rest) = _notes.value.partition {
                val d = it.deletedAt
                d != null && now - d > TRASH_RETENTION_MS
            }
            if (expired.isNotEmpty()) {
                count = expired.size
                _notes.value = rest
                saveNotesLocked()
            }
        }
        return count
    }

    fun noteById(id: String): Note? = _notes.value.firstOrNull { it.id == id }

    /**
     * Найти заметку по точному заголовку (trim, без учёта регистра) —
     * навигация по [[вики-ссылкам]]. Удалённые и заблокированные не участвуют
     * (иначе по [[ссылке]] можно открыть защищённую заметку без разблокировки).
     */
    fun findByTitle(title: String): Note? {
        val t = title.trim().lowercase()
        return _notes.value.firstOrNull {
            !it.isTrashed && !isNoteLocked(it) && it.title.trim().lowercase() == t
        }
    }

    /** Открыть по [[вики-ссылке]]: существующую или создать новую с этим заголовком. */
    fun findOrCreateByTitle(title: String): Note =
        findByTitle(title) ?: createNote(title = title.trim())
            ?: Note(
                id = "", title = title.trim(), content = "", color = "default",
                folderId = null, isFavorite = false, isPinned = false,
                deletedAt = null, reminderAt = null, isEncrypted = false,
                createdAt = 0L, updatedAt = 0L
            )

    /**
     * Бэклинки: неудалённые заметки, чей контент ссылается на «[[title]]»
     * (поиск по подстроке без учёта регистра, затем точная проверка целей
     * ссылок; лимит 50 — как в веб-версии). Заблокированные исключены.
     */
    fun backlinksFor(note: Note): List<Note> {
        val target = note.title.trim()
        if (target.isEmpty()) return emptyList()
        val needle = "[[$target]]".lowercase()
        return _notes.value
            .filter {
                it.id != note.id && !it.isTrashed && !isNoteLocked(it) &&
                    it.content.lowercase().contains(needle)
            }
            .filter { extractWikiLinks(it.content).any { t -> t.equals(target, ignoreCase = true) } }
            .take(50)
    }

    /**
     * Все неудалённые заметки с напоминанием, по возрастанию времени —
     * единый источник для календаря (точки сетки, счётчики года, панель дня).
     * Заблокированные папки исключены — их напоминания не «протекают» в UI.
     */
    fun withReminders(): List<Note> =
        _notes.value
            .filter { !it.isTrashed && it.reminderAt != null && !isNoteLocked(it) }
            .sortedBy { it.reminderAt ?: Long.MAX_VALUE }

    // ----- Папки ---------------------------------------------------------------

    /** Создать папку; null — если имя пустое или папка уже есть (409 exists). */
    fun createFolder(name: String): Folder? {
        val n = name.trim()
        if (n.isEmpty() || n.length > 60) return null
        lock.withLock {
            if (_folders.value.any { it.name.equals(n, ignoreCase = true) }) return null
            val folder = Folder(UUID.randomUUID().toString(), n, System.currentTimeMillis())
            // Порядок папок — РУЧНОЙ (перетаскивание в шторке): новая папка
            // просто дописывается в конец, не перемешивая расставленное.
            _folders.value = _folders.value + folder
            saveFoldersLocked()
            return folder
        }
    }

    /**
     * Переименовать папку; null — конфликт имени/не найдена. Защищённую
     * папку можно переименовать только в разблокированной сессии.
     */
    fun renameFolder(id: String, name: String): Folder? {
        val n = name.trim()
        if (n.isEmpty() || n.length > 60) return null
        lock.withLock {
            if (_folders.value.any { it.id != id && it.name.equals(n, ignoreCase = true) }) return null
            val idx = _folders.value.indexOfFirst { it.id == id }
            if (idx < 0) return null
            if (isFolderLocked(id)) return null
            val renamed = _folders.value[idx].copy(name = n)
            // Позиция папки сохраняется: порядок ручной, переименование
            // не должно перемешивать расставленное перетаскиванием.
            _folders.value = _folders.value.toMutableList().apply { set(idx, renamed) }
            saveFoldersLocked()
            return renamed
        }
    }

    /**
     * Удалить папку; заметки остаются (folderId → null, как onDelete: SetNull).
     * Возвращает false, если папки нет или она защищена и заблокирована —
     * в последнем случае перед удалением надо разблокировать (иначе
     * зашифрованное содержимое осталось бы нечитаемым навсегда).
     */
    fun deleteFolder(id: String): Boolean {
        lock.withLock {
            val folder = _folders.value.firstOrNull { it.id == id } ?: return false
            if (folder.isProtected && !_unlockedFolderIds.value.contains(id)) return false
            _folders.value = _folders.value.filterNot { it.id == id }
            _notes.value = _notes.value.map {
                if (it.folderId == id) it.copy(folderId = null, isEncrypted = false) else it
            }
            unlockedKeys.remove(id)
            _unlockedFolderIds.value = _unlockedFolderIds.value - id
            saveFoldersLocked()
            saveNotesLocked()
            return true
        }
    }

    fun folderById(id: String?): Folder? =
        if (id == null) null else _folders.value.firstOrNull { it.id == id }

    /**
     * Переставить папки в порядке [ids] (перетаскивание строк в шторке).
     * Порядок папок — это порядок списка [folders]: он и хранится на диске
     * (folders.json — массив), и виден во всех списках/диалогах. Папки, не
     * попавшие в [ids] (созданы во время жеста и т.п.), сохраняют прежний
     * относительный порядок в конце.
     */
    fun setFolderOrder(ids: List<String>) {
        if (ids.isEmpty()) return
        lock.withLock {
            val current = _folders.value
            if (current.size < 2) return
            val byId = current.associateBy { it.id }
            val reordered = mutableListOf<Folder>()
            ids.forEach { id -> byId[id]?.let(reordered::add) }
            current.forEach { folder ->
                if (reordered.none { it.id == folder.id }) reordered.add(folder)
            }
            if (reordered.map { it.id } == current.map { it.id }) return
            _folders.value = reordered
            saveFoldersLocked()
        }
    }

    /** Число неудалённых заметок в папке (счётчик в шторке). */
    fun noteCountIn(folderId: String): Int =
        _notes.value.count { it.folderId == folderId && !it.isTrashed }

    /** Имя папки заметки (или null) — строка-лейбл на карточке. */
    fun folderLabel(note: Note): String? = folderById(note.folderId)?.name

    // ----- Выборки (контракты списков веб-версии) -------------------------------

    /**
     * Основная выборка. view:
     *  - «all»      — активные (если folderId/tag/color заданы — фильтры)
     *  - «favorites»— избранные
     *  - «upcoming» — только с напоминанием в будущем, сортировка reminderAt asc
     *    (фикс ревью: раньше null-reminders проходили фильтр и попадали в список)
     *  - «trash»    — удалённые (в т.ч. защищённых папок — в корзине виден
     *    только заголовок, содержимое остаётся шифром до разблокировки)
     *
     * Заметки заблокированных защищённых папок скрыты из всех view, кроме trash.
     *
     * [folderScope] — ограничить поиск ТЕКУЩИМ списком (основное поле):
     * корень → только заметки без папки, открытая папка → её заметки.
     * false (быстрый поиск шторки) — поиск идёт по всем заметкам, включая
     * лежащие в папках. Тег/цвет — «сквозные» фильтры как прежде.
     * [allNotes] — взять ВСЕ заметки без папочных фильтров (граф связей).
     */
    fun query(
        view: String,
        folderId: String? = null,
        tag: String? = null,
        color: String? = null,
        q: String = "",
        folderScope: Boolean = false,
        allNotes: Boolean = false,
        sort: SortKey = SortKey.UPDATED
    ): List<Note> {
        val query = q.trim().lowercase()
        val visible: (Note) -> Boolean = { !it.isTrashed && (view == "trash" || !isNoteLocked(it)) }
        val list = when (view) {
            "trash" -> _notes.value.filter { it.isTrashed }
            "favorites" -> _notes.value.filter { visible(it) && it.isFavorite }
            "upcoming" -> {
                val now = System.currentTimeMillis()
                return _notes.value
                    .filter { visible(it) && it.reminderAt != null && it.reminderAt!! >= now }
                    .sortedWith(compareBy { it.reminderAt ?: Long.MAX_VALUE })
            }
            else -> {
                // Вид «Заметки» (бывшие «Все заметки»): заметка, перемещённая
                // в папку, исчезает из этого списка и видна внутри папки.
                // Тег/цвет — «сквозные» фильтры (иначе содержимое папок было
                // бы недостижимо). Поиск раздельный (по просьбе пользователя):
                //  - основное поле (folderScope=true) — ТОЛЬКО по заметкам
                //    текущего списка, в папках не ищет;
                //  - быстрый поиск шторки (folderScope=false) — по всем
                //    заметкам, включая лежащие в папках.
                val filterSweep = tag != null || color != null
                val searchSweep = query.isNotEmpty() && !folderScope
                _notes.value
                    .filter { visible(it) }
                    .filter {
                        when {
                            allNotes || filterSweep || searchSweep -> true
                            folderId != null -> it.folderId == folderId
                            else -> it.folderId == null
                        }
                    }
            }
        }
        val filtered = list
            .filter { tag == null || it.tags.contains(tag.lowercase()) }
            .filter { color == null || normalizeColor(color) == it.color }
            .filter { query.isEmpty() || it.title.lowercase().contains(query) || it.content.lowercase().contains(query) }
        if (view == "trash") {
            return filtered.sortedWith(compareByDescending { it.deletedAt ?: 0L })
        }
        // Ручной порядок (drag&drop, SortKey.MANUAL): чистая сохранённая
        // последовательность — БЕЗ принудительного «закреплённые сверху»,
        // пользователь двигает карточки как хочет. Scope ручного порядка:
        // корень ("root"), конкретная папка (её id), избранное ("favorites").
        if (sort == SortKey.MANUAL) {
            val scope = if (view == "favorites") "favorites" else folderId ?: "root"
            val pos = manualOrder(scope).withIndex().associate { (i, id) -> id to i }
            return filtered.sortedWith(compareBy { pos[it.id] ?: Int.MAX_VALUE })
        }
        return filtered.sortedWith(
            compareByDescending<Note> { it.isPinned }
                .thenComparator { a, b ->
                    when (sort) {
                        SortKey.UPDATED -> (b.updatedAt).compareTo(a.updatedAt)
                        SortKey.CREATED -> (b.createdAt).compareTo(a.createdAt)
                        SortKey.TITLE -> titleCompare(a, b)
                        SortKey.REMINDER -> {
                            val ra = a.reminderAt ?: Long.MAX_VALUE
                            val rb = b.reminderAt ?: Long.MAX_VALUE
                            ra.compareTo(rb)
                        }
                        // MANUAL обрабатывается выше отдельным ранним return
                        // (чистый сохранённый порядок без pinned-first).
                        SortKey.MANUAL -> 0
                    }
                }
        )
    }

    /** Облако тегов: имя → число неудалённых заметок (как GET /api/tags). */
    fun tagCounts(): List<Pair<String, Int>> {
        val counts = LinkedHashMap<String, Int>()
        _notes.value.filter { !it.isTrashed && !isNoteLocked(it) }.forEach { note ->
            note.tags.forEach { tag ->
                counts[tag] = (counts[tag] ?: 0) + 1
            }
        }
        return counts.map { it.key to it.value }
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
    }

    // ----- Резервная копия (один JSON-файл) ------------------------------------

    /** Итог восстановления — числа для тоста/логов. */
    data class RestoreReport(
        val foldersAdded: Int,
        val notesAdded: Int,
        val notesUpdated: Int,
        val notesSkipped: Int
    )

    /**
     * Снимок ВСЕХ данных (папки + заметки, включая корзину) в один JSON.
     *
     * Заметки защищённых папок сериализуются в ДИСКОВОМ формате — то есть
     * всегда ШИФРОТЕКСТОМ: [noteToJson] шифрует открытый текст ключом
     * разблокированной папки, а для заблокированной в памяти и так лежит
     * шифротекст с диска. Секрет никогда не попадает в файл копии открытым.
     *
     * [Folder.encryptedKey] остаётся обёрнутым мастер-ключом Keystore:
     * копия полностью восстанавливается на том же устройстве; на другом
     * защищённые заметки не расшифровать (мастер-ключ не извлекается —
     * это осознанный компромисс безопасности, см. подсказку в настройках).
     */
    fun buildBackup(): JSONObject {
        lock.withLock {
            val foldersSnapshot = _folders.value.toList()
            val foldersArr = JSONArray()
            foldersSnapshot.forEach { foldersArr.put(it.toJson()) }
            val notesArr = JSONArray()
            _notes.value.forEach { notesArr.put(noteToJson(it, foldersSnapshot)) }
            return JSONObject()
                .put("app", "ObsidianKeep")
                .put("kind", "backup")
                .put("version", 1)
                .put("exportedAt", System.currentTimeMillis())
                .put("foldersCount", foldersSnapshot.size)
                .put("notesCount", _notes.value.size)
                .put("folders", foldersArr)
                .put("notes", notesArr)
        }
    }

    /**
     * Восстановление из копии — слияние БЕЗ разрушения текущих данных:
     *  - папки: добавляются только ОТСУТСТВУЮЩИЕ (по id); существующие не
     *    трогаются — их крипто-состояние связано с заметками на диске;
     *    конфликт имён разрешается суффиксом «(из копии)»;
     *  - заметки: отсутствующие добавляются, существующие заменяются
     *    версией из копии только если та НОВЕЕ (updatedAt — правило
     *    «последняя правка побеждает», как в синхронизациях);
     *  - заметку разблокированной защищённой папки копия хранит
     *    шифротекстом, а память этой папки держит открытый текст —
     *    контент расшифровывается ключом сессии, иначе UI показал бы
     *    «шифр», а следующая запись зашифровала бы его повторно.
     *
     * Бросает IllegalArgumentException, если файл не копия ObsidianKeep
     * (проверка app/kind — восстанавливать любой JSON нельзя).
     * Напоминания после восстановления перепланирует вызывающий код.
     */
    fun restoreBackup(data: JSONObject): RestoreReport {
        require(data.optString("app") == "ObsidianKeep" && data.optString("kind") == "backup") {
            "Это не файл резервной копии ObsidianKeep"
        }
        var foldersAdded = 0
        var notesAdded = 0
        var notesUpdated = 0
        var notesSkipped = 0
        lock.withLock {
            // --- Папки: только новые (id как ключ), конфликт имён → суффикс.
            val restoredFolders = mutableListOf<Folder>()
            val foldersArr = data.optJSONArray("folders")
            for (i in 0 until (foldersArr?.length() ?: 0)) {
                val f = runCatching { Folder.fromJson(foldersArr!!.getJSONObject(i)) }.getOrNull() ?: continue
                if (f.id.isBlank() || _folders.value.any { it.id == f.id }) continue
                var name = f.name.trim().ifBlank { "Папка" }.take(60)
                if (_folders.value.any { it.name.equals(name, ignoreCase = true) }) name = "$name (из копии)"
                restoredFolders += f.copy(name = name)
                foldersAdded++
            }
            if (restoredFolders.isNotEmpty()) {
                // Дописать в КОНЕЦ в порядке копии: ручной порядок существующих
                // папок (перетаскивание) не перемешивается алфавитной сортировкой.
                _folders.value = _folders.value + restoredFolders
                saveFoldersLocked()
            }

            // --- Заметки: разбор, отсев битых и «висячих» (папки нет ни
            //     в копии, ни в хранилище — иначе шифротекст стал бы мусором).
            val knownFolderIds = (_folders.value.map { it.id }).toSet()
            val parsed = mutableListOf<Note>()
            val notesArr = data.optJSONArray("notes")
            for (i in 0 until (notesArr?.length() ?: 0)) {
                val n = runCatching { Note.fromJson(notesArr!!.getJSONObject(i)) }.getOrNull()
                if (n == null || n.id.isBlank()) { notesSkipped++; continue }
                if (n.folderId != null && !knownFolderIds.contains(n.folderId)) { notesSkipped++; continue }
                parsed += n
            }

            val currentById = _notes.value.associateBy { it.id }
            val toAdd = mutableListOf<Note>()
            val toReplace = mutableListOf<Note>()
            parsed.forEach { bn ->
                // Разблокированная защищённая папка → в памяти открытый текст:
                // расшифровать контент из копии (на диск его снова зашифрует
                // saveNotesLocked); не расшифровался — оставляем как есть.
                val fixed = if (bn.isEncrypted && bn.folderId != null) {
                    val key = unlockedKeys[bn.folderId]
                    if (key != null) {
                        val plain = runCatching { CryptoManager.decrypt(bn.content, key) }.getOrNull()
                        if (plain != null) bn.copy(content = plain) else bn
                    } else bn
                } else bn
                when (val cur = currentById[fixed.id]) {
                    null -> { toAdd += fixed; notesAdded++ }
                    else -> if (fixed.updatedAt > cur.updatedAt) { toReplace += fixed; notesUpdated++ } else notesSkipped++
                }
            }
            if (toReplace.isNotEmpty()) {
                val map = toReplace.associateBy { it.id }
                _notes.value = _notes.value.map { map[it.id] ?: it }
            }
            if (toAdd.isNotEmpty()) _notes.value = toAdd + _notes.value
            if (toAdd.isNotEmpty() || toReplace.isNotEmpty()) saveNotesLocked()
        }
        return RestoreReport(foldersAdded, notesAdded, notesUpdated, notesSkipped)
    }
}
