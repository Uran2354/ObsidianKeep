# Правила R8 для ObsidianKeep (release-сборка).
# Минификация выключена (см. app/build.gradle.kts), правила приведены
# для случая, когда minifyEnabled включат обратно.

# Коллбеки androidx.biometric вызываются из фреймворка.
-keep class androidx.biometric.** { *; }

# Keystore/шифрование не трогаем (рефлексии нет, но с безопасностью
# лучше не рисковать при включённой оптимизации).
-keep class javax.crypto.** { *; }
-keep class org.json.** { *; }
