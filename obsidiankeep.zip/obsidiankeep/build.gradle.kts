// Корневой build-файл ObsidianKeep.
// AGP 9.x имеет ВСТРОЕННУЮ поддержку Kotlin (built-in Kotlin): отдельный
// плагин org.jetbrains.kotlin.android больше не применяется ни здесь, ни в
// модуле — это канонический способ сборки начиная с AGP 9.0.

plugins {
    alias(libs.plugins.android.application) apply false
}
