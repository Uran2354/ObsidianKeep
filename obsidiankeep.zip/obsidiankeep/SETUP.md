# ObsidianKeep (Android) — настройка и сборка

Полноценный Gradle-проект Android Studio: открывается и собирается «как есть»
на актуальных версиях Android Studio и Gradle. Исходники — в «плоском одном
пакете» `com.example.obsidiankeep`: UI целиком в коде (без XML-лейаутов
и ViewBinding), векторные иконки — в `res/drawable` (подключаются через
`R.drawable.ic_*`), строковые литералы русские.

## 1. Требования

| Что | Значение |
|---|---|
| Android Studio | актуальная стабильная (поддержка AGP 9.x) |
| AGP | **9.4.1** (встроенный Kotlin — плагин `kotlin-android` не нужен) |
| Gradle | **9.8.1** (wrapper включён: `gradlew` + `gradle-wrapper.jar`) |
| JDK | 17+ (в Studio — встроенный JBR 21) |
| compileSdk | 37 (максимум, поддерживаемый AGP 9.4) |
| targetSdk | 35 (включён edge-to-edge; отступы применяет `Ui.applyEdgeToEdgeInsets`) |
| minSdk | 23 (BiometricPrompt; NotificationChannel — гард `Build.VERSION` ≥ 26) |

Версии заданы в **`gradle/libs.versions.toml`** (version catalog — стандарт
современных проектов); менять их достаточно в одном месте.

## 2. Сборка

### Android Studio
1. File → Open → выбрать папку проекта (где `settings.gradle.kts`).
2. Дождаться синхронизации Gradle (все зависимости подтянутся сами).
3. Run ▶ — приложение установится и запустится.

### Командная строка
```bash
./gradlew assembleDebug        # APK: app/build/outputs/apk/debug/app-debug.apk
./gradlew installDebug         # + установка на подключённое устройство
./gradlew assembleRelease      # release (минификация выключена)
```

Проект собирался и проверялся на Gradle 9.8.1 + AGP 9.4.1 (JDK 21):
`BUILD SUCCESSFUL`, `assembleDebug` → рабочий APK.

## 3. Зависимости (уже подключены, gradle/libs.versions.toml)

```toml
agp = "9.4.1"
coreKtx = "1.19.1"
appcompat = "1.8.0"
material = "1.14.0"
lifecycle = "2.11.0"          # lifecycle-runtime-ktx (repeatOnLifecycle)
coroutines = "1.11.0"         # kotlinx-coroutines-android (StateFlow)
biometric = "1.1.0"           # разблокировка защищённых папок
drawerlayout = "1.2.0"        # шторка навигации
```

Room/Hilt/Compose **не используются** — хранение в JSON (`org.json` входит
в платформу), DI нет, UI — классические View.

## 4. Структура проекта

```
obsidiankeep/
├── settings.gradle.kts          # репозитории + модуль :app
├── build.gradle.kts             # корень: плагин AGP (apply false)
├── gradle.properties            # AndroidX, jvmargs
├── gradle/
│   ├── libs.versions.toml       # каталог версий (единственное место версий)
│   └── wrapper/                 # gradle-wrapper.jar + properties (Gradle 9.8.1)
├── gradlew / gradlew.bat        # wrapper-скрипты
└── app/
    ├── build.gradle.kts         # модуль: compileSdk 37, minSdk 23, targetSdk 35
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml  # 6 активностей + ReminderReceiver + разрешения
        ├── java/com/example/obsidiankeep/   # 18 Kotlin-файлов (см. карту ниже)
        └── res/
            ├── drawable/         # 31 векторная иконка ic_* (панели, шторка, пустые состояния)
            ├── values/          # strings, themes, colors (+ values-night)
            └── mipmap-*/        # иконка приложения (mdpi…xxxhdpi)
```

## 5. Тема

`res/values/themes.xml` — Material3 DayNight, без ActionBar (тулбары
рисуются в коде), фон окна — `@color/ok_window_background` (свой для
светлой и тёмной темы). Тёмная тема по умолчанию — переключается
`Prefs.theme` («Системная / Светлая / Тёмная» в настройках) через
`AppCompatDelegate.setDefaultNightMode` (применяется при старте процесса
в `ObsidianKeepApp`, поэтому даже запуск с уведомления открывается
в выбранной теме).

## 6. Разрешения (AndroidManifest.xml)

| Разрешение | Зачем |
|---|---|
| `POST_NOTIFICATIONS` | уведомления напоминаний (Android 13+; запрашивается при первом запуске) |
| `SCHEDULE_EXACT_ALARM` | точные будильники напоминаний (Android 12+; при отказе — тихий fallback на неточный будильник) |
| `USE_BIOMETRIC` | BiometricPrompt в диалогах разблокировки папок |

## 7. Где живут данные

| Файл | Содержимое |
|---|---|
| `filesDir/obsidiankeep/notes.json` | все заметки (вкл. корзину); заметки защищённых папок — шифротекстом AES/GCM |
| `filesDir/obsidiankeep/folders.json` | папки (вкл. PIN-хэш и обёрнутый ключ защищённых) |

Запись атомарная (tmp → rename), асинхронная (однопоточный executor — UI
не блокируется автосохранением). Резервная копия — просто скопировать папку.

## 8. Защита папок

Долгое нажатие на папку в шторке → «Защитить папку…»:

| Что | Как работает |
|---|---|
| PIN | 4–16 цифр, хранится как PBKDF2-HMAC-SHA256 (100 000 итераций) + соль; забытый PIN восстановить нельзя |
| Биометрия | Если на устройстве есть отпечаток/лицо — в диалоге разблокировки есть кнопка «Войти по отпечатку» (BiometricPrompt, PIN не требуется) |
| Шифрование | Содержимое заметок шифруется AES/GCM случайным ключом папки; сам ключ обёрнут мастер-ключом Android Keystore — на диске шифротекст даже на рутованном устройстве |
| Скрытие | Заметки заблокированных папок исчезают из списков/поиска/тегов/графа/календаря; в корзине виден только заголовок |
| Авто-блокировка | При сворачивании приложения все папки блокируются автоматически (ObsidianKeepApp → ActivityLifecycleCallbacks → lockAll) |
| Перебор | 5 неверных PIN — пауза 15 секунд |

## 9. Календарь

Четыре режима, как в оригинале (переключатель над сеткой):
**Неделя** (7 дней со счётчиками) · **Месяц** (сетка с точками) ·
**Год** (12 месяцев со счётчиками, тап → месяц) · **День** (детальный
список: тап — открыть, долгое — убрать напоминание/в корзину).
Ещё: кнопка «Сегодня», ‹ › навигация по периоду, панель выбранного дня
со списком и «+ Добавить напоминание» (если 09:00 уже прошло — берётся
now+1 мин, чтобы будильник не оказался в прошлом).

## 10. Карта исходников (`app/src/main/java/com/example/obsidiankeep/`)

| Файл | Роль |
|---|---|
| `Models.kt` | Note/Folder (поля защиты), JSON, разбор #тегов, [[вики-ссылок]], stripMarkdown |
| `Prefs.kt` | настройки: тема, подложка, сетка + фильтры |
| `NoteColors.kt` | 8 цветов, насыщенная/приглушённая подложка |
| `NotesStore.kt` | хранилище-синглтон: CRUD, папки, корзина, бэклинки, выборки, шифрование и сессии разблокировки, async-запись |
| `Security.kt` | CryptoManager: мастер-ключ Keystore, AES/GCM, PBKDF2-PIN (FolderPin) |
| `FolderLock.kt` | диалоги: разблокировка (PIN/биометрия), защитить/сменить PIN/снять защиту |
| `Ui.kt` | мини-дизайн-система: палитра (Palette), карточки/чипы/кнопки-иконки + edge-to-edge (targetSdk 35) |
| `ObsidianKeepApp.kt` | Application: тема при старте, init, purge корзины, будильники, авто-блокировка папок в фоне |
| `Reminders.kt` / `ReminderReceiver.kt` | AlarmManager + уведомление (для защищённых — без содержимого) |
| `MainActivity.kt` | сетка masonry, шторка («Настройки» после «Теги», иконки папок с замком), поиск-пилюля, сортировка/цвета через bottom-sheet, переключатель темы, undo-Snackbar |
| `EditorActivity.kt` | редактор: режимы, markdown-тулбар, теги/цвет/папка/напоминание, гейт разблокировки |
| `Markdown.kt` | markdown → Spannable, кликабельные [[вики]] и #теги |
| `CalendarActivity.kt` | 4 режима Неделя/Месяц/Год/День, «Сегодня», панель дня, действия |
| `GraphView.kt` / `GraphActivity.kt` | canvas force-граф, drag, тап → заметка, статистика узлы/связи |
| `TagsActivity.kt` | облако тегов + список заметок тега |
| `TrashActivity.kt` | корзина: восстановить/удалить/очистить (10 дней), значок замка для защищённых |

## 11. Проблемы и решения

| Проблема | Решение |
|---|---|
| Studio предлагает обновить Gradle/AGP | Можно отказаться — версии согласованы (Gradle 9.8.1 ↔ AGP 9.4.1); или обновить обе в `gradle/libs.versions.toml` и `gradle/wrapper/gradle-wrapper.properties` |
| `ClassNotFoundException .ObsidianKeepApp` | В манифесте не указан `android:name=".ObsidianKeepApp"` (в проекте уже указан) |
| Напоминание не приходит | Проверьте `SCHEDULE_EXACT_ALARM` (Android 12+), разрешение уведомлений (запрашивается при первом запуске) и что `reminderAt` в будущем |
| После смены темы экран мигает | Это штатный recreate; состояние экрана хранится в Prefs |
| Рисуются не те цвета карточек | Настройки → «Цвет подложки»: Насыщенная/Приглушённая (по умолчанию насыщенная) |
| Забыл PIN папки | Восстановления нет (хэш PBKDF2): заметки останутся зашифрованными, удалить папку до разблокировки нельзя. Храните PIN надёжно |
| Нет кнопки «Войти по отпечатку» | На устройстве не задана биометрия (Настройки → Безопасность) или её нет физически — используется PIN |
| Разблокировка слетает | Так и задумано: при сворачивании приложения папки блокируются автоматически |
| Контент «подныривает» под статус-бар | Проверьте, что активность вызывает `applyEdgeToEdgeInsets()` (уже вызывается во всех шести) |
